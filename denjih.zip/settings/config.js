module.exports = {
  tokenBot: "8711213918:AAEdwM_k3ntnYPcWPbdOfsLrC1KagEifozQ",
  ownerID: "7471927461",
};
