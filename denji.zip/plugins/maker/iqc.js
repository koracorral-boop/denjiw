const handler = async (m, { conn, args, usedPrefix, command }) => {
    let text
    if (args.length >= 1) {
        text = args.join(" ")
    } else if (m.quoted && m.quoted.text) {
        text = m.quoted.text
    } else {
        return m.reply(`📱 *iPhone Quoted Chat Maker*

*Penggunaan:*
${usedPrefix}${command} [teks]

*Contoh:*
${usedPrefix}${command} ehmmmm?

*Atau reply pesan yang ingin dijadikan quoted chat*`)
    }

    await m.react('🕓')

    try {
        const apikey = 'nz-5e9d2afe12'
        const url = `https://api.naze.biz.id/create/iqc?text=${encodeURIComponent(text)}&apikey=${apikey}`

        await conn.sendFile(m.chat, url, 'iqc.png', '', m)
        await m.react('✅')
    } catch (error) {
        await m.react('❌')
        await m.reply('❌ Gagal membuat iPhone Quoted Chat, coba lagi nanti.')
    }
}

handler.help = ['iqc <teks>']
handler.tags = ['maker']
handler.command = ['iqc', 'iphonequote', 'quotechat']
handler.limit = true

export default handler