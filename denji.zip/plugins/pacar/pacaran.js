import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)
const dbPath = path.resolve(__dirname, '../../database/pacar.json')
const EXPIRED = 30 * 60 * 1000
const ONE_DAY = 24 * 60 * 60 * 1000
const STREAK_EXPIRE = 48 * 60 * 60 * 1000 // streak hangus jika 48 jam tanpa interaksi

function loadDB() {
  if (!fs.existsSync(dbPath)) {
    fs.writeFileSync(dbPath, JSON.stringify({}, null, 2))
  }
  return JSON.parse(fs.readFileSync(dbPath))
}

function saveDB(db) {
  fs.writeFileSync(dbPath, JSON.stringify(db, null, 2))
}

function initUser(db, jid) {
  if (!db[jid]) db[jid] = {}

  if (!Array.isArray(db[jid].pasangan)) db[jid].pasangan = []
  if (typeof db[jid].maxPacar !== 'number') db[jid].maxPacar = 1
  if (!db[jid].tembak || typeof db[jid].tembak !== 'object') db[jid].tembak = null
  if (!db[jid].ditembak || typeof db[jid].ditembak !== 'object') db[jid].ditembak = null

  // Migrasi format lama (array string) ke format baru (array object)
  db[jid].pasangan = db[jid].pasangan.map(p => {
    if (typeof p === 'string') {
      return {
        jid: p,
        since: Date.now(),
        streak: 0,
        lastStreak: 0,
        selfReplied: false,
        partnerReplied: false
      }
    }
    if (typeof p.since !== 'number') p.since = Date.now()
    if (typeof p.streak !== 'number') p.streak = 0
    if (typeof p.lastStreak !== 'number') p.lastStreak = 0
    if (typeof p.selfReplied !== 'boolean') p.selfReplied = false
    if (typeof p.partnerReplied !== 'boolean') p.partnerReplied = false
    return p
  })

  return db[jid]
}

function clearExpired(db, jid) {
  const user = initUser(db, jid)

  if (user.tembak && Date.now() > user.tembak.expired) {
    const target = user.tembak.target
    if (db[target]) {
      initUser(db, target)
      if (db[target].ditembak && db[target].ditembak.from === jid) {
        db[target].ditembak = null
      }
    }
    user.tembak = null
  }

  if (user.ditembak && Date.now() > user.ditembak.expired) {
    const from = user.ditembak.from
    if (db[from]) {
      initUser(db, from)
      if (db[from].tembak && db[from].tembak.target === jid) {
        db[from].tembak = null
      }
    }
    user.ditembak = null
  }
}

function getPasanganEntry(user, jid) {
  return user.pasangan.find(p => p.jid === jid)
}

function isPacaran(user, jid) {
  return user.pasangan.some(p => p.jid === jid)
}

function slotFull(user) {
  return user.pasangan.length >= user.maxPacar
}

function isOwner(sender) {
  const owners = global.owner || []
  const number = sender.split('@')[0]
  return owners.some(v => Array.isArray(v) ? v[0] == number : v == number)
}

function checkStreakExpiry(entry) {
  if (entry.lastStreak > 0 && Date.now() - entry.lastStreak > STREAK_EXPIRE) {
    entry.streak = 0
    entry.selfReplied = false
    entry.partnerReplied = false
  }
}

function getStreakEmoji(streak) {
  if (streak <= 0) return ''
  if (streak < 7) return '🔥'
  if (streak < 14) return '🔥🔥'
  if (streak < 30) return '💫🔥'
  if (streak < 100) return '⭐🔥'
  return '👑🔥'
}

function formatDuration(ms) {
  const hours = Math.floor(ms / (60 * 60 * 1000))
  const minutes = Math.floor((ms % (60 * 60 * 1000)) / (60 * 1000))
  return `${hours}j ${minutes}m`
}

const handler = async (m, { command, text }) => {
  const db = loadDB()
  const sender = m.sender
  const mentioned = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : null

  initUser(db, sender)
  clearExpired(db, sender)

  if (mentioned) {
    initUser(db, mentioned)
    clearExpired(db, mentioned)
  }

  if (command === 'tembak') {
    const target = mentioned
    if (!target) throw 'Tag orang yang mau kamu tembak.\nContoh: *.tembak @user*'
    if (target === sender) throw 'Tidak bisa menembak diri sendiri.'
    if (target.includes('0@s.whatsapp.net')) throw 'Tidak bisa menembak bot.'

    const me = db[sender]
    const dia = db[target]

    if (isPacaran(me, target)) throw 'Kamu sudah pacaran sama dia.'
    if (slotFull(me)) throw `Slot pacar kamu penuh.\nSlot: ${me.pasangan.length}/${me.maxPacar}`
    if (slotFull(dia)) throw `Slot pacar dia penuh.\nSlot: ${dia.pasangan.length}/${dia.maxPacar}`
    if (me.tembak) throw 'Kamu masih punya tembakan yang belum selesai.'
    if (dia.ditembak) throw 'Dia sedang ditembak orang lain, tunggu dulu.'

    const expired = Date.now() + EXPIRED

    me.tembak = { target, expired }
    dia.ditembak = { from: sender, expired }

    saveDB(db)

    return m.reply(
      `💘 @${sender.split('@')[0]} menembak @${target.split('@')[0]}!\n\n` +
      `@${target.split('@')[0]}, jika kamu mau terima dia, ketik:\n` +
      `*.terima @${sender.split('@')[0]}*\n` +
      `Jika tidak mau, ketik:\n` +
      `*.tolak @${sender.split('@')[0]}*\n\n` +
      `@${sender.split('@')[0]}, kalau kamu mau mundur, ketik:\n` +
      `*.akunyerah*\n\n` +
      `⏳ Berlaku selama 30 menit.`,
      m.chat,
      { mentions: [sender, target] }
    )
  }

  if (command === 'terima') {
    const target = mentioned
    if (!target) throw 'Tag orang yang menembak kamu.\nContoh: *.terima @user*'

    const me = db[sender]
    const dia = db[target]

    clearExpired(db, sender)
    clearExpired(db, target)

    if (!me.ditembak) throw 'Tidak ada yang menembak kamu.'
    if (me.ditembak.from !== target) throw 'Orang itu tidak sedang menembak kamu.'
    if (!dia.tembak || dia.tembak.target !== sender) throw 'Tembakan tidak valid atau sudah expired.'
    if (isPacaran(me, target)) throw 'Kamu sudah pacaran sama dia.'
    if (slotFull(me)) throw `Slot pacar kamu penuh.\nSlot: ${me.pasangan.length}/${me.maxPacar}`
    if (slotFull(dia)) throw `Slot pacar dia penuh.\nSlot: ${dia.pasangan.length}/${dia.maxPacar}`

    const now = Date.now()

    me.pasangan.push({
      jid: target,
      since: now,
      streak: 0,
      lastStreak: 0,
      selfReplied: false,
      partnerReplied: false
    })

    dia.pasangan.push({
      jid: sender,
      since: now,
      streak: 0,
      lastStreak: 0,
      selfReplied: false,
      partnerReplied: false
    })

    me.ditembak = null
    dia.tembak = null

    saveDB(db)

    return m.reply(
      `💖 Selamat!\n@${sender.split('@')[0]} dan @${target.split('@')[0]} sekarang resmi pacaran!\n\n` +
      `Slot @${sender.split('@')[0]}: ${me.pasangan.length}/${me.maxPacar}\n` +
      `Slot @${target.split('@')[0]}: ${dia.pasangan.length}/${dia.maxPacar}\n\n` +
      `🔥 Streak akan mulai dihitung setelah 24 jam.\n` +
      `Saling reply pesan untuk menjaga streak kalian!`,
      m.chat,
      { mentions: [sender, target] }
    )
  }

  if (command === 'tolak') {
    const target = mentioned
    if (!target) throw 'Tag orang yang mau kamu tolak.\nContoh: *.tolak @user*'

    const me = db[sender]
    const dia = db[target]

    clearExpired(db, sender)
    clearExpired(db, target)

    if (!me.ditembak) throw 'Tidak ada yang menembak kamu.'
    if (me.ditembak.from !== target) throw 'Orang itu tidak sedang menembak kamu.'
    if (!dia.tembak || dia.tembak.target !== sender) throw 'Tembakan tidak valid atau sudah expired.'

    me.ditembak = null
    dia.tembak = null

    saveDB(db)

    return m.reply(
      `💔 @${sender.split('@')[0]} menolak tembakan dari @${target.split('@')[0]}.`,
      m.chat,
      { mentions: [sender, target] }
    )
  }

  if (command === 'akunyerah') {
    const me = db[sender]

    clearExpired(db, sender)

    if (!me.tembak) throw 'Kamu tidak sedang menembak siapa pun.'

    const target = me.tembak.target
    initUser(db, target)
    clearExpired(db, target)

    const dia = db[target]

    if (dia.ditembak && dia.ditembak.from === sender) {
      dia.ditembak = null
    }

    me.tembak = null

    saveDB(db)

    return m.reply(
      `🥀 Kamu memilih menyerah dan merelakan @${target.split('@')[0]}.\nTembakan dibatalkan.`,
      m.chat,
      { mentions: [target] }
    )
  }

  if (['cekpacar', 'mypacar', 'pacarsaya', 'listpacar'].includes(command)) {
    const who = mentioned || sender
    initUser(db, who)
    clearExpired(db, who)

    const user = db[who]

    // Cek expired streak semua pasangan
    for (const p of user.pasangan) {
      checkStreakExpiry(p)
    }

    saveDB(db)

    if (!user.pasangan.length) {
      return m.reply(
        `@${who.split('@')[0]} belum punya pacar.\nSlot: ${user.pasangan.length}/${user.maxPacar}`,
        m.chat,
        { mentions: [who] }
      )
    }

    const now = Date.now()
    let teks = `💞 *Daftar Pacar* @${who.split('@')[0]}\n`
    teks += `📊 Slot: ${user.pasangan.length}/${user.maxPacar}\n`
    teks += `${'─'.repeat(25)}\n\n`

    for (let i = 0; i < user.pasangan.length; i++) {
      const p = user.pasangan[i]
      const daysSince = Math.floor((now - p.since) / ONE_DAY)

      let streakText = ''
      if (now - p.since < ONE_DAY) {
        const remaining = ONE_DAY - (now - p.since)
        streakText = `⏳ Streak dimulai dalam ${formatDuration(remaining)}`
      } else if (p.streak === 0) {
        streakText = `🔥 Streak: 0 — Ayo saling reply!`
      } else {
        streakText = `${getStreakEmoji(p.streak)} Streak: *${p.streak}*`
      }

      // Peringatan streak hampir hangus
      let warningText = ''
      if (p.streak > 0 && p.lastStreak > 0) {
        const timeLeft = STREAK_EXPIRE - (now - p.lastStreak)
        if (timeLeft > 0 && timeLeft < 6 * 60 * 60 * 1000) {
          warningText = `\n   ⚠️ Streak hangus dalam ${formatDuration(timeLeft)}!`
        }
      }

      // Status reply hari ini
      let replyStatus = ''
      if (now - p.since >= ONE_DAY && p.lastStreak > 0 && now - p.lastStreak >= ONE_DAY) {
        const selfIcon = p.selfReplied ? '✅' : '❌'
        const partnerIcon = p.partnerReplied ? '✅' : '❌'
        replyStatus = `\n   📨 Kamu: ${selfIcon} | Dia: ${partnerIcon}`
      }

      teks += `${i + 1}. @${p.jid.split('@')[0]}\n`
      teks += `   ${streakText}${warningText}${replyStatus}\n`
      teks += `   📅 ${daysSince} hari pacaran\n\n`
    }

    teks += `💡 _Saling reply chat untuk naikkan streak!_`

    return m.reply(teks, m.chat, { mentions: [who, ...user.pasangan.map(p => p.jid)] })
  }

  if (command === 'putus') {
    const target = mentioned
    if (!target) throw 'Tag pacar yang mau kamu putusin.\nContoh: *.putus @user*'

    const me = db[sender]
    const dia = db[target]

    if (!isPacaran(me, target)) throw 'Dia bukan pacar kamu.'

    // Ambil data streak sebelum putus
    const entry = getPasanganEntry(me, target)
    const streakInfo = entry ? entry.streak : 0

    me.pasangan = me.pasangan.filter(v => v.jid !== target)
    dia.pasangan = dia.pasangan.filter(v => v.jid !== sender)

    saveDB(db)

    return m.reply(
      `💔 @${sender.split('@')[0]} resmi putus dengan @${target.split('@')[0]}.\n` +
      (streakInfo > 0 ? `🔥 Streak ${streakInfo} telah hilang...` : ''),
      m.chat,
      { mentions: [sender, target] }
    )
  }

  if (command === 'setslotpacar') {
    if (!isOwner(sender)) throw 'Fitur ini hanya untuk owner.'

    const target = mentioned
    if (!target) throw 'Tag user yang mau diatur slot pacarnya.\nContoh: *.setslotpacar @user 3*'

    const args = text.trim().split(/\s+/).filter(v => !v.startsWith('@'))
    const jumlah = parseInt(args[0])

    if (isNaN(jumlah)) throw 'Masukkan jumlah slot.\nContoh: *.setslotpacar @user 3*'
    if (jumlah < 1) throw 'Minimal slot pacar adalah 1.'

    const user = db[target]
    user.maxPacar = jumlah

    if (user.pasangan.length > user.maxPacar) {
      const dibuang = user.pasangan.slice(user.maxPacar)
      user.pasangan = user.pasangan.slice(0, user.maxPacar)

      for (const ex of dibuang) {
        initUser(db, ex.jid)
        db[ex.jid].pasangan = db[ex.jid].pasangan.filter(v => v.jid !== target)
      }
    }

    saveDB(db)

    return m.reply(
      `✅ Slot pacar @${target.split('@')[0]} berhasil diatur menjadi *${jumlah}*`,
      m.chat,
      { mentions: [target] }
    )
  }

  if (command === 'addslotpacar') {
    if (!isOwner(sender)) throw 'Fitur ini hanya untuk owner.'

    const target = mentioned
    if (!target) throw 'Tag user yang mau ditambah slot pacarnya.\nContoh: *.addslotpacar @user 1*'

    const args = text.trim().split(/\s+/).filter(v => !v.startsWith('@'))
    const jumlah = parseInt(args[0])

    if (isNaN(jumlah)) throw 'Masukkan jumlah tambahan slot.\nContoh: *.addslotpacar @user 1*'
    if (jumlah < 1) throw 'Minimal tambahan slot adalah 1.'

    const user = db[target]
    user.maxPacar += jumlah

    saveDB(db)

    return m.reply(
      `✅ Slot pacar @${target.split('@')[0]} berhasil ditambah *${jumlah}*\n` +
      `Sekarang menjadi *${user.maxPacar}*`,
      m.chat,
      { mentions: [target] }
    )
  }
}

// ═══════════════════════════════════════════
// STREAK TRACKER — berjalan di setiap pesan
// Mendeteksi reply antar pasangan
// ═══════════════════════════════════════════
handler.before = async function (m) {
  try {
    // Hanya proses jika ada quoted message (reply)
    if (!m.quoted || !m.quoted.sender) return
    
    const sender = m.sender
    const repliedTo = m.quoted.sender
    
    // Abaikan jika reply diri sendiri
    if (!sender || !repliedTo || sender === repliedTo) return
    
    const db = loadDB()
    
    // Cek apakah kedua user ada di database
    if (!db[sender] || !db[repliedTo]) return
    
    initUser(db, sender)
    initUser(db, repliedTo)
    
    const senderUser = db[sender]
    const repliedUser = db[repliedTo]
    
    // Cari data pasangan dari kedua sisi
    const senderEntry = getPasanganEntry(senderUser, repliedTo)
    const repliedEntry = getPasanganEntry(repliedUser, sender)
    
    // Bukan pasangan, abaikan
    if (!senderEntry || !repliedEntry) return
    
    const now = Date.now()
    
    // Cek apakah streak sudah expired (48 jam tanpa interaksi)
    checkStreakExpiry(senderEntry)
    checkStreakExpiry(repliedEntry)
    
    // Streak belum bisa dimulai (belum 24 jam sejak jadian)
    if (now - senderEntry.since < ONE_DAY) {
      saveDB(db)
      return
    }
    
    // ═══ Tandai bahwa sender sudah reply ke pasangannya ═══
    senderEntry.selfReplied = true     // di sisi sender: "aku sudah reply"
    repliedEntry.partnerReplied = true  // di sisi partner: "pasanganku sudah reply"
    
    // ═══ Cek apakah KEDUA BELAH PIHAK sudah saling reply ═══
    if (senderEntry.selfReplied && senderEntry.partnerReplied) {
      // Cek cooldown: streak hanya bisa naik 1x per 24 jam
      const canStreak = senderEntry.lastStreak === 0 || (now - senderEntry.lastStreak >= ONE_DAY)
      
      if (canStreak) {
        // Naikkan streak!
        senderEntry.streak++
        senderEntry.lastStreak = now
        senderEntry.selfReplied = false
        senderEntry.partnerReplied = false
        
        // Sinkronkan data ke sisi partner
        repliedEntry.streak = senderEntry.streak
        repliedEntry.lastStreak = now
        repliedEntry.selfReplied = false
        repliedEntry.partnerReplied = false
        
        saveDB(db)
        
        const emoji = getStreakEmoji(senderEntry.streak)
        
        m.reply(
          `${emoji} *Streak Up!*\n\n` +
          `@${sender.split('@')[0]} ❤️ @${repliedTo.split('@')[0]}\n` +
          `🔥 Streak: *${senderEntry.streak}*\n\n` +
          `Pertahankan streak kalian dengan saling reply setiap hari!`,
          m.chat,
          { mentions: [sender, repliedTo] }
        )
        return
      }
    }
    
    saveDB(db)
  } catch (e) {
    // Gagal streak tracking tidak boleh mengganggu proses pesan lainnya
    console.error('[STREAK ERROR]', e)
  }
}

handler.help = [
  'tembak @tag',
  'terima @tag',
  'tolak @tag',
  'akunyerah',
  'cekpacar [@tag]',
  'mypacar',
  'pacarsaya',
  'listpacar',
  'putus @tag',
  'setslotpacar @tag (jumlah)',
  'addslotpacar @tag (jumlah)'
]
handler.tags = ['love']
handler.command = [
  'tembak',
  'terima',
  'tolak',
  'akunyerah',
  'cekpacar',
  'mypacar',
  'pacarsaya',
  'listpacar',
  'putus',
  'setslotpacar',
  'addslotpacar'
]

export default handler