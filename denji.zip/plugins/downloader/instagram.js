let handler = async (m, { conn, args, usedPrefix, command }) => {
    const url = args[0]
    if (!url) {
        return m.reply(
            `Please provide a valid Instagram link.\n› Example: ${usedPrefix + command} https://www.instagram.com/p/...`
        )
    }

    if (!/^https?:\/\/(www\.)?instagram\.com\//i.test(url)) {
        return m.reply('Invalid URL. Please provide a proper Instagram link.')
    }

    if (/\/stories\//i.test(url)) {
        return m.reply('Instagram stories are not supported. Please provide a post or reel URL.')
    }

    await conn.sendMessage(m.chat, {
        react: {
            text: '⏳',
            key: m.key
        }
    })

    try {
        const { success, data, error } = await instagram(url)
        if (!success) throw new Error(error || 'Failed to fetch media.')

        await Promise.all(
            data.map(async (item) => {
                if (item.type === 'mp4') {
                    await conn.sendMessage(
                        m.chat,
                        { video: { url: item.url }, mimetype: 'video/mp4' },
                        { quoted: m }
                    )
                } else {
                    await conn.sendMessage(
                        m.chat,
                        { image: { url: item.url } },
                        { quoted: m }
                    )
                }
            })
        )

        await conn.sendMessage(m.chat, {
            react: {
                text: '✅',
                key: m.key
            }
        })
    } catch (e) {
        global.logger.error(e)

        await conn.sendMessage(m.chat, {
            react: {
                text: '❌',
                key: m.key
            }
        })

        m.reply(`Error: ${e.message}`)
    }
}

handler.help = ['instagram']
handler.tags = ['downloader']
handler.command = ['igdl', 'ig', 'instagram']

export default handler

async function instagram(url) {
    const encoded = encodeURIComponent(url)
    const endpoint = `https://api.neoxr.eu/api/ig?url=${encoded}&apikey=Exjfjg`

    try {
        const res = await fetch(endpoint)
        if (!res.ok) throw new Error(`API returned status ${res.status}`)

        const json = await res.json()
        if (!json || !json.status || !Array.isArray(json.data) || json.data.length === 0) {
            return { success: false, error: 'No downloadable media found.' }
        }

        const data = json.data.map((item) => ({
            type: item.type === 'mp4' ? 'mp4' : 'jpg',
            url: item.url
        }))

        return { success: true, data }
    } catch (err) {
        return { success: false, error: err.message || 'Failed to fetch from API.' }
    }
}