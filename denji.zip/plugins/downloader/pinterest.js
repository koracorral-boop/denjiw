const NEOXR_KEY = process.env.NEOXR_APIKEY || 'Exjfjg';
const STELLAR_KEY = process.env.STELLAR_APIKEY || 'YukiWaBot';

const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

const getSenderName = async (conn, sender) => {
  try {
    const name = await conn.getName(sender);
    return name || sender.split('@')[0];
  } catch {
    return sender.split('@')[0];
  }
};

const isValidPinterestUrl = (input) => {
  return /^https?:\/\/(www\.)?(pin\.it|pinterest\.com)\//i.test(input);
};

const handler = async (m, { usedPrefix, command, conn, args }) => {
  if (!args[0]) throw `*Example:*\n• ${usedPrefix}${command} Nao Tomori\n• ${usedPrefix}${command} Nao Tomori --video\n• ${usedPrefix}${command} https://pin.it/xxxxx`;

  await conn.sendMessage(m.chat, { react: { text: '🕓', key: m.key } });

  const input = args.join(' ').trim();
  const isVideo = /--vid(eo)?/i.test(input);
  const cleanInput = input.replace(/--vid(eo)?/gi, '').trim();
  const isUrl = isValidPinterestUrl(cleanInput);

  if (!cleanInput) {
    await conn.sendMessage(m.chat, { react: { text: '✖️', key: m.key } });
    throw `Masukkan keyword atau link Pinterest!\n\nContoh:\n• ${usedPrefix}${command} Nao Tomori\n• ${usedPrefix}${command} https://pin.it/xxxxx`;
  }

  try {
    if (isUrl) {
      // === DOWNLOAD dari link Pinterest ===
      const response = await fetch(`https://api.neoxr.eu/api/pin?url=${encodeURIComponent(cleanInput)}&apikey=${NEOXR_KEY}`);

      if (!response.ok) throw new Error(`HTTP ${response.status}: Gagal menghubungi API`);

      const json = await response.json();

      if (!json.status || !json.data?.url) {
        await conn.sendMessage(m.chat, { react: { text: '✖️', key: m.key } });
        return m.reply('Gagal mengunduh dari Pinterest. Pastikan link valid dan coba lagi.');
      }

      const { url: mediaUrl, type = 'image', size = 'Unknown' } = json.data;
      const nem = await getSenderName(conn, m.sender);
      const caption = `📌 *Pinterest Download*\n› Type: ${type.toUpperCase()}\n› Size: ${size}\n› Request by: ${nem}`;
      const mediaType = type.toLowerCase();

      if (mediaType === 'video' || mediaType === 'mp4') {
        await conn.sendMessage(m.chat, {
          video: { url: mediaUrl },
          caption,
          gifPlayback: false,
          ptv: false,
          mimetype: 'video/mp4'
        }, { quoted: m });
      } else if (mediaType === 'gif') {
        await conn.sendMessage(m.chat, {
          video: { url: mediaUrl },
          caption,
          gifPlayback: true,
          ptv: false,
          mimetype: 'video/mp4'
        }, { quoted: m });
      } else {
        await conn.sendMessage(m.chat, {
          image: { url: mediaUrl },
          caption
        }, { quoted: m });
      }

      await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } else if (isVideo) {
      // === SEARCH VIDEO Pinterest ===
      const response = await fetch(`https://api.stellarwa.xyz/search/pinterestvideo?query=${encodeURIComponent(cleanInput)}&key=${STELLAR_KEY}`);

      if (!response.ok) throw new Error(`HTTP ${response.status}: Gagal menghubungi API`);

      const json = await response.json();

      if (!json.status || !Array.isArray(json.data?.videos) || json.data.videos.length < 1) {
        await conn.sendMessage(m.chat, { react: { text: '✖️', key: m.key } });
        return m.reply('Video tidak ditemukan. Coba keyword yang berbeda.');
      }

      const videos = json.data.videos.filter(v => v?.dl && typeof v.dl === 'string' && v.dl.startsWith('http'));

      if (videos.length < 1) {
        await conn.sendMessage(m.chat, { react: { text: '✖️', key: m.key } });
        return m.reply('Video tidak ditemukan atau URL tidak valid.');
      }

      const results = videos.sort(() => Math.random() - 0.5).slice(0, Math.min(5, videos.length));
      const nem = await getSenderName(conn, m.sender);

      for (let i = 0; i < results.length; i++) {
        const { dl, title = 'No Title', duration = '-', likes = 0 } = results[i];

        const caption = `📌 *Pinterest Video Search*\n› Query: ${cleanInput}\n› Title: ${title}\n› Duration: ${duration}\n› Likes: ${Number(likes).toLocaleString('id-ID')}\n› Video: ${i + 1}/${results.length}\n› Request by: ${nem}`;

        await conn.sendMessage(m.chat, {
          video: { url: dl },
          caption,
          gifPlayback: false,
          ptv: false,
          mimetype: 'video/mp4'
        }, { quoted: m });

        // Delay antar pesan agar tidak terkena rate limit
        if (i < results.length - 1) await sleep(1500);
      }

      await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } else {
      // === SEARCH IMAGE Pinterest ===
      const response = await fetch(`https://api.neoxr.eu/api/pinterest-v2?q=${encodeURIComponent(cleanInput)}&show=40&type=image&apikey=${NEOXR_KEY}`);

      if (!response.ok) throw new Error(`HTTP ${response.status}: Gagal menghubungi API`);

      const json = await response.json();

      if (!json.status || !Array.isArray(json.data) || json.data.length < 1) {
        await conn.sendMessage(m.chat, { react: { text: '✖️', key: m.key } });
        return m.reply('Foto tidak ditemukan. Coba keyword yang berbeda.');
      }

      const data = json.data.filter(item => !item.is_video && Array.isArray(item.content) && item.content.length > 0 && item.content[0]?.url);

      if (data.length < 1) {
        await conn.sendMessage(m.chat, { react: { text: '✖️', key: m.key } });
        return m.reply('Foto tidak ditemukan atau URL tidak valid.');
      }

      const results = data.sort(() => Math.random() - 0.5).slice(0, Math.min(5, data.length));
      const nem = await getSenderName(conn, m.sender);
      const caption = `📌 *Pinterest Search*\n› Query: ${cleanInput}\n› Total: ${results.length} foto\n› Request by: ${nem}`;

      if (results.length === 1) {
        await conn.sendMessage(m.chat, {
          image: { url: results[0].content[0].url },
          caption
        }, { quoted: m });
      } else {
        try {
          const albumContent = results.map((item, i) => ({
            image: { url: item.content[0].url },
            caption: i === 0 ? caption : ''
          }));

          await conn.sendMessage(m.chat, { album: albumContent }, { quoted: m });
        } catch {
          // Fallback: kirim satu per satu jika album tidak didukung
          for (let i = 0; i < results.length; i++) {
            await conn.sendMessage(m.chat, {
              image: { url: results[i].content[0].url },
              caption: i === 0 ? caption : `📌 Foto ${i + 1}/${results.length}`
            }, { quoted: m });
            if (i < results.length - 1) await sleep(1000);
          }
        }
      }

      await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    }

  } catch (e) {
    console.error('[Pinterest Handler Error]', e);
    await conn.sendMessage(m.chat, { react: { text: '✖️', key: m.key } });
    throw `Terjadi kesalahan: ${e.message || 'Unknown error'}`;
  }
};

handler.help = ['pinterest <keyword|url>', 'pinterest <keyword> --video'];
handler.tags = ['internet'];
handler.command = ['pinterest', 'pin'];
handler.limit = 5;

export default handler;