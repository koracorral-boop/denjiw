import { spawn } from "child_process";
import { writeFileSync, unlinkSync, existsSync } from "fs";
import { join } from "path";
import { tmpdir } from "os";

// ── youtube search by wolep ──────────────────────────────────────────
const youtubeSearch = async (query) => {
    if (typeof query !== "string" || query.length === 0) throw Error("invalid query");

    const headers = { "Accept-Encoding": "gzip, deflate, br, zstd" };
    const body = JSON.stringify({
        context: {
            client: {
                hl: "en",
                gl: "ID",
                clientName: "WEB",
                clientVersion: "2.20250701.09.00",
            },
        },
        params: "EgIQAQ%3D%3D",
        query,
    });

    const response = await fetch(
        "https://www.youtube.com/youtubei/v1/search?prettyPrint=false",
        { headers, body, method: "post" }
    );
    if (!response.ok)
        throw Error(`${response.status} ${response.statusText}\n${await response.text()}`);

    const json = await response.json();
    const result = json.contents.twoColumnSearchResultsRenderer
        .primaryContents.sectionListRenderer.contents[0]
        .itemSectionRenderer.contents
        .filter((v) => v?.videoRenderer?.lengthText?.simpleText)
        .map((v) => {
            const vr = v.videoRenderer;
            const videoId = vr.videoId;
            return {
                videoId,
                title: vr.title.runs[0].text,
                channel: vr.ownerText.runs[0].text,
                url: `https://youtu.be/${videoId}`,
                thumbnail:
                    vr.thumbnail.thumbnails[1]?.url ||
                    vr.thumbnail.thumbnails[0]?.url,
                duration: vr.lengthText.simpleText,
                datePassed: vr.publishedTimeText?.simpleText || null,
                views: vr.shortViewCountText.simpleText,
            };
        });

    if (result.length === 0)
        throw Error(`tidak bisa menemukan video dari keyword ${query}`);
    return result;
};

// ── handler ──────────────────────────────────────────────────────────
let handler = async (m, { conn, args, usedPrefix, command }) => {
    if (!args[0])
        return m.reply(
            `Please provide a song title.\n› Example: ${usedPrefix + command} horregg`
        );

    await m.react('🕐');
    let inputPath, outputPath;

    try {
        // ✅ 1) Search video via YouTube innertube
        const searchResults = await youtubeSearch(args.join(" ").trim());
        const video = searchResults[0];

        // ✅ 2) Ambil link download dari API
        const res = await fetch(
            "https://api.neoxr.eu/api/play?q=" +
                encodeURIComponent(video.url) +
                "&apikey=Exjfjg"
        );
        const json = await res.json();

        if (!json.status || !json.data?.url) {
            await m.react('❌');
            return m.reply("Failed to retrieve the audio download link.");
        }

        // ✅ 3) Kirim info dengan extendedMessage (externalAdReply)
        const infoMessage = `🎵 *[ PLAY YOUTUBE ]*

▸ *Id*       : ${video.videoId}
▸ *Title*    : ${video.title}
▸ *Channel*  : ${video.channel}
▸ *Duration* : ${video.duration}
▸ *Views*    : ${video.views}
▸ *Size*     : ${json.data.size}
▸ *Quality*  : ${json.data.quality}
▸ *Url*      : ${video.url}

_⏳ Harap tunggu sebentar, permintaan anda akan segera dikirim..._`;

        const [audioRes] = await Promise.all([
            fetch(json.data.url),

            conn.sendMessage(
                m.chat,
                {
                    text: infoMessage,
                    contextInfo: {
                        mentionedJid: [m.sender],
                        forwardingScore: 999,
                        isForwarded: true,
                        externalAdReply: {
                            title: video.title,
                            body: `${video.channel}  •  ${video.duration}  •  ${video.views}`,
                            mediaType: 1,
                            previewType: 0,
                            renderLargerThumbnail: true,
                            thumbnailUrl: video.thumbnail,
                            sourceUrl: video.url,
                            showAdAttribution: false,
                        },
                    },
                },
                { quoted: m }
            ),
        ]);

        if (!audioRes.ok)
            throw new Error(`Gagal fetch audio. Status: ${audioRes.status}`);

        // ✅ 4) Download audio ke buffer
        const audioBuffer = Buffer.from(await audioRes.arrayBuffer());
        if (audioBuffer.length < 1024)
            throw new Error("Audio terlalu kecil, kemungkinan URL tidak valid.");

        // ✅ 5) Simpan ke temp file
        const tmp = join(tmpdir(), `play_${Date.now()}`);
        inputPath = tmp + ".mp3";
        outputPath = tmp + "_out.mp3";

        writeFileSync(inputPath, audioBuffer);

        // ✅ 6) Convert dengan ffmpeg
        await new Promise((resolve, reject) => {
            const ffmpegArgs = [
                "-i", inputPath,
                "-vn",
                "-acodec", "libmp3lame",
                "-ar", "44100",
                "-ac", "2",
                "-ab", "192k",
                "-f", "mp3",
                "-y",
                outputPath,
            ];

            const ffmpeg = spawn("ffmpeg", ffmpegArgs);

            let stderr = "";
            let stdout = "";

            ffmpeg.stdout.on("data", (d) => (stdout += d.toString()));
            ffmpeg.stderr.on("data", (d) => (stderr += d.toString()));

            ffmpeg.on("close", (code) => {
                if (code === 0 && existsSync(outputPath)) {
                    resolve();
                } else {
                    console.error("ffmpeg stderr:", stderr);
                    console.error("ffmpeg stdout:", stdout);
                    reject(new Error(`ffmpeg gagal (exit code ${code})`));
                }
            });

            ffmpeg.on("error", (err) => {
                reject(new Error(`ffmpeg error: ${err.message}`));
            });
        });

        // ✅ 7) Pastikan file output ada
        if (!existsSync(outputPath))
            throw new Error("File output tidak ditemukan setelah convert.");

        // ✅ 8) Kirim sebagai audio
        await conn.sendMessage(
            m.chat,
            {
                audio: { url: outputPath },
                mimetype: "audio/mp4",
                ptt: false,
                fileName: `${video.title}.mp3`,
            },
            { quoted: m }
        );

        await m.react('✅');
    } catch (e) {
        console.error("Error detail:", e);
        await m.react('❌');
        m.reply(`Error: ${e.message}`);
    } finally {
        // ✅ 9) Bersihkan temp file
        try {
            if (inputPath && existsSync(inputPath)) unlinkSync(inputPath);
        } catch {}
        try {
            if (outputPath && existsSync(outputPath)) unlinkSync(outputPath);
        } catch {}
    }
};

handler.help = ["play"];
handler.tags = ["downloader"];
handler.command = ["play", "playaudio"];

export default handler;