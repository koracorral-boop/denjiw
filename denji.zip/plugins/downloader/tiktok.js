let handler = async (m, { conn, args, usedPrefix, command }) => {
  if (!args[0])
    throw `Example: ${usedPrefix + command} https://vt.tiktok.com/ZSmeB4vKj/`
  await m.react('🕓')
  try {
    const tiktokUrl = args[0]
    const isAudioOnly = ['tikmp3', 'tiktokmp3', 'ttaudio', 'tiktokaudio', 'tiktiksound', 'ttmp3'].includes(command)

    if (!isAudioOnly) {
      const res = await fetch(`https://tikwm.com/api/?url=${encodeURIComponent(tiktokUrl)}`)
      const d = await res.json()
      if (d.code !== 0 || !d.data) throw d.msg || 'TikTok API error'
      const isImage = d.data.images?.length > 0
      if (isImage) {
        if (d.data.images.length === 1) {
          await conn.sendMessage(m.chat, {
            image: { url: d.data.images[0] }
          }, { quoted: m })
        } else {
          await conn.sendMessage(m.chat, {
            album: d.data.images.map(url => ({
              image: { url }
            }))
          }, { quoted: m })
        }
      } else {
        if (!d.data.play) throw 'Video tidak ditemukan'
        await conn.sendMessage(m.chat, {
          video: { url: d.data.play },
          mimetype: 'video/mp4'
        }, { quoted: m })
      }
    }

    // Ambil audio menggunakan API stellarwa
    try {
      const audioRes = await fetch(`https://api.stellarwa.xyz/dl/tiktokmp3?url=${encodeURIComponent(tiktokUrl)}&key=YukiWaBot`)
      const audioJson = await audioRes.json()
      if (audioJson.status && audioJson.data && audioJson.data.dl) {
        await conn.sendMessage(m.chat, {
          audio: { url: audioJson.data.dl },
          mimetype: 'audio/mpeg'
        }, { quoted: m })
      }
    } catch (audioErr) {
      console.error('Audio fetch error:', audioErr)
      // Fallback ke tikwm music jika API stellarwa gagal
      if (!isAudioOnly) {
        const res2 = await fetch(`https://tikwm.com/api/?url=${encodeURIComponent(tiktokUrl)}`)
        const d2 = await res2.json()
        if (d2.data?.music) {
          await conn.sendMessage(m.chat, {
            audio: { url: d2.data.music },
            mimetype: 'audio/mpeg'
          }, { quoted: m })
        }
      } else {
        const res2 = await fetch(`https://tikwm.com/api/?url=${encodeURIComponent(tiktokUrl)}`)
        const d2 = await res2.json()
        if (d2.data?.music) {
          await conn.sendMessage(m.chat, {
            audio: { url: d2.data.music },
            mimetype: 'audio/mpeg'
          }, { quoted: m })
        }
      }
    }

    await m.react('✅')
  } catch (e) {
    console.error(e)
    await m.react('❌')
    conn.reply(m.chat, `Error: ${e.message || e}`, m)
  }
}
handler.help = ['tiktok', 'tikmp3']
handler.tags = ['downloader']
handler.command = ['tiktok', 'tt', 'ttdl', 'tiktokdl', 'tikmp3', 'tiktokmp3', 'ttaudio', 'tiktokaudio', 'tiktiksound', 'ttmp3']
handler.limit = true
export default handler