/**
 * Ban/Unban fitur global (owner only)
 * Semua user ter-block, hanya owner yang bisa pakai
 * 
 * Ban 1 command = seluruh alias plugin ikut ter-ban
 *
 *   .bfg sticker
 *   .unbfg sticker
 *   .listbfg
 */

let handler = async (m, { command, text, usedPrefix }) => {
  if (!text && !['listbfg', 'listbanfiturglobal'].includes(command)) {
    return m.reply(
      `📌 *Penggunaan:*\n` +
      `• *${usedPrefix}bfg <command>* — ban fitur global\n` +
      `• *${usedPrefix}unbfg <command>* — unban fitur global\n` +
      `• *${usedPrefix}listbfg* — lihat daftar\n\n` +
      `Contoh: *${usedPrefix}bfg sticker*\n` +
      `→ Semua alias (sticker/stiker/s) ter-ban di semua grup`
    )
  }

  const cmd = (text || '').toLowerCase().trim()

  switch (command) {
    case 'bfg':
    case 'banfiturglobal': {
      const aliases = global.findAllAliases(cmd)
      const success = global.addBanFiturGlobal(cmd)

      if (success) {
        let msg = `✅ Fitur *${cmd}* berhasil di-*nonaktifkan secara global*.`
        if (aliases.length > 1) {
          msg += `\n📋 Alias yang ikut ter-ban: ${aliases.join(', ')}`
        }
        msg += `\n\n🔒 Semua user tidak bisa pakai, hanya owner.`
        m.reply(msg)
      } else {
        m.reply(`⚠️ Fitur *${cmd}* sudah ada di daftar ban global.`)
      }
      break
    }

    case 'unbfg':
    case 'unbanfiturglobal': {
      const success = global.delBanFiturGlobal(cmd)
      if (success) {
        const aliases = global.findAllAliases(cmd)
        let msg = `✅ Fitur *${cmd}* berhasil di-*aktifkan kembali secara global*.`
        if (aliases.length > 1) {
          msg += `\n📋 Alias yang ikut aktif: ${aliases.join(', ')}`
        }
        m.reply(msg)
      } else {
        m.reply(`⚠️ Fitur *${cmd}* tidak ditemukan di daftar ban global.`)
      }
      break
    }

    case 'listbfg':
    case 'listbanfiturglobal': {
      const list = global.listBanFiturGlobal()
      if (list.length === 0) {
        m.reply('📋 Tidak ada fitur yang di-ban secara global.')
      } else {
        let msg = `📋 *Daftar Ban Fitur Global:*\n\n`
        list.forEach((f, i) => {
          const aliases = global.findAllAliases(f)
          msg += `${i + 1}. *${f}*`
          if (aliases.length > 1) {
            msg += ` → alias: ${aliases.filter(a => a !== f).join(', ')}`
          }
          msg += '\n'
        })
        msg += `\n_Total: ${list.length} fitur_`
        m.reply(msg)
      }
      break
    }
  }
}

handler.command = ['bfg', 'banfiturglobal', 'unbfg', 'unbanfiturglobal', 'listbfg', 'listbanfiturglobal']
handler.help = ['bfg <cmd>', 'unbfg <cmd>', 'listbfg']
handler.tags = ['owner']
handler.rowner = true

export default handler