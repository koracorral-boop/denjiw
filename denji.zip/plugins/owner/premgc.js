import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)
const premgcPath = path.resolve(__dirname, '../../database/premiumgc.json')

// ==================== DATABASE HELPERS ====================

function loadDB() {
  try {
    const dir = path.dirname(premgcPath)
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true })
    if (!fs.existsSync(premgcPath)) {
      fs.writeFileSync(premgcPath, JSON.stringify({}, null, 2))
      return {}
    }
    const raw = fs.readFileSync(premgcPath, 'utf-8')
    const parsed = JSON.parse(raw)
    return parsed && typeof parsed === 'object' ? parsed : {}
  } catch {
    return {}
  }
}

function saveDB(data) {
  const dir = path.dirname(premgcPath)
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true })
  fs.writeFileSync(premgcPath, JSON.stringify(data, null, 2))
}

// ==================== TIME PARSER ====================

const UNIT_MS = {
  'd': 1000,
  'm': 60 * 1000,
  'j': 60 * 60 * 1000,
  'h': 24 * 60 * 60 * 1000,
  'b': 30 * 24 * 60 * 60 * 1000
}

const UNIT_NAME = {
  'd': 'Detik',
  'm': 'Menit',
  'j': 'Jam',
  'h': 'Hari',
  'b': 'Bulan'
}

function parseDuration(str) {
  if (!str) return null
  str = str.trim().toLowerCase()

  if (str === '0') {
    return { ms: 0, text: 'Permanen', permanent: true }
  }

  const match = str.match(/^(\d+)(d|m|j|h|b)$/i)
  if (!match) return null

  const amount = parseInt(match[1])
  const unit = match[2].toLowerCase()

  if (amount <= 0 || !UNIT_MS[unit]) return null

  return {
    ms: amount * UNIT_MS[unit],
    text: `${amount} ${UNIT_NAME[unit]}`,
    permanent: false
  }
}

function formatRemaining(ms) {
  if (ms <= 0) return 'Sudah expired'

  const bulan = Math.floor(ms / UNIT_MS['b'])
  ms %= UNIT_MS['b']
  const hari = Math.floor(ms / UNIT_MS['h'])
  ms %= UNIT_MS['h']
  const jam = Math.floor(ms / UNIT_MS['j'])
  ms %= UNIT_MS['j']
  const menit = Math.floor(ms / UNIT_MS['m'])
  ms %= UNIT_MS['m']
  const detik = Math.floor(ms / UNIT_MS['d'])

  const parts = []
  if (bulan) parts.push(`${bulan} bulan`)
  if (hari) parts.push(`${hari} hari`)
  if (jam) parts.push(`${jam} jam`)
  if (menit) parts.push(`${menit} menit`)
  if (detik && !bulan && !hari) parts.push(`${detik} detik`)

  return parts.join(' ') || '< 1 detik'
}

function formatDate(ts) {
  return new Date(ts).toLocaleDateString('id-ID', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    timeZone: 'Asia/Jakarta'
  }) + ' WIB'
}

const DURATION_USAGE =
  `\n*Format Durasi:*\n` +
  `- *0* = Permanen\n` +
  `- *30d* = 30 Detik\n` +
  `- *30m* = 30 Menit\n` +
  `- *12j* = 12 Jam\n` +
  `- *30h* = 30 Hari\n` +
  `- *1b* = 1 Bulan`

// ==================== HANDLER ====================

const handler = async (m, { command, args, text, conn, groupMetadata, isROwner, isOwner: ownerFlag }) => {
  const sender = m.sender
  const isOwnr = ownerFlag || isROwner

  // ═══════════════════════════════════════
  //   ADD PREMIUM GROUP
  // ═══════════════════════════════════════
  if (['addpremgc', 'addpremiumgc', 'setpremgc'].includes(command)) {
    if (!isOwnr) throw 'Fitur ini hanya untuk *Owner Bot*.'

    let groupId, groupName, durationArg

    if (m.isGroup) {
      groupId = m.chat
      groupName = groupMetadata?.subject || m.chat
      durationArg = args[0]
    } else {
      if (!args[0]) {
        throw `*Cara Penggunaan:*\n\n` +
          `Di dalam grup:\n` +
          `*.addpremgc [durasi]*\n\n` +
          `Di private chat:\n` +
          `*.addpremgc [id_grup] [durasi]*\n` +
          DURATION_USAGE
      }
      groupId = args[0].includes('@') ? args[0] : args[0] + '@g.us'
      durationArg = args[1]
      try {
        const meta = await conn.groupMetadata(groupId)
        groupName = meta.subject || groupId
      } catch {
        groupName = groupId
      }
    }

    if (!durationArg) {
      throw `Masukkan durasi!\n\n` +
        `Contoh: *.addpremgc 30h*\n` +
        DURATION_USAGE
    }

    const duration = parseDuration(durationArg)
    if (!duration) {
      throw `Format durasi tidak valid: *${durationArg}*\n` +
        DURATION_USAGE
    }

    const db = loadDB()
    const now = Date.now()

    if (db[groupId]) {
      const existing = db[groupId]
      const statusText = !existing.expiredAt || existing.expiredAt == 0
        ? 'Permanen'
        : Date.now() > Number(existing.expiredAt)
          ? 'Expired'
          : `Sisa: ${formatRemaining(Number(existing.expiredAt) - now)}`

      throw `Grup *${existing.name || groupId}* sudah terdaftar!\n` +
        `Status: ${statusText}\n\n` +
        `Gunakan *.extendpremgc* untuk perpanjang\n` +
        `atau *.delpremgc* dulu lalu tambah ulang.`
    }

    const expiredAt = duration.permanent ? 0 : now + duration.ms

    db[groupId] = {
      name: groupName,
      addedBy: sender,
      addedAt: now,
      expiredAt: expiredAt,
      duration: durationArg
    }

    saveDB(db)

    const statusLine = duration.permanent
      ? `Durasi: *Permanen*`
      : `Durasi: *${duration.text}*\n` +
        `Expired: ${formatDate(expiredAt)}`

    const teks =
      `*PREMIUM GROUP ACTIVATED*\n\n` +
      `Grup: *${groupName}*\n` +
      `ID: \`${groupId}\`\n` +
      `${statusLine}\n` +
      `Oleh: @${sender.split('@')[0]}\n` +
      `Mulai: ${formatDate(now)}\n\n` +
      `Semua member di grup ini sekarang\n` +
      `dapat menggunakan bot *tanpa limit*!`

    return m.reply(teks, m.chat, { mentions: [sender] })
  }

  // ═══════════════════════════════════════
  //   EXTEND PREMIUM GROUP
  // ═══════════════════════════════════════
  if (['extendpremgc', 'extendpremiumgc', 'addtimepremgc', 'perpanjangpremgc'].includes(command)) {
    if (!isOwnr) throw 'Fitur ini hanya untuk *Owner Bot*.'

    let groupId, groupName, durationArg

    if (m.isGroup) {
      groupId = m.chat
      groupName = groupMetadata?.subject || m.chat
      durationArg = args[0]
    } else {
      if (!args[0]) {
        throw `*Cara Penggunaan:*\n\n` +
          `Di dalam grup:\n` +
          `*.extendpremgc [durasi]*\n\n` +
          `Di private chat:\n` +
          `*.extendpremgc [id_grup] [durasi]*\n` +
          DURATION_USAGE
      }
      groupId = args[0].includes('@') ? args[0] : args[0] + '@g.us'
      durationArg = args[1]
      try {
        const meta = await conn.groupMetadata(groupId)
        groupName = meta.subject || groupId
      } catch {
        groupName = groupId
      }
    }

    if (!durationArg) {
      throw `Masukkan durasi perpanjangan!\n\n` +
        `Contoh: *.extendpremgc 30h*\n` +
        DURATION_USAGE
    }

    const duration = parseDuration(durationArg)
    if (!duration) {
      throw `Format durasi tidak valid: *${durationArg}*\n` +
        DURATION_USAGE
    }

    const db = loadDB()
    const now = Date.now()

    if (!db[groupId]) {
      throw `Grup ini *belum* terdaftar sebagai Premium Group.\n` +
        `Gunakan *.addpremgc* terlebih dahulu.`
    }

    const entry = db[groupId]
    groupName = entry.name || groupName

    if ((!entry.expiredAt || entry.expiredAt == 0) && !duration.permanent) {
      throw `Grup *${groupName}* sudah *Permanen*.\nTidak perlu diperpanjang!`
    }

    if (duration.permanent) {
      const oldStatus = (!entry.expiredAt || entry.expiredAt == 0)
        ? 'Permanen'
        : `${formatRemaining(Math.max(0, Number(entry.expiredAt) - now))}`

      entry.expiredAt = 0
      entry.duration = '0'
      saveDB(db)

      return m.reply(
        `*PREMIUM GROUP > PERMANEN*\n\n` +
        `Grup: *${groupName}*\n` +
        `Sebelumnya: ${oldStatus}\n` +
        `Sekarang: *Permanen*\n` +
        `Oleh: @${sender.split('@')[0]}`,
        m.chat,
        { mentions: [sender] }
      )
    }

    const expAt = Number(entry.expiredAt)
    const base = expAt > now ? expAt : now
    const newExpired = base + duration.ms
    const oldRemaining = expAt > now
      ? formatRemaining(expAt - now)
      : 'Expired'

    entry.expiredAt = newExpired
    entry.duration = (entry.duration || '') + ` +${durationArg}`

    saveDB(db)

    const teks =
      `*PREMIUM GROUP DIPERPANJANG*\n\n` +
      `Grup: *${groupName}*\n` +
      `Sebelumnya: ${oldRemaining}\n` +
      `Ditambah: *${duration.text}*\n` +
      `Sisa sekarang: *${formatRemaining(newExpired - now)}*\n` +
      `Expired baru: ${formatDate(newExpired)}\n` +
      `Oleh: @${sender.split('@')[0]}`

    return m.reply(teks, m.chat, { mentions: [sender] })
  }

  // ═══════════════════════════════════════
  //   REMOVE PREMIUM GROUP
  // ═══════════════════════════════════════
  if (['delpremgc', 'delpremiumgc', 'rempremgc', 'removepremgc'].includes(command)) {
    if (!isOwnr) throw 'Fitur ini hanya untuk *Owner Bot*.'

    let groupId, groupName

    if (m.isGroup) {
      groupId = m.chat
      groupName = groupMetadata?.subject || m.chat
    } else if (args[0]) {
      groupId = args[0].includes('@') ? args[0] : args[0] + '@g.us'
      groupName = groupId
    } else {
      throw `Gunakan di dalam grup atau masukkan ID grup.\n\n` +
        `Contoh:\n*.delpremgc* (di dalam grup)\n*.delpremgc 120363xxxxx@g.us*`
    }

    const db = loadDB()

    if (!db[groupId]) {
      throw `Grup ini *bukan* Premium Group.`
    }

    const oldData = db[groupId]
    groupName = oldData.name || groupName

    const oldStatus = (!oldData.expiredAt || oldData.expiredAt == 0)
      ? 'Permanen'
      : Number(oldData.expiredAt) > Date.now()
        ? `Sisa: ${formatRemaining(Number(oldData.expiredAt) - Date.now())}`
        : 'Expired'

    delete db[groupId]
    saveDB(db)

    const teks =
      `*PREMIUM GROUP DEACTIVATED*\n\n` +
      `Grup: *${groupName}*\n` +
      `ID: \`${groupId}\`\n` +
      `Status sblm dihapus: ${oldStatus}\n` +
      `Dihapus oleh: @${sender.split('@')[0]}\n\n` +
      `Member di grup ini sekarang\n` +
      `kembali menggunakan *sistem limit*.`

    return m.reply(teks, m.chat, { mentions: [sender] })
  }

  // ═══════════════════════════════════════
  //   LIST ALL PREMIUM GROUPS
  // ═══════════════════════════════════════
  if (['listpremgc', 'listpremiumgc', 'premgclist'].includes(command)) {
    if (!isOwnr) throw 'Fitur ini hanya untuk *Owner Bot*.'

    const db = loadDB()
    const groups = Object.keys(db)

    if (!groups.length) {
      return m.reply('Belum ada grup yang terdaftar sebagai *Premium Group*.')
    }

    const now = Date.now()
    let aktif = 0
    let expired = 0
    let permanen = 0
    const mentions = []

    let teks = `*DAFTAR PREMIUM GROUP*\n\n`

    for (let i = 0; i < groups.length; i++) {
      const gid = groups[i]
      const info = db[gid]

      let currentName = info.name || gid
      try {
        const meta = await conn.groupMetadata(gid)
        currentName = meta.subject || currentName
        db[gid].name = currentName
      } catch { }

      let statusText
      if (!info.expiredAt || info.expiredAt == 0) {
        statusText = 'Permanen'
        permanen++
        aktif++
      } else if (now > Number(info.expiredAt)) {
        statusText = 'Expired'
        expired++
      } else {
        const remaining = formatRemaining(Number(info.expiredAt) - now)
        statusText = `Sisa: ${remaining}`
        aktif++
      }

      teks += `*${i + 1}.* ${currentName}\n`
      teks += `   \`${gid}\`\n`
      teks += `   Status: ${statusText}\n`
      teks += `   Ditambahkan: ${formatDate(info.addedAt)}\n`

      if (info.expiredAt && info.expiredAt != 0 && now < Number(info.expiredAt)) {
        teks += `   Expired: ${formatDate(Number(info.expiredAt))}\n`
      }

      teks += `   Oleh: @${info.addedBy.split('@')[0]}\n\n`
      mentions.push(info.addedBy)
    }

    teks += `Total: *${groups.length}* grup\n`
    teks += `Aktif: *${aktif}* | Expired: *${expired}* | Permanen: *${permanen}*\n\n`
    teks += `Gunakan *.delpremgc* untuk hapus expired\n`
    teks += `Gunakan *.cleanpremgc* untuk hapus semua expired`

    saveDB(db)
    return m.reply(teks, m.chat, { mentions })
  }

  // ═══════════════════════════════════════
  //   CLEAN EXPIRED
  // ═══════════════════════════════════════
  if (['cleanpremgc', 'cleanpremiumgc', 'purgepremgc'].includes(command)) {
    if (!isOwnr) throw 'Fitur ini hanya untuk *Owner Bot*.'

    const db = loadDB()
    const now = Date.now()
    const removed = []

    for (const gid of Object.keys(db)) {
      const exp = db[gid].expiredAt
      if (exp && exp != 0 && now > Number(exp)) {
        removed.push({
          id: gid,
          name: db[gid].name || gid
        })
        delete db[gid]
      }
    }

    saveDB(db)

    if (!removed.length) {
      return m.reply('Tidak ada Premium Group yang expired.')
    }

    let teks =
      `*CLEAN UP SELESAI*\n\n` +
      `Berhasil menghapus *${removed.length}* grup expired:\n\n`

    for (let i = 0; i < removed.length; i++) {
      teks += `${i + 1}. ${removed[i].name}\n`
      teks += `   \`${removed[i].id}\`\n\n`
    }

    teks += `Sisa Premium Group: *${Object.keys(db).length}*`

    return m.reply(teks)
  }

  // ═══════════════════════════════════════
  //   CHECK / INFO
  // ═══════════════════════════════════════
  if (['cekpremgc', 'checkpremgc', 'premgc', 'premiumgc', 'infopremgc'].includes(command)) {

    let groupId, groupName

    if (m.isGroup) {
      groupId = m.chat
      groupName = groupMetadata?.subject || m.chat
    } else if (args[0]) {
      groupId = args[0].includes('@') ? args[0] : args[0] + '@g.us'
      try {
        const meta = await conn.groupMetadata(groupId)
        groupName = meta.subject || groupId
      } catch {
        groupName = groupId
      }
    } else {
      throw `Gunakan di dalam grup atau masukkan ID grup.\n\n` +
        `Contoh:\n*.premgc* (di dalam grup)\n*.premgc 120363xxxxx@g.us*`
    }

    const db = loadDB()
    const info = db[groupId]
    const now = Date.now()

    if (!info) {
      return m.reply(
        `*INFO GRUP*\n\n` +
        `Grup: *${groupName}*\n` +
        `Status: *BUKAN PREMIUM*\n\n` +
        `Hubungi owner untuk mengaktifkan\n` +
        `premium group di grup ini.`
      )
    }

    let statusText, extraInfo = ''
    const expAt = Number(info.expiredAt)

    if (!info.expiredAt || info.expiredAt == 0) {
      statusText = '*PERMANEN*'
    } else if (now > expAt) {
      statusText = '*EXPIRED*'
      extraInfo =
        `\nPremium sudah berakhir pada:\n` +
        `${formatDate(expAt)}\n`
    } else {
      const remaining = expAt - now
      statusText = '*AKTIF*'

      const totalDuration = expAt - info.addedAt
      const elapsed = now - info.addedAt
      const percent = Math.max(0, Math.min(100, Math.round((elapsed / totalDuration) * 100)))
      const filled = Math.round(percent / 5)
      const bar = '|'.repeat(filled) + '.'.repeat(20 - filled)

      extraInfo =
        `\nSisa waktu: *${formatRemaining(remaining)}*\n` +
        `Expired: ${formatDate(expAt)}\n` +
        `\n[${bar}] ${percent}%\n`

      if (remaining < 24 * 60 * 60 * 1000) {
        extraInfo += `\n*PERINGATAN:* Premium akan habis\ndalam kurang dari 24 jam!\n`
      }
    }

    const daysSince = Math.floor((now - info.addedAt) / (24 * 60 * 60 * 1000))

    const teks =
      `*PREMIUM GROUP*\n\n` +
      `Grup: *${groupName}*\n` +
      `Status: ${statusText}\n` +
      `Diaktifkan: ${formatDate(info.addedAt)}\n` +
      `Sudah ${daysSince} hari\n` +
      `Oleh: @${info.addedBy.split('@')[0]}` +
      `${extraInfo}\n\n` +
      `Member dapat gunakan bot *tanpa limit*!`

    return m.reply(teks, m.chat, { mentions: [info.addedBy] })
  }
}

// ==================== METADATA ====================

handler.help = [
  'addpremgc',
  'extendpremgc',
  'delpremgc',
  'listpremgc',
  'cleanpremgc',
  'premgc'
]

handler.tags = ['owner', 'group']

handler.command = [
  'addpremgc', 'addpremiumgc', 'setpremgc',
  'extendpremgc', 'extendpremiumgc', 'addtimepremgc', 'perpanjangpremgc',
  'delpremgc', 'delpremiumgc', 'rempremgc', 'removepremgc',
  'listpremgc', 'listpremiumgc', 'premgclist',
  'cleanpremgc', 'cleanpremiumgc', 'purgepremgc',
  'cekpremgc', 'checkpremgc', 'premgc', 'premiumgc', 'infopremgc'
]

export default handler