import fs from 'fs'
import path from 'path'

function isSafePath(p) {
    return !p.includes('..') && !path.isAbsolute(p)
}

function getWIBTime() {
    return new Date().toLocaleString('id-ID', {
        timeZone: 'Asia/Jakarta',
        weekday: 'long',
        day: 'numeric',
        month: 'long',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false
    }) + ' WIB'
}

let handler = async (m, { text, usedPrefix, command, conn }) => {
    const isSave = command === 'sp' || command === 'saveplugin' || command === 'saveplugins'
    const isDelete = command === 'dp' || command === 'delplugin' || command === 'deleteplugin'
    const isGet = command === 'gp' || command === 'getplugin'

    if (!text) {
        throw `
*Parameter Salah!*

Cara penggunaan:
Simpan: *${usedPrefix}sp* <nama_folder/nama_file> (Balas kode/file JS)
Hapus: *${usedPrefix}dp* <nama_folder/nama_file>
Ambil: *${usedPrefix}gp* <nama_folder/nama_file>
Ambil (file): *${usedPrefix}gp* <nama_folder/nama_file> --file

Contoh:
${usedPrefix}sp internet/google (Reply teks kode / file .js)
${usedPrefix}sp menu (Simpan di root plugins)
${usedPrefix}gp menu --file (Kirim sebagai file .js)
`
    }

    let sendAsFile = false
    let cleanText = text.replace(/\s*--file\s*/gi, '').trim()
    if (/--file/i.test(text)) sendAsFile = true

    if (!isSafePath(cleanText)) {
        throw 'Path mencurigakan/tidak valid!'
    }

    let fileName = cleanText.endsWith('.js') ? cleanText : cleanText + '.js'
    let filePath = path.join('plugins', fileName)
    let dirPath = path.dirname(filePath)
    let waktu = getWIBTime()

    try {
        if (isSave) {
            if (!m.quoted) {
                throw 'Mohon balas pesan berisi kode plugin atau file .js yang ingin disimpan!'
            }

            let content = null
            let sourceType = ''
            let fileSize = 0

            let quotedMsg = m.quoted.msg || m.quoted
            let mimetype = quotedMsg?.mimetype || m.quoted?.mimetype || ''

            if (mimetype || m.quoted?.document || quotedMsg?.document) {
                let mediaBuf = await m.quoted.download?.()
                    || await conn.downloadMediaMessage(m.quoted)
                    || await conn.downloadM(m.quoted)

                if (!mediaBuf) {
                    throw 'Gagal mendownload file! Pastikan file masih tersedia.'
                }

                content = mediaBuf
                sourceType = 'Sumber: File Dokumen'
                fileSize = Buffer.byteLength(mediaBuf)
            } else if (m.quoted?.text) {
                content = m.quoted.text
                sourceType = 'Sumber: Teks Reply'
                fileSize = Buffer.byteLength(content, 'utf-8')
            } else {
                throw 'Pesan yang direply tidak berisi kode teks maupun file dokumen!'
            }

            if (!fs.existsSync(dirPath)) {
                fs.mkdirSync(dirPath, { recursive: true })
            }

            fs.writeFileSync(filePath, content)

            let sizeStr = fileSize < 1024
                ? `${fileSize} B`
                : fileSize < 1048576
                    ? `${(fileSize / 1024).toFixed(2)} KB`
                    : `${(fileSize / 1048576).toFixed(2)} MB`

            return m.reply(`
*PLUGIN BERHASIL DISIMPAN*

Lokasi: ${filePath}
Ukuran: ${sizeStr}
${sourceType}
Waktu: ${waktu}
`.trim())
        }

        if (isDelete) {
            if (!fs.existsSync(filePath)) {
                if (fs.existsSync(fileName)) {
                    filePath = fileName
                } else {
                    throw `Plugin *${fileName}* tidak ditemukan!`
                }
            }

            let stats = fs.statSync(filePath)
            let sizeStr = stats.size < 1024
                ? `${stats.size} B`
                : stats.size < 1048576
                    ? `${(stats.size / 1024).toFixed(2)} KB`
                    : `${(stats.size / 1048576).toFixed(2)} MB`

            fs.unlinkSync(filePath)

            try {
                let dir = path.dirname(filePath)
                if (dir !== 'plugins' && fs.existsSync(dir)) {
                    let remaining = fs.readdirSync(dir)
                    if (remaining.length === 0) {
                        fs.rmdirSync(dir)
                    }
                }
            } catch {}

            return m.reply(`
*PLUGIN BERHASIL DIHAPUS*

Lokasi: ${filePath}
Ukuran: ${sizeStr}
Waktu: ${waktu}
`.trim())
        }

        if (isGet) {
            if (!fs.existsSync(filePath)) {
                throw `Plugin *${fileName}* tidak ditemukan!`
            }

            let stats = fs.statSync(filePath)
            let sizeStr = stats.size < 1024
                ? `${stats.size} B`
                : stats.size < 1048576
                    ? `${(stats.size / 1024).toFixed(2)} KB`
                    : `${(stats.size / 1048576).toFixed(2)} MB`

            if (sendAsFile) {
                let fileBuffer = fs.readFileSync(filePath)
                let baseName = path.basename(filePath)

                await conn.sendMessage(m.chat, {
                    document: fileBuffer,
                    mimetype: 'application/javascript',
                    fileName: baseName,
                    caption: `
*PLUGIN FILE*

Lokasi: ${filePath}
Ukuran: ${sizeStr}
Waktu: ${waktu}
`.trim()
                }, { quoted: m })

                return
            }

            let fileContent = fs.readFileSync(filePath, 'utf-8')

            if (fileContent.length > 10000) {
                let fileBuffer = fs.readFileSync(filePath)
                let baseName = path.basename(filePath)

                await conn.sendMessage(m.chat, {
                    document: fileBuffer,
                    mimetype: 'application/javascript',
                    fileName: baseName,
                    caption: `
*PLUGIN FILE* (Terlalu panjang untuk teks)

Lokasi: ${filePath}
Ukuran: ${sizeStr}
Waktu: ${waktu}
`.trim()
                }, { quoted: m })

                return
            }

            return m.reply(`
*PLUGIN: ${path.basename(filePath)}*
Lokasi: ${filePath}
Ukuran: ${sizeStr}
Waktu: ${waktu}

\`\`\`
${fileContent}
\`\`\`
`.trim())
        }

    } catch (e) {
        console.error(e)
        throw `Terjadi kesalahan:\n${e.message || e}`
    }
}

handler.help = ['saveplugin <path>', 'delplugin <path>', 'getplugin <path>']
handler.tags = ['owner']
handler.command = ['sp', 'saveplugin', 'saveplugins', 'dp', 'delplugin', 'deleteplugin', 'gp', 'getplugin']
handler.owner = true

export default handler