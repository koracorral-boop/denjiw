import moment from 'moment-timezone'
import * as levelling from '../lib/levelling.js'

moment.locale('id')

function formatTag(tag) {
  return tag.replace(/[-_]/g, ' ').replace(/\b\w/g, c => c.toUpperCase())
}

function ucapan() {
  const jam = moment.tz('Asia/Jakarta').hour()
  if (jam >= 4 && jam < 11) return 'Selamat Pagi'
  if (jam >= 11 && jam < 15) return 'Selamat Siang'
  if (jam >= 15 && jam < 18) return 'Selamat Sore'
  return 'Selamat Malam'
}

const defaultMenu = {
  before: `
┌ ◦ *[ %me ]*
├ ${ucapan()} %name
│
│ ◦ Uptime : *%uptime*
│ ◦ Limit : *%limit*
│ ◦ Role : *%role*
│ ◦ Level : *%level (%exp / %maxexp)*
│ ◦ Sisa XP Level Up : *%xp4levelup*
│ ◦ %totalexp XP secara Total
│
│ ◦ Note :
│ ◦ *🄿* = Premium
│ ◦ *🄻* = Limit
└────
%readmore
`.trim(),
  header: '╭─「 *%category* 」',
  body: '│ • %cmd',
  footer: '╰────\n',
  after: `> Powered by denji`
}

let handler = async (m, { conn, usedPrefix, command, text }) => {
  try {
    let user = global.db.data.users[m.sender]
    let name = `@${m.sender.split('@')[0]}`
    let botname = conn.user?.name || "Whatsapp Bot"
    let limit = user.premiumTime > 0 ? 'Unlimited' : `${user.limit ?? 10}`
    let exp = user.exp || 0
    let level = user.level || 0
    let role = user.role || 'Beginner'
    let totalexp = user.totalexp || exp
    let { max } = levelling.xpRange(level, global.multiplier || 1)
    let maxexp = max
    let xp4levelup = `${Math.max(max - exp, 0)} XP`
    let uptime = clockString(process.uptime() * 1000)

    let plugins = Object.values(global.plugins || {}).filter(p => !p.disabled)
    let categories = {}

    for (let plugin of plugins) {
      let helps = Array.isArray(plugin.help) ? plugin.help : plugin.help ? [plugin.help] : []
      let tags = Array.isArray(plugin.tags) ? plugin.tags : plugin.tags ? [plugin.tags] : []
      if (tags.length === 0 && helps.length > 0) tags = ['other']
      for (let tag of tags) {
        if (!tag) continue
        if (!categories[tag]) categories[tag] = []
        categories[tag].push({
          helps,
          limit: !!plugin.limit,
          premium: !!plugin.premium,
          prefix: !!plugin.customPrefix
        })
      }
    }

    const readMore = String.fromCharCode(8206).repeat(4001)

    let replace = {
      name, limit, me: botname, role, level, exp,
      maxexp, xp4levelup, totalexp, uptime,
      readmore: readMore, p: usedPrefix
    }

    let menuType = text?.toLowerCase().trim()
    let menuText = []
    let { before, header, body, footer, after } = defaultMenu

    if (!menuType) {
      let list = Object.keys(categories).sort().map(t => `│ • \`${usedPrefix + command} ${t}\``).join('\n')
      menuText = [
        before.replace(/%(\w+)/g, (_, k) => replace[k] || _),
        "╭─「 *DAFTAR MENU* 」",
        `│ • \`${usedPrefix + command} all\``,
        list,
        "╰────\n",
        `Ketik \`${usedPrefix + command} <menu>\``,
        `Contoh: \`${usedPrefix + command} ${Object.keys(categories).sort()[0] || 'all'}\`\n`,
        after
      ]
    } else if (menuType === 'all') {
      menuText.push(before.replace(/%(\w+)/g, (_, k) => replace[k] || _))
      for (let tag of Object.keys(categories).sort()) {
        menuText.push(header.replace('%category', formatTag(tag)))
        for (let item of categories[tag]) {
          for (let cmd of item.helps) {
            let premium = item.premium ? ' (🄿)' : ''
            let lim = item.limit ? ' (🄻)' : ''
            let prefix = item.prefix ? '' : usedPrefix
            menuText.push(body.replace('%cmd', `${prefix}${cmd}${premium}${lim}`))
          }
        }
        menuText.push(footer)
      }
      menuText.push(after)
    } else if (categories[menuType]) {
      menuText.push(before.replace(/%(\w+)/g, (_, k) => replace[k] || _))
      menuText.push(header.replace('%category', formatTag(menuType)))
      for (let item of categories[menuType]) {
        for (let cmd of item.helps) {
          let premium = item.premium ? ' (🄿)' : ''
          let lim = item.limit ? ' (🄻)' : ''
          let prefix = item.prefix ? '' : usedPrefix
          menuText.push(body.replace('%cmd', `${prefix}${cmd}${premium}${lim}`))
        }
      }
      menuText.push(footer)
      menuText.push(after)
    } else {
      let suggestion = Object.keys(categories).find(t => t.includes(menuType) || menuType.includes(t))
      menuText = [`Menu *${text}* tidak ditemukan.`]
      if (suggestion) menuText.push(`Mungkin maksud kamu: *${usedPrefix + command} ${suggestion}*`)
      menuText.push(`Ketik *${usedPrefix + command}* untuk melihat daftar menu.`)
    }

    let finalText = menuText.join('\n').replace(/%(\w+)/g, (_, k) => replace[k] || _)
    await m.reply(finalText)

  } catch (e) {
    console.error(e)
    m.reply("Menu error, coba lagi nanti.")
  }
}

handler.command = ["menu", "help"]
export default handler

function clockString(ms) {
  let h = Math.floor(ms / 3600000)
  let m = Math.floor(ms / 60000) % 60
  let s = Math.floor(ms / 1000) % 60
  return [h, m, s].map(v => String(v).padStart(2, '0')).join(':')
}