const cooldown = 24 * 60 * 60 * 1000

const handler = async (m) => {
  let user = global.db.data.users[m.sender]
  if (!user) {
    user = global.db.data.users[m.sender] = {
      limit: 0,
      lastclaim: 0
    }
  }

  if (typeof user.limit !== 'number') user.limit = 0
  if (typeof user.lastclaim !== 'number') user.lastclaim = 0

  const now = Date.now()
  const elapsed = now - user.lastclaim

  if (elapsed < cooldown) {
    const remaining = cooldown - elapsed
    const hours = Math.floor(remaining / 3600000)
    const minutes = Math.floor((remaining % 3600000) / 60000)
    const seconds = Math.floor((remaining % 60000) / 1000)
    throw `Kamu sudah claim hari ini.\nCoba lagi dalam *${hours} jam ${minutes} menit ${seconds} detik*`
  }

  if (Math.random() < 0.25) {
    user.lastclaim = now
    return m.reply('🎁 *Daily Claim*\nSayang sekali, kamu *zonk* hari ini.')
  }

  const reward = Math.floor(Math.random() * 31) + 20
  user.limit += reward
  user.lastclaim = now

  m.reply(`🎁 *Daily Claim*\nSelamat kamu mendapat *${reward} Limit*\nLimit sekarang: *${user.limit}*`)
}

handler.help = ['claim', 'daily']
handler.tags = ['economy']
handler.command = ['claim', 'daily']

export default handler