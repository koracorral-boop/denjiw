const handler = async (m, { conn, args }) => {
  const users = global.db.data.users
  const botNumber = conn.user.jid
  
  // Tentukan tipe leaderboard (default: money)
  const type = ['limit', 'lim', 'l'].includes(args[0]?.toLowerCase()) ? 'limit' : 'money'
  
  // Mengambil dan mengurutkan user (exclude bot)
  const leaderboard = Object.entries(users)
    .filter(([jid]) => jid !== botNumber)
    .map(([jid, data]) => ({
      jid,
      money: data.money || 0,
      limit: data.limit || 0
    }))
    .sort((a, b) => b[type] - a[type])
    .slice(0, 10) // Top 10
  
  if (leaderboard.length === 0) {
    return m.reply('Belum ada data leaderboard.')
  }
  
  const title = type === 'money' ? '💰 MONEY' : '⚡ LIMIT'
  let text = `🏆 *LEADERBOARD ${title} TOP 10* 🏆\n\n`
  
  const medals = ['🥇', '🥈', '🥉']
  
  leaderboard.forEach((user, index) => {
    const medal = medals[index] || `${index + 1}.`
    const name = user.jid.split('@')[0]
    const value = user[type].toLocaleString()
    text += `${medal} @${name}\n`
    text += `   ${type === 'money' ? '💰' : '⚡'} ${type.charAt(0).toUpperCase() + type.slice(1)}: ${value}\n\n`
  })
  
  m.reply(text, m.chat, { mentions: leaderboard.map(u => u.jid) })
}

handler.help = ['leaderboard [money/limit]', 'lb [money/limit]']
handler.tags = ['economy']
handler.command = ['leaderboard', 'lb']

export default handler