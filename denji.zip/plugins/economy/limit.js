const handler = async (m) => {
  let who = m.isGroup && m.mentionedJid[0] ? m.mentionedJid[0] : m.sender
  const user = global.db.data.users[who]
  m.reply(`@${who.split('@')[0]} mempunyai:
• Limit: ${user?.limit || 0}
• Money: ${user?.money || 0}`, m.chat, { mentions: [who] })
}

handler.help = ['limit [@user]']
handler.tags = ['economy']
handler.command = ['limit']

export default handler