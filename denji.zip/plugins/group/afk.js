import { promises as fs } from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)
const DB_PATH = path.resolve(__dirname, '../../database/afk.json')
const linkRegex = /chat\.whatsapp\.com\/(?:invite\/)?([0-9A-Za-z]{20,24})/i

async function readDb() {
  try {
    const raw = await fs.readFile(DB_PATH, 'utf-8')
    return JSON.parse(raw)
  } catch {
    return {}
  }
}

async function writeDb(data) {
  try {
    const tmpPath = `${DB_PATH}.tmp`
    await fs.writeFile(tmpPath, JSON.stringify(data, null, 2))
    await fs.rename(tmpPath, DB_PATH)
  } catch {
    await fs.writeFile(DB_PATH, JSON.stringify(data, null, 2))
  }
}

function formatDuration(ms) {
  const s = Math.floor(ms / 1000)
  const h = Math.floor(s / 3600)
  const m = Math.floor((s % 3600) / 60)
  const sec = s % 60
  const parts = []
  if (h > 0) parts.push(`${h} jam`)
  if (m > 0) parts.push(`${m} menit`)
  if (sec > 0 || parts.length === 0) parts.push(`${sec} detik`)
  return parts.join(' ')
}

// ═══════════════════════════════════════════════════════
//  ANTI-FORBIDDEN: Fetch grup dengan retry + fallback
// ═══════════════════════════════════════════════════════
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms))

/**
 * Coba fetch semua grup, dengan retry + exponential backoff
 * Return: Set of group JIDs atau null jika gagal total
 */
async function fetchBotGroups(conn, maxRetry = 3) {
  for (let attempt = 1; attempt <= maxRetry; attempt++) {
    try {
      const groups = await conn.groupFetchAllParticipating()
      return new Set(Object.keys(groups))
    } catch (err) {
      const isForbidden = /forbidden|403|rate/i.test(err?.message || String(err))
      const isTimeout = /timed?\s?out|ETIMEOUT/i.test(err?.message || String(err))

      console.log(
        `[AFK CLEANUP] ⚠️ Attempt ${attempt}/${maxRetry} gagal: ${err.message || err}`
      )

      if (attempt < maxRetry && (isForbidden || isTimeout)) {
        const wait = attempt * 10000 // 10s, 20s, 30s
        console.log(`[AFK CLEANUP] ⏳ Retry dalam ${wait / 1000}s...`)
        await delay(wait)
      }
    }
  }
  return null
}

/**
 * Fallback: cek satu per satu grup via groupMetadata
 * Lebih lambat tapi tidak kena forbidden
 */
async function checkGroupsIndividually(conn, chatIds) {
  const activeGroups = new Set()

  for (const chatId of chatIds) {
    if (!chatId.endsWith('@g.us')) continue

    try {
      await conn.groupMetadata(chatId)
      activeGroups.add(chatId)
    } catch (err) {
      const isNotFound = /not-authorized|forbidden|404|item-not-found/i.test(
        err?.message || String(err)
      )

      if (isNotFound) {
        // Bot sudah tidak di grup ini
        console.log(`[AFK CLEANUP] 🚫 Bot tidak di grup: ${chatId}`)
      } else {
        // Error lain (network dll) → asumsikan masih ada, jangan hapus
        activeGroups.add(chatId)
        console.log(`[AFK CLEANUP] ❓ Tidak bisa cek ${chatId}: ${err.message}`)
      }
    }

    // Jeda antar request agar tidak rate-limited
    await delay(1500)
  }

  return activeGroups
}

// ═══════════════════════════════════════════════════════
//  CLEANUP SCHEDULER — Jam 00:00 WIB
// ═══════════════════════════════════════════════════════
let cleanupTimer = null
let connInstance = null

function msUntilMidnightWIB() {
  const now = new Date()
  const wibParts = new Intl.DateTimeFormat('en-US', {
    timeZone: 'Asia/Jakarta',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
  }).formatToParts(now)

  const get = (type) => parseInt(wibParts.find(p => p.type === type).value)
  const elapsed = get('hour') * 3600 + get('minute') * 60 + get('second')
  return ((86400 - elapsed) * 1000) + 5000
}

async function cleanupAfkData() {
  try {
    if (!connInstance) {
      console.log('[AFK CLEANUP] ⚠️ Tidak ada koneksi, skip')
      return
    }

    // Cek koneksi aktif
    if (!connInstance.user?.id) {
      console.log('[AFK CLEANUP] ⚠️ Koneksi belum siap, skip')
      return
    }

    const db = await readDb()
    const chatIds = Object.keys(db).filter(id => id.endsWith('@g.us'))

    if (chatIds.length === 0) {
      console.log('[AFK CLEANUP] ✅ Tidak ada data grup AFK')
      return
    }

    console.log(`[AFK CLEANUP] 🔍 Mengecek ${chatIds.length} grup...`)

    // Strategi 1: Fetch semua sekaligus (cepat)
    let botGroups = await fetchBotGroups(connInstance)

    // Strategi 2: Fallback per-grup jika fetch semua gagal
    if (botGroups === null) {
      console.log('[AFK CLEANUP] 🔄 Fallback: cek grup satu per satu...')
      botGroups = await checkGroupsIndividually(connInstance, chatIds)
    }

    let removedCount = 0
    let removedGroups = []

    for (const chatId of chatIds) {
      if (!botGroups.has(chatId)) {
        const userCount = Object.keys(db[chatId]).length
        removedGroups.push(`${chatId} (${userCount} users)`)
        delete db[chatId]
        removedCount++
      }
    }

    if (removedCount > 0) {
      await writeDb(db)
      console.log(
        `[AFK CLEANUP] 🧹 Dihapus ${removedCount} grup:\n` +
        removedGroups.map(g => `  - ${g}`).join('\n')
      )
    } else {
      console.log('[AFK CLEANUP] ✅ Semua data valid, tidak ada yang dihapus')
    }
  } catch (err) {
    console.log('[AFK CLEANUP] ❌ Error:', err.message || err)
  }
}

function scheduleNextCleanup() {
  if (cleanupTimer) clearTimeout(cleanupTimer)

  const ms = msUntilMidnightWIB()
  const nextRunWIB = new Date(Date.now() + ms)
    .toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })

  console.log(`[AFK CLEANUP] ⏰ Jadwal berikutnya: ${nextRunWIB} WIB`)

  cleanupTimer = setTimeout(async () => {
    console.log('[AFK CLEANUP] 🕛 Cleanup 00:00 WIB dimulai...')
    await cleanupAfkData()
    scheduleNextCleanup()
  }, ms)

  if (cleanupTimer.unref) cleanupTimer.unref()
}

scheduleNextCleanup()

// ═══════════════════════════════════════════════════════
//  COMMAND — .afk [alasan]
// ═══════════════════════════════════════════════════════
let handler = async (m, { conn, text: txt }) => {
  connInstance = conn

  const afkData = await readDb()
  if (!afkData[m.chat]) afkData[m.chat] = {}

  const isGroupLink = linkRegex.exec(txt)
  const reason = txt
    ? (afkData[m.chat].antiLinkGc && isGroupLink ? 'Terdeteksi mengirim link grup' : txt)
    : ''
  const cutReason = reason.length > 100 ? reason.slice(0, 100) + '...' : reason

  const userName = global.db?.data?.users?.[m.sender]?.name || (await conn.getName(m.sender))

  afkData[m.chat][m.sender] = {
    afk: Date.now(),
    afkReason: cutReason || 'Tidak disebutkan',
    name: userName
  }

  await writeDb(afkData)

  let msg = `*🚩 @${m.sender.split('@')[0]} is now AFK!*`
  if (cutReason) msg += `\n*Reason: ${cutReason}*`

  await conn.sendMessage(m.chat, {
    text: msg,
    mentions: [m.sender]
  }, { quoted: m })
}

handler.help = ['afk [alasan]']
handler.tags = ['group']
handler.command = ['afk']
handler.group = true

// ═══════════════════════════════════════════════════════
//  BEFORE — Deteksi kembali & mention user AFK
// ═══════════════════════════════════════════════════════
handler.before = async function (m) {
  if (m.isBaileys || m.fromMe) return false

  const botJid = this.user?.jid || this.user?.id
  if (botJid && (m.sender === botJid || m.sender === botJid.replace(/:\d+/, ''))) return false
  if (!m.chat?.endsWith('@g.us') || !m.sender) return false

  connInstance = this

  const db = await readDb()
  if (!db[m.chat]) return false

  let needWrite = false

  const senderData = db[m.chat][m.sender]
  if (senderData && typeof senderData.afk === 'number' && senderData.afk > 0) {
    const duration = formatDuration(Date.now() - senderData.afk)
    const reason = senderData.afkReason || 'Tidak disebutkan'

    try {
      await this.sendMessage(m.chat, {
        text: `*@${m.sender.split('@')[0]} telah kembali dari afk selama*\n\n${duration}\n\n*Reason :* ${reason}`,
        mentions: [m.sender]
      }, { quoted: m })
    } catch {}

    delete db[m.chat][m.sender]
    needWrite = true
  }

  const jids = new Set([
    ...(m.mentionedJid || []),
    ...(m.quoted?.sender ? [m.quoted.sender] : []),
  ])

  if (jids.size > 0) {
    let afkUsers = []

    for (const jid of jids) {
      if (jid === m.sender) continue
      if (botJid && (jid === botJid || jid === botJid.replace(/:\d+/, ''))) continue

      const userData = db[m.chat][jid]
      if (userData && typeof userData.afk === 'number' && userData.afk > 0) {
        afkUsers.push({
          jid,
          name: userData.name || jid.split('@')[0],
          reason: userData.afkReason || 'Tidak disebutkan',
          duration: formatDuration(Date.now() - userData.afk)
        })
      }
    }

    if (afkUsers.length > 0) {
      try {
        let afkMsg = '*User sedang AFK:*\n\n'
        afkUsers.forEach((u, i) => {
          afkMsg += `${i + 1}. @${u.jid.split('@')[0]}\n`
          afkMsg += `Alasan: ${u.reason}\n`
          afkMsg += `Sejak: ${u.duration}\n\n`
        })

        await this.sendMessage(m.chat, {
          text: afkMsg.trim(),
          mentions: afkUsers.map(u => u.jid)
        }, { quoted: m })
      } catch {}
    }
  }

  if (needWrite) await writeDb(db)
  return false
}

export default handler