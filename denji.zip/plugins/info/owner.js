let handler = async (m, { conn }) => {
    // Mengambil data owner dari global.owner
    let ownerList = global.owner.filter(v => v !== undefined)
    
    let list = []
    for (let i of ownerList) {
        // i[0] = Nomor, i[1] = Nama
        list.push({
            displayName: i[1],
            vcard: `BEGIN:VCARD\nVERSION:3.0\nN:${i[1]}\nFN:${i[1]}\nitem1.TEL;waid=${i[0]}:${i[0]}\nitem1.X-ABLabel:Ponsel\nitem2.EMAIL;type=INTERNET:owner@example.com\nitem2.X-ABLabel:Email\nEND:VCARD`
        })
    }

    // Mengirim kontak
    await conn.sendMessage(m.chat, {
        contacts: {
            displayName: `${list.length} Kontak`,
            contacts: list
        }
    }, { quoted: m })
}
    
handler.command = ["owner", "creator"]

export default handler