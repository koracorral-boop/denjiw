import os from 'os'
import { performance } from 'perf_hooks'

function formatBytes(bytes, decimals = 1) {
  if (bytes === 0) return '0 B'
  const k = 1024
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB']
  const i = Math.floor(Math.log(bytes) / Math.log(k))
  return parseFloat((bytes / Math.pow(k, i)).toFixed(decimals)) + ' ' + sizes[i]
}

function formatUptime(seconds) {
  seconds = Number(seconds)
  const h = Math.floor(seconds / 3600)
  const m = Math.floor(seconds % 3600 / 60)
  const s = Math.floor(seconds % 60)
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`
}

function getCpuUsage() {
  const cpus = os.cpus()
  let idle = 0, total = 0
  for (const cpu of cpus) {
    for (const type in cpu.times) total += cpu.times[type]
    idle += cpu.times.idle
  }
  return (1 - idle / total)
}

let handler = async (m, { conn }) => {
  const start = performance.now()
  await conn.sendMessage(m.chat, { react: { text: '📊', key: m.key } })

  const cpus = os.cpus()
  const cpuModel = cpus[0].model.trim()
  const cpuSpeed = cpus[0].speed
  const cpuCores = cpus.length

  const totalMem = os.totalmem()
  const freeMem = os.freemem()
  const usedMem = totalMem - freeMem

  const memNode = process.memoryUsage()

  const sysUptime = os.uptime()
  const loadAvg = os.loadavg()

  const latencyVal = performance.now() - start
  const latency = latencyVal.toFixed(0)

  const text =
`Response Time *${latency} miliseconds*

≡ *BOT STATS*
▸ Uptime : *${formatUptime(process.uptime())}*
▸ RAM    : *${formatBytes(memNode.rss)}* (Resident)
▸ Heap   : *${formatBytes(memNode.heapUsed)}* / ${formatBytes(memNode.heapTotal)}

≡ *SERVER STATS*
▸ CPU    : *${cpuCores}* Core (${cpuModel})
▸ Load   : *${loadAvg[0].toFixed(2)}* (1m)
▸ RAM    : *${formatBytes(usedMem)}* / ${formatBytes(totalMem)}
▸ OS     : *${os.type().toUpperCase()}* ${os.arch()} (Uptime: ${formatUptime(sysUptime)})
▸ Node   : *${process.version}*`

  await conn.sendMessage(m.chat, { text }, { quoted: m })
}

handler.command = ['ping', 'speed', 'info', 'stats']
handler.tags = ['main']
handler.help = ['ping']

export default handler