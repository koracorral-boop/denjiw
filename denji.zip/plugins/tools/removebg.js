let handler = async (m, { conn, command, usedPrefix, isOwner }) => {
    const q = m.quoted && m.quoted.mimetype ? m.quoted : m;
    const mime = (q.msg || q).mimetype || "";

    if (!q || typeof q.download !== "function" || !/image\/(jpe?g|png|webp)/i.test(mime)) {
        return m.reply(
            `Please send or reply to an image.\nExample: ${usedPrefix}${command} (reply image)`
        );
    }

    try {
        // React jam (loading)
        await conn.sendMessage(m.chat, {
            react: { text: "🕐", key: m.key }
        });

        const img = await q.download().catch(() => null);
        if (!img || !(img instanceof Buffer)) {
            throw new Error("Invalid image buffer");
        }

        const imageUrl = await uploadImage(img);
        if (!imageUrl) {
            throw new Error("Failed to upload image");
        }

        const resultBuffer = await removeBg(imageUrl);
        if (!resultBuffer) {
            throw new Error("Remove background failed");
        }

        await conn.sendMessage(
            m.chat,
            {
                image: resultBuffer,
                caption: "Background removed successfully.",
            },
            { quoted: m }
        );

        // React centang (done)
        await conn.sendMessage(m.chat, {
            react: { text: "✅", key: m.key }
        });
    } catch (e) {
        // React silang (error)
        await conn.sendMessage(m.chat, {
            react: { text: "❌", key: m.key }
        });

        if (isOwner) {
            const errorLog = [
                `⚠️ *ERROR LOG*`,
                ``,
                `*Command:* ${usedPrefix}${command}`,
                `*Chat:* ${m.chat}`,
                `*Sender:* ${m.sender}`,
                `*Time:* ${new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })}`,
                ``,
                `*Error Name:* ${e?.name || "Unknown"}`,
                `*Error Message:* ${e?.message || "No message"}`,
                ``,
                `*Stack Trace:*`,
                `\`\`\``,
                `${e?.stack || "No stack trace available"}`,
                `\`\`\``,
            ].join("\n");

            m.reply(errorLog);
        } else {
            m.reply("Failed to remove background.");
        }

        global.logger?.error?.(e);
    }
};

handler.help = ["removebg"];
handler.tags = ["tools"];
handler.command = ["removebg", "nobg"];

export default handler;

/* ================= HELPER ================= */

// Upload image menggunakan tmpfiles.org
async function uploadImage(buffer) {
    try {
        const formData = new FormData();
        formData.append('file', new Blob([buffer], { type: 'image/jpeg' }), 'image.jpg');

        const res = await fetch('https://tmpfiles.org/api/v1/upload', {
            method: 'POST',
            body: formData
        });

        if (!res.ok) return null;

        const json = await res.json();
        if (!json?.data?.url) return null;

        // Ubah URL agar jadi direct link
        // https://tmpfiles.org/123456/image.jpg → https://tmpfiles.org/dl/123456/image.jpg
        const directUrl = json.data.url.replace('tmpfiles.org/', 'tmpfiles.org/dl/');
        return directUrl;
    } catch {
        return null;
    }
}

// Remove background using API
async function removeBg(imageUrl) {
    try {
        const apiUrl = `https://api.azbry.my.id/api/tools/removebg?url=${encodeURIComponent(imageUrl)}`;
        const res = await fetch(apiUrl);

        if (!res.ok) return null;

        const buffer = Buffer.from(await res.arrayBuffer());
        return buffer;
    } catch {
        return null;
    }
}