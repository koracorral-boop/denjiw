import { readFileSync, writeFileSync, unlinkSync, existsSync, mkdirSync } from 'fs'
import path from 'path'
import { exec } from 'child_process'
import { fileURLToPath } from 'url'
import crypto from 'crypto'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)
const TMP_DIR = path.join(__dirname, '../../tmp')

// Ensure tmp directory exists
if (!existsSync(TMP_DIR)) {
  mkdirSync(TMP_DIR, { recursive: true })
}

// Helper function to generate random filename
function generateFilename(ext) {
  return `${Date.now()}_${crypto.randomBytes(4).toString('hex')}.${ext}`
}

// Helper function to download media
async function downloadMedia(conn, quoted) {
  try {
    let buffer

    if (typeof quoted.download === 'function') {
      buffer = await quoted.download()
    } else if (typeof conn.downloadMediaMessage === 'function') {
      buffer = await conn.downloadMediaMessage(quoted)
    } else if (typeof conn.downloadM === 'function') {
      buffer = await conn.downloadM(quoted)
    } else if (quoted.msg) {
      const { downloadContentFromMessage } = await import('baileys')
      const stream = await downloadContentFromMessage(quoted.msg, 'sticker')
      const chunks = []
      for await (const chunk of stream) {
        chunks.push(chunk)
      }
      buffer = Buffer.concat(chunks)
    } else {
      throw new Error('No download method available')
    }

    if (!buffer || buffer.length === 0) {
      throw new Error('Buffer kosong setelah download')
    }

    return buffer
  } catch (err) {
    throw new Error(`Gagal download media: ${err.message}`)
  }
}

// Main handler
let handler = async (m, { conn }) => {
  // Check if quoted message exists
  if (!m.quoted) {
    return m.reply('*🚩 Reply sticker yang ingin diubah ke gambar (tidak support sticker animasi).*')
  }

  // Check if it's a webp sticker
  const mimetype = m.quoted.mimetype || m.quoted.msg?.mimetype || ''
  if (!mimetype.includes('webp')) {
    return m.reply('*🚩 Reply sticker yang ingin diubah ke gambar (tidak support sticker animasi).*')
  }

  try {
    // Send processing reaction
    await conn.sendMessage(m.chat, { react: { text: '🕒', key: m.key } })

    // Download sticker
    const buffer = await downloadMedia(conn, m.quoted)

    // Generate temp file paths
    const inputFile = path.join(TMP_DIR, generateFilename('webp'))
    const outputFile = path.join(TMP_DIR, generateFilename('png'))

    // Write buffer to temp file
    writeFileSync(inputFile, buffer)

    // Convert using ffmpeg
    exec(`ffmpeg -i "${inputFile}" "${outputFile}"`, async (err) => {
      // Clean up input file
      if (existsSync(inputFile)) {
        try { unlinkSync(inputFile) } catch {}
      }

      if (err) {
        return m.reply('*🚩 Konversi gagal. Pastikan sticker bukan animasi.*')
      }

      try {
        // Check if output exists
        if (!existsSync(outputFile)) {
          return m.reply('*🚩 Konversi gagal. File output tidak ditemukan.*')
        }

        const imageBuffer = readFileSync(outputFile)

        // Send image
        await conn.sendMessage(m.chat, {
          image: imageBuffer,
          caption: ''
        }, { quoted: m })

        // Send success reaction
        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } })

      } catch (e) {
        m.reply(`*🚩 Error: ${e.message}*`)
      } finally {
        // Clean up output file
        if (existsSync(outputFile)) {
          try { unlinkSync(outputFile) } catch {}
        }
      }
    })

  } catch (e) {
    await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
    m.reply(`*🚩 Error: ${e.message}*`)
  }
}

handler.help = ['toimg']
handler.tags = ['tools']
handler.command = ['toimg', 'toimage']

export default handler