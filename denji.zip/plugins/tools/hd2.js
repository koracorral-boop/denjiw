import { fileTypeFromBuffer } from 'file-type'

async function uploadToTempfiles(buffer) {
    const type = await fileTypeFromBuffer(buffer) || { mime: 'image/png', ext: 'png' }
    
    const uploaders = [
        async () => {
            const form = new FormData()
            const blob = new Blob([buffer], { type: type.mime })
            form.append('file', blob, `image.${type.ext}`)
            form.append('expires', '1d')
            const res = await fetch('https://tempfiles.org/api/upload', { method: 'POST', body: form })
            const json = await res.json()
            return json?.data?.url || json?.url
        },
        async () => {
            const form = new FormData()
            const blob = new Blob([buffer], { type: type.mime })
            form.append('file', blob, `image.${type.ext}`)
            const res = await fetch('https://tmpfiles.org/api/v1/upload', { method: 'POST', body: form })
            const json = await res.json()
            return json?.data?.url?.replace('tmpfiles.org/', 'tmpfiles.org/dl/')
        },
        async () => {
            const form = new FormData()
            const blob = new Blob([buffer], { type: type.mime })
            form.append('file', blob, `image.${type.ext}`)
            const res = await fetch('https://file.io', { method: 'POST', body: form })
            const json = await res.json()
            return json?.link
        }
    ]
    
    for (const uploader of uploaders) {
        try {
            const url = await uploader()
            if (url) return url
        } catch {}
    }
    
    return null
}

async function remini(imageUrl, apikey) {
    try {
        const response = await fetch(`https://anabot.my.id/api/ai/remini?imageUrl=${encodeURIComponent(imageUrl)}&apikey=${encodeURIComponent(apikey)}`, {
            method: 'GET',
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        })
        
        if (!response.ok) {
            throw new Error(`HTTP Error ${response.status}`)
        }
        
        const data = await response.json()
        return data
    } catch (error) {
        return { 
            success: false, 
            error: error.message 
        }
    }
}

let handler = async (m, { conn, command, usedPrefix }) => {
    const q = m.quoted && m.quoted.mimetype ? m.quoted : m
    const mime = (q.msg || q).mimetype || ""
    
    if (!q || typeof q.download !== "function" || !/image\/(jpe?g|png|webp)/i.test(mime)) {
        return m.reply(
            `*Remini HD Enhancement*\n\n` +
            `Cara Penggunaan:\n` +
            `Kirim/reply gambar dengan caption:\n` +
            `${usedPrefix}${command}\n\n` +
            `Format yang didukung:\n` +
            `JPG, JPEG, PNG, WEBP`
        )
    }
    
    try {
        // Mencatat waktu mulai proses
        const startTime = Date.now();

        if (global.loading) {
            await global.loading(m, conn)
        }
        
        const media = await q.download().catch(() => null)
        
        if (!media || !Buffer.isBuffer(media)) {
            throw new Error("Invalid image buffer")
        }
        
        const uploadedUrl = await uploadToTempfiles(media)
        
        if (!uploadedUrl) {
            throw new Error("Failed to upload image")
        }
        
        const result = await remini(uploadedUrl, 'freeApikey')
        
        if (!result.success) {
            throw new Error(result.error || "Enhancement failed")
        }
        
        const enhancedImageUrl = result.data?.result
        
        if (!enhancedImageUrl) {
            throw new Error("No enhanced image URL in response")
        }
        
        // Menghitung total waktu (download, upload, processing API)
        const fetchTime = Date.now() - startTime;

        await conn.sendMessage(
            m.chat,
            {
                image: { url: enhancedImageUrl },
                caption: `🍟 *Fetching* : ${fetchTime} ms` // Mengubah caption sesuai permintaan
            },
            { quoted: m }
        )
        
        if (global.loading) {
            await global.loading(m, conn, true)
        }
        
    } catch (error) {
        if (global.loading) {
            await global.loading(m, conn, true)
        }
        
        if (global.logger && global.logger.error) {
            global.logger.error(error)
        }
        
        let userMessage = 'Gagal meng-enhance gambar.\n\n'
        
        if (error.message.includes('upload')) {
            userMessage += 'Gagal mengupload gambar ke server'
        } else if (error.message.includes('buffer')) {
            userMessage += 'Format gambar tidak valid'
        } else if (error.message.includes('429')) {
            userMessage += 'Rate limit tercapai, coba lagi nanti'
        } else {
            userMessage += error.message
        }
        
        m.reply(userMessage)
    }
}

handler.help = ["hd2", "remini2", "enhance"]
handler.tags = ["tools"]
handler.command = ["hd2", "remini2", "enhance"]
handler.limit = 1

export default handler