import fs from 'fs';
import { tmpdir } from 'os';
import { execFile } from 'child_process';
import Crypto from 'crypto';
import webp from 'node-webpmux';
import path from 'path';

const temp = process.platform === 'win32' ? process.env.TEMP : tmpdir();

// ═══════════════════════════════════════════
//  HELPER: Jalankan ffmpeg tanpa fluent-ffmpeg
// ═══════════════════════════════════════════

function runFFmpeg(args) {
    return new Promise((resolve, reject) => {
        execFile('ffmpeg', args, { timeout: 60000 }, (error, stdout, stderr) => {
            if (error) {
                reject(new Error(`ffmpeg error: ${error.message}\n${stderr}`));
            } else {
                resolve(true);
            }
        });
    });
}

// ═══════════════════════════════════════════
//  EXIF UTILITIES (built-in)
// ═══════════════════════════════════════════

async function imageToWebp(media) {
    const tmpFileIn = path.join(temp, `${Crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.${media?.ext || 'png'}`);
    const tmpFileOut = path.join(temp, `${Crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`);
    fs.writeFileSync(tmpFileIn, media.data);
    try {
        await runFFmpeg([
            '-y',
            '-i', tmpFileIn,
            '-vcodec', 'libwebp',
            '-sws_flags', 'lanczos',
            '-vf',
            'scale=512:512:force_original_aspect_ratio=decrease,format=rgba,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=white@0.0',
            '-f', 'webp',
            tmpFileOut,
        ]);
        fs.promises.unlink(tmpFileIn);
        const buff = fs.readFileSync(tmpFileOut);
        fs.promises.unlink(tmpFileOut);
        return buff;
    } catch (e) {
        fs.existsSync(tmpFileIn) && fs.promises.unlink(tmpFileIn);
        fs.existsSync(tmpFileOut) && fs.promises.unlink(tmpFileOut);
        throw e;
    }
}

async function videoToWebp(media) {
    const tmpFileIn = path.join(temp, `${Crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.${media?.ext || 'mp4'}`);
    const tmpFileOut = path.join(temp, `${Crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`);
    fs.writeFileSync(tmpFileIn, media.data);
    try {
        await runFFmpeg([
            '-y',
            '-i', tmpFileIn,
            '-vcodec', 'libwebp',
            '-sws_flags', 'lanczos',
            '-vf',
            'scale=512:512:force_original_aspect_ratio=decrease,format=rgba,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=white@0.0,fps=15',
            '-loop', '0',
            '-ss', '00:00:00',
            '-t', '00:00:10',
            '-preset', 'default',
            '-an',
            '-vsync', '0',
            '-f', 'webp',
            tmpFileOut,
        ]);
        fs.promises.unlink(tmpFileIn);
        const buff = fs.readFileSync(tmpFileOut);
        fs.promises.unlink(tmpFileOut);
        return buff;
    } catch (e) {
        fs.existsSync(tmpFileIn) && fs.promises.unlink(tmpFileIn);
        fs.existsSync(tmpFileOut) && fs.promises.unlink(tmpFileOut);
        throw e;
    }
}

async function writeExif(media, metadata) {
    let wMedia = /webp/.test(media.mimetype)
        ? media.data
        : /image/.test(media.mimetype)
        ? await imageToWebp(media)
        : /video/.test(media.mimetype)
        ? await videoToWebp(media)
        : '';

    if (metadata && Object.keys(metadata).length !== 0) {
        const img = new webp.Image();
        const json = {
            'sticker-pack-id': metadata?.packId || `CustomWM-${Date.now()}`,
            'sticker-pack-name': metadata?.packName || '',
            'sticker-pack-publisher': metadata?.packPublish || '',
            'android-app-store-link': metadata?.androidApp || '',
            'ios-app-store-link': metadata?.iOSApp || '',
            emojis: metadata?.emojis || ['😎'],
            'is-avatar-sticker': metadata?.isAvatar || 0,
        };
        const exifAttr = Buffer.from([
            0x49, 0x49, 0x2a, 0x00, 0x08, 0x00, 0x00, 0x00,
            0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x16, 0x00, 0x00, 0x00,
        ]);
        const jsonBuff = Buffer.from(JSON.stringify(json), 'utf-8');
        const exif = Buffer.concat([exifAttr, jsonBuff]);
        exif.writeUIntLE(jsonBuff.length, 14, 4);
        await img.load(wMedia);
        img.exif = exif;
        return await img.save(null);
    }
}

// ═══════════════════════════════════════════
//  HANDLER
// ═══════════════════════════════════════════

let handler = async (m, { conn, args, usedPrefix, command }) => {
    try {
        // ─── Validasi: harus reply stiker ───
        const q = m.quoted ? m.quoted : m;
        const mime = (q.msg || q).mimetype || q.mediaType || '';

        if (!/webp/.test(mime)) {
            return m.reply(
                `⚠️ *Reply sebuah stiker!*\n\n` +
                `📌 *Cara pakai:*\n` +
                `• ${usedPrefix + command} packname|author\n` +
                `• ${usedPrefix + command} packname\n` +
                `• ${usedPrefix + command} |author\n\n` +
                `_Reply stiker yang ingin diganti watermark-nya._`
            );
        }

        // ─── Reaction loading ───
        await conn.sendMessage(m.chat, { react: { text: '🕐', key: m.key } });

        // ─── Download stiker ───
        const media = await q.download();
        if (!media || !Buffer.isBuffer(media)) {
            throw new Error('Gagal mengunduh stiker. Coba lagi.');
        }

        // ─── Parsing args: packname | author ───
        let packname = '';
        let author = '';

        if (args.length > 0) {
            const text = args.join(' ').trim();
            if (text.includes('|')) {
                const parts = text.split('|');
                packname = parts[0]?.trim() || '';
                author   = parts[1]?.trim() || '';
            } else {
                packname = text;
                author   = '';
            }
        }

        // ─── Tulis EXIF baru langsung ───
        const stickerBuffer = await writeExif(
            { data: media, mimetype: 'image/webp' },
            {
                packName:    packname,
                packPublish: author,
                packId:      `CustomWM-${Date.now()}`,
                emojis:      ['😎'],
            }
        );

        if (!stickerBuffer) {
            throw new Error('Gagal menulis metadata EXIF ke stiker.');
        }

        // ─── Kirim stiker hasil ───
        await conn.sendMessage(
            m.chat,
            { sticker: stickerBuffer },
            { quoted: m }
        );

        // ─── Reaction sukses ───
        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (e) {
        console.error('[Ganti WM Error]:', e);
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        await m.reply(`❌ *Terjadi Kesalahan:*\n${e.message}`);
    }
};

handler.help    = ['wm packname|author', 'wm packname', 'wm |author'];
handler.tags    = ['tools'];
handler.command = ['gantiwm', 'swm', 'changewm', 'wm', 'stealsticker', 'rewm'];
handler.limit   = true;

export default handler;