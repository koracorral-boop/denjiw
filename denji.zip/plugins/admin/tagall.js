let handler = async (m, { conn, text, participants }) => {
    const fallbackText = (
        m.quoted?.text ||
        m.quoted?.caption ||
        m.quoted?.message?.extendedTextMessage?.text ||
        m.quoted?.message?.conversation ||
        ''
    ).trim()
    const msgText = (text || '').trim() || fallbackText

    const users = participants.map(u => u.id).filter(v => v !== conn.user.jid)
    const body = users.map(v => '• @' + v.replace(/@.+/, '')).join('\n')
    
    const header = '*[ TAG ALL ]*'
    const textContent = msgText || ''
    const content = `${header}\n\n${textContent}\n\n${body}`

    await conn.reply(
        m.chat,
        content,
        m,
        { contextInfo: { mentionedJid: users } }
    )
}

handler.help = ['tagall']
handler.tags = ['admin']
handler.command = ["tagall", "tag-all"]
handler.admin = handler.group = true

export default handler