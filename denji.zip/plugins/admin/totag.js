const handler = async (m, { conn, text, isAdmin, participants }) => {
    const users = participants
        .map(u => u.id)
        .filter(v => v !== conn.user.jid)

    if (!m.quoted) throw 'Reply pesan'

    // Ambil mention dari pesan quoted
    const quotedMentions = m.quoted.mentionedJid || []
    const allMentions = [...new Set([...users, ...quotedMentions])]

    // Deep clone fakeObj agar tidak merusak pesan asli
    let copyObj = JSON.parse(JSON.stringify(m.quoted.fakeObj))
    let mtype = Object.keys(copyObj.message || {})[0]

    if (!mtype) throw 'Pesan tidak valid'

    // Jika tipe "conversation" (teks biasa), ubah ke extendedTextMessage
    // karena "conversation" tidak mendukung contextInfo
    if (mtype === 'conversation') {
        copyObj.message = {
            extendedTextMessage: {
                text: copyObj.message.conversation,
                contextInfo: {
                    mentionedJid: allMentions
                }
            }
        }
    } 
    // Jika viewOnceMessage, inject ke message dalamnya
    else if (mtype === 'viewOnceMessage' || mtype === 'viewOnceMessageV2') {
        let innerType = Object.keys(copyObj.message[mtype]?.message || {})[0]
        if (innerType && typeof copyObj.message[mtype].message[innerType] === 'object') {
            if (!copyObj.message[mtype].message[innerType].contextInfo) {
                copyObj.message[mtype].message[innerType].contextInfo = {}
            }
            copyObj.message[mtype].message[innerType].contextInfo.mentionedJid = allMentions
        }
    } 
    // Untuk tipe lain (image, video, extendedText, document, dll)
    else if (typeof copyObj.message[mtype] === 'object') {
        if (!copyObj.message[mtype].contextInfo) {
            copyObj.message[mtype].contextInfo = {}
        }
        copyObj.message[mtype].contextInfo.mentionedJid = allMentions
    }

    await conn.sendMessage(m.chat, { forward: copyObj, mentions: allMentions })
}

handler.help = ['totag']
handler.tags = ['admin']
handler.command = ['totag', 'totags']
handler.admin = true
handler.group = true

export default handler