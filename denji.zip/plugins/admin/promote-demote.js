let handler = async (m, { conn, text, command }) => {
    let who = m.quoted 
        ? m.quoted.sender 
        : m.mentionedJid && m.mentionedJid[0] 
            ? m.mentionedJid[0] 
            : text 
                ? (text.replace(/\D/g, '') + '@s.whatsapp.net') 
                : ''
    
    if (!who) throw 'Reply / tag target!'
    
    let action = command === 'promote' ? 'promote' : 'demote'
    
    await conn.groupParticipantsUpdate(m.chat, [who], action)
    
    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
}

handler.help = ['promote @tag', 'demote @tag']
handler.tags = ['admin']
handler.command = ["promote", "demote"]

handler.admin = true
handler.group = true
handler.botAdmin = true

export default handler