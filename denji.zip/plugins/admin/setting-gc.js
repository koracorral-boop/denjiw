import { generateWAMessageFromContent, proto, prepareWAMessageMedia } from "baileys"

let handler = async (m, { conn, args, usedPrefix, command }) => {
    
    // 1. JIKA TIDAK ADA ARGUMEN, KIRIM LIST MESSAGE
    if (!args[0]) {
        let msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    "messageContextInfo": {
                        "deviceListMetadata": {},
                        "deviceListMetadataVersion": 2
                    },
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({
                            text: `*[ PENGATURAN GRUP ]*\n\nSilahkan pilih opsi pengaturan grup di bawah ini:`
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.create({
                            text: global.footer || "Group Settings"
                        }),
                        header: proto.Message.InteractiveMessage.Header.create({
                            title: "",
                            subtitle: "",
                            hasMediaAttachment: false
                        }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                            buttons: [
                                {
                                    "name": "single_select",
                                    "buttonParamsJson": JSON.stringify({
                                        "title": "KLIK DISINI",
                                        "sections": [
                                            {
                                                "title": "PENGATURAN CHAT",
                                                "highlight_label": "Populer",
                                                "rows": [
                                                    {
                                                        "header": "Buka Grup",
                                                        "title": "Open Chat",
                                                        "description": "Izinkan semua member mengirim pesan",
                                                        "id": `${usedPrefix + command} buka`
                                                    },
                                                    {
                                                        "header": "Tutup Grup",
                                                        "title": "Close Chat",
                                                        "description": "Hanya admin yang dapat mengirim pesan",
                                                        "id": `${usedPrefix + command} tutup`
                                                    }
                                                ]
                                            },
                                            {
                                                "title": "PENGATURAN INFO GRUP",
                                                "rows": [
                                                    {
                                                        "header": "Unlock Info",
                                                        "title": "Buka Edit Info",
                                                        "description": "Semua member bisa ubah info grup",
                                                        "id": `${usedPrefix + command} bukalink`
                                                    },
                                                    {
                                                        "header": "Lock Info",
                                                        "title": "Kunci Edit Info",
                                                        "description": "Hanya admin bisa ubah info grup",
                                                        "id": `${usedPrefix + command} kuncilink`
                                                    }
                                                ]
                                            }
                                        ]
                                    })
                                }
                            ]
                        })
                    })
                }
            }
        }, { userJid: m.chat, quoted: m })

        return conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
    }

    // 2. LOGIKA PROSES (Jika ada argumen / setelah tombol ditekan)
    let isClose = {
        // English
        'open': 'not_announcement',
        'close': 'announcement',
        'unlock': 'unlocked',
        'lock': 'locked',
        // Indonesia
        'buka': 'not_announcement',
        'tutup': 'announcement',
        'bukalink': 'unlocked',
        'kuncilink': 'locked',
        'kunci': 'locked',
        'bukakunci': 'unlocked',
    }[(args[0] || '').toLowerCase()]
    
    // Jika user mengetik argumen tapi salah
    if (isClose === undefined)
        throw `
*[ GROUP SETTINGS ]*

*Format salah! Pilih opsi di bawah:*
• ${usedPrefix + command} buka
• ${usedPrefix + command} tutup
• ${usedPrefix + command} unlock
• ${usedPrefix + command} lock
`.trim()

    // ========== CEK STATUS GRUP SAAT INI ==========
    let groupMetadata = await conn.groupMetadata(m.chat)
    
    // announce: true = grup tertutup | false = grup terbuka
    // restrict: true = edit info terkunci | false = edit info terbuka
    let currentStatus = {
        'not_announcement': !groupMetadata.announce,
        'announcement': groupMetadata.announce,
        'unlocked': !groupMetadata.restrict,
        'locked': groupMetadata.restrict,
    }[isClose]
    
    // Pesan jika sudah dalam status tersebut
    let alreadyMsg = {
        'not_announcement': '⚠️ Group sudah dalam keadaan *TERBUKA!* Tidak perlu dibuka lagi.',
        'announcement': '⚠️ Group sudah dalam keadaan *TERTUTUP!* Tidak perlu ditutup lagi.',
        'unlocked': '⚠️ Edit info group sudah dalam keadaan *TERBUKA!* Tidak perlu dibuka lagi.',
        'locked': '⚠️ Edit info group sudah dalam keadaan *TERKUNCI!* Tidak perlu dikunci lagi.',
    }[isClose]
    
    // Jika sudah dalam status yang sama, tolak
    if (currentStatus) throw alreadyMsg
    // =============================================

    await conn.groupSettingUpdate(m.chat, isClose)
    
    let responseMsg = {
        'not_announcement': '✅ Group berhasil *dibuka!* Semua member bisa mengirim pesan.',
        'announcement': '🔒 Group berhasil *ditutup!* Hanya admin yang bisa mengirim pesan.',
        'unlocked': '🔓 Edit info group *dibuka!* Semua member bisa edit info group.',
        'locked': '🔐 Edit info group *dikunci!* Hanya admin yang bisa edit info group.',
    }[isClose]
    
    m.reply(responseMsg)
}

handler.help = ['group']
handler.tags = ['admin']
handler.command = ["group", "grub", "grup"]
handler.admin = true
handler.botAdmin = true

export default handler