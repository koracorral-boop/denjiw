import { promises as fs } from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)
const DB_PATH = path.resolve(__dirname, '../../database/antitag.json')

async function loadDb() {
  try {
    await fs.mkdir(path.dirname(DB_PATH), { recursive: true })
    return JSON.parse(await fs.readFile(DB_PATH, 'utf-8'))
  } catch {
    return {}
  }
}

async function saveDb(data) {
  await fs.mkdir(path.dirname(DB_PATH), { recursive: true })
  await fs.writeFile(DB_PATH, JSON.stringify(data, null, 2))
}

function todayWIB() {
  return new Date().toLocaleDateString('sv-SE', { timeZone: 'Asia/Jakarta' })
}

function nowWIB() {
  return new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })
}

function isOwner(sender) {
  if (!global.owner) return false
  const num = sender.split('@')[0]
  return global.owner.flat().includes(num)
}

function getChat(db, chatId) {
  if (!db[chatId]) {
    db[chatId] = {
      enabled: false,  // default: nonaktif
      limit: 0,        // default: 0 (strict, langsung hapus)
      usage: {}
    }
  }
  return db[chatId]
}

let handler = async (m, { conn, args, isAdmin, isOwner }) => {

  const db = await loadDb()
  const chat = getChat(db, m.chat)
  const sub = (args[0] || '').toLowerCase()

  // .antitag (tanpa argumen) → toggle on/off
  if (!sub) {
    chat.enabled = !chat.enabled
    await saveDb(db)

    return m.reply(
      `⚙️ *ANTI-TAG ${chat.enabled ? 'AKTIF ✅' : 'NONAKTIF ❌'}*\n\n` +
      `│ Status : ${chat.enabled ? 'ON' : 'OFF'}\n` +
      `│ Limit  : ${chat.limit === 0 ? 'Strict (langsung hapus)' : chat.limit + 'x/hari'}\n` +
      `│ Oleh   : @${m.sender.split('@')[0]}\n` +
      `│ Waktu  : ${nowWIB()}\n\n` +
      `💡 Ketik *.antitag menu* untuk bantuan`,
      null, { mentions: [m.sender] }
    )
  }

  // .antitag on / off
  if (['on', 'off'].includes(sub)) {
    chat.enabled = sub === 'on'
    await saveDb(db)

    return m.reply(
      `⚙️ *ANTI-TAG ${chat.enabled ? 'AKTIF ✅' : 'NONAKTIF ❌'}*\n\n` +
      `│ Limit : ${chat.limit === 0 ? 'Strict' : chat.limit + 'x/hari'}\n` +
      `│ Oleh  : @${m.sender.split('@')[0]}`,
      null, { mentions: [m.sender] }
    )
  }

  // .antitag <angka> → set limit langsung
  if (/^\d+$/.test(sub)) {
    const num = Math.min(parseInt(sub), 100)
    chat.limit = num
    await saveDb(db)

    return m.reply(
      `📊 *LIMIT DIPERBARUI*\n\n` +
      `│ Limit : ${num === 0 ? 'Strict (langsung hapus semua)' : num + 'x/hari'}\n` +
      `│ Oleh  : @${m.sender.split('@')[0]}\n\n` +
      `🔄 Reset otomatis jam 00.00 WIB`,
      null, { mentions: [m.sender] }
    )
  }

  // .antitag reset
  if (sub === 'reset') {
    chat.usage = {}
    await saveDb(db)

    return m.reply(
      `🔄 *LIMIT DIRESET*\n\n` +
      `Semua hitungan penggunaan telah dinolkan.\n` +
      `Oleh: @${m.sender.split('@')[0]}`,
      null, { mentions: [m.sender] }
    )
  }

  // .antitag stats
  if (['stats', 'stat', 'info'].includes(sub)) {
    const today = todayWIB()
    const users = Object.entries(chat.usage || {}).filter(([, d]) => d.date === today)

    let msg = `📊 *ANTI-TAG STATUS*\n\n`
    msg += `│ Aktif   : ${chat.enabled ? '✅ ON' : '❌ OFF'}\n`
    msg += `│ Limit   : ${chat.limit === 0 ? 'Strict' : chat.limit + 'x/hari'}\n`
    msg += `│ Tanggal : ${today}\n\n`

    if (users.length > 0) {
      msg += `👥 *Penggunaan Hari Ini:*\n`
      users.forEach(([jid, d]) => {
        const sisa = chat.limit === 0 ? '-' : Math.max(0, chat.limit - d.count)
        msg += `│ • ${jid.split('@')[0]} → ${d.count}x (sisa: ${sisa})\n`
      })
    } else {
      msg += `_Belum ada yang tag hari ini_`
    }

    return m.reply(msg)
  }

  // .antitag menu / help / apapun
  return m.reply(
    `⚙️ *ANTI-TAG MENU*\n\n` +
    `│ *.antitag*        → Toggle on/off\n` +
    `│ *.antitag on*     → Aktifkan\n` +
    `│ *.antitag off*    → Nonaktifkan\n` +
    `│ *.antitag 0*      → Mode strict (hapus semua)\n` +
    `│ *.antitag 5*      → Boleh tag 5x/hari\n` +
    `│ *.antitag reset*  → Reset hitungan\n` +
    `│ *.antitag stats*  → Lihat statistik\n\n` +
    `📌 *Default: Nonaktif, Limit 0 (strict)*\n\n` +
    `*Contoh:*\n` +
    `*.antitag* → nyalakan\n` +
    `*.antitag 3* → boleh tag 3x/hari\n` +
    `*.antitag* → matikan lagi`
  )
}

handler.help = ['antitag']
handler.tags = ['admin']
handler.command = ['antitag', 'antitagsw']
handler.group = true
handler.admin = true

handler.before = async function (m, { isAdmin, isBotAdmin }) {
  if (m.isBaileys) return false
  if (!m.chat?.endsWith('@g.us')) return false
  if (m.mtype !== 'groupStatusMentionMessage') return false

  try {
    const db = await loadDb()
    const chat = db[m.chat]

    if (!chat?.enabled || !isBotAdmin) return false
    if (isOwner(m.sender) || isAdmin) return false

    const today = todayWIB()
    const limit = chat.limit ?? 0

    if (!chat.usage) chat.usage = {}
    if (!chat.usage[m.sender] || chat.usage[m.sender].date !== today) {
      chat.usage[m.sender] = { count: 0, date: today }
    }

    const user = chat.usage[m.sender]
    const mention = [m.sender]
    const tag = `@${m.sender.split('@')[0]}`

    // MODE STRICT (limit = 0) → langsung hapus
    if (limit === 0) {
      await this.sendMessage(m.chat, {
        delete: {
          remoteJid: m.chat,
          fromMe: false,
          id: m.key.id,
          participant: m.key.participant || m.sender
        }
      })

      await this.sendMessage(m.chat, {
        text: `🚫 Pesan ${tag} dihapus.\nAlasan: Tag grup dari status tidak diizinkan.`,
        mentions: mention
      })

      return false
    }

    // MODE LIMIT
    user.count++

    if (user.count > limit) {
      await this.sendMessage(m.chat, {
        delete: {
          remoteJid: m.chat,
          fromMe: false,
          id: m.key.id,
          participant: m.key.participant || m.sender
        }
      })

      await this.sendMessage(m.chat, {
        text: `🚫 Pesan ${tag} dihapus.\nLimit harian tercapai (${limit}x/hari).\nReset jam 00.00 WIB`,
        mentions: mention
      })
    } else {
      const sisa = limit - user.count
      await this.sendMessage(m.chat, {
        text: `⚠️ ${tag} menggunakan tag grup dari status.\nPenggunaan: ${user.count}/${limit} │ Sisa: ${sisa}x`,
        mentions: mention
      })
    }

    await saveDb(db)
  } catch (e) {
    console.error('[ANTITAG]', e)
  }

  return false
}

export default handler