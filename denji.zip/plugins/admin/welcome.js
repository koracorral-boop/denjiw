let handler = async (m, { command, args }) => {

    if (!global.db.data.chats[m.chat]) {
        global.db.data.chats[m.chat] = {}
    }

    let chat = global.db.data.chats[m.chat]
    let arg = args[0]?.toLowerCase()
    let before = chat[command] ?? false

    if (arg === 'on' || arg === '1') {
        chat[command] = true
    } else if (arg === 'off' || arg === '0') {
        chat[command] = false
    } else {
        chat[command] = !before
    }

    let name = command.charAt(0).toUpperCase() + command.slice(1)
    let status = chat[command] ? 'aktif ✅' : 'nonaktif ❌'

    if (before === chat[command]) {
        m.reply(`⚠️ *${name}* sudah ${status}`)
    } else {
        m.reply(`🔄 *${name}* → ${status}`)
    }
}

handler.help = ['welcome [on/off]', 'left [on/off]']
handler.tags = ['admin']
handler.command = ['welcome', 'left']
handler.group = true
handler.admin = true

export default handler