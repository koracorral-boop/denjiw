import { generateWAMessageFromContent, proto } from 'baileys'

let handler = async (m, { conn, text, participants }) => {

  // ─── Ambil teks dari reply / ketikan ───
  const fallbackText = (
    m.quoted?.text ||
    m.quoted?.caption ||
    m.quoted?.message?.extendedTextMessage?.text ||
    m.quoted?.message?.conversation ||
    ''
  ).trim()
  const rawText = (text || '').trim() || fallbackText
  if (!rawText) {
    throw 'Masukkan teks setelah perintah atau balas pesan berteks lalu ketik .hidetag'
  }

  // ─── Fake Contact (quoted) ───
  const fkontak = {
    key: {
      participants: "0@s.whatsapp.net",
      remoteJid: "status@broadcast",
      fromMe: false,
      id: "Halo"
    },
    message: {
      contactMessage: {
        vcard: `BEGIN:VCARD\nVERSION:3.0\nN:Sy;Bot;;;\nFN:y\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`
      }
    },
    participant: "0@s.whatsapp.net"
  }

  // ─── Daftar mention semua member ───
  const mentions = participants.map(a => a.id)

  // ══════════════════════════════════════
  //  CEK APAKAH ADA TOMBOL  (pakai "|")
  // ══════════════════════════════════════
  if (rawText.includes('|')) {

    const parts   = rawText.split('|')
    const bodyText = parts[0].trim()

    // ─── Bangun array tombol dari setiap bagian setelah "|" ───
    const buttons = parts.slice(1)
      .filter(b => b.trim() !== '')
      .map(b => ({
        name: "quick_reply",                       // tombol kirim perintah
        buttonParamsJson: JSON.stringify({
          display_text: b.trim(),                  // label tombol
          id: b.trim()                             // teks yg dikirim saat ditekan
        })
      }))

    // ─── Susun Interactive Message ───
    const interactiveMessage = proto.Message.InteractiveMessage.create({
      body: proto.Message.InteractiveMessage.Body.create({
        text: bodyText
      }),
      footer: proto.Message.InteractiveMessage.Footer.create({
        text: ''                                   // kosongkan / isi footer bebas
      }),
      header: proto.Message.InteractiveMessage.Header.create({
        hasMediaAttachment: false
      }),
      nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
        buttons: buttons
      }),
      contextInfo: {
        mentionedJid: mentions                     // <-- kunci hidetag
      }
    })

    // ─── Bungkus dalam viewOnceMessage agar button muncul ───
    const msg = generateWAMessageFromContent(m.chat, {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2
          },
          interactiveMessage
        }
      }
    }, {
      quoted: fkontak,
      userJid: conn.user.id
    })

    // ─── Kirim ───
    await conn.relayMessage(m.chat, msg.message, {
      messageId: msg.key.id
    })

  } else {

    // ══════════════════════════════════════
    //  HIDETAG BIASA (tanpa tombol)
    // ══════════════════════════════════════
    await conn.sendMessage(
      m.chat,
      { text: rawText, mentions },
      { quoted: fkontak }
    )
  }
}

handler.help    = ['hidetag']
handler.tags    = ['admin']
handler.command = ["h", "ht", "hidetag", "htag"]
handler.group   = true
handler.admin   = true

export default handler