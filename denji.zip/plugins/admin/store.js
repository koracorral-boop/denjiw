import path from 'path';
import fs from 'fs';
import { fileTypeFromBuffer } from 'file-type';
import { fileURLToPath } from 'url';
import crypto from 'crypto';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const STORAGE_DIR = path.join(__dirname, '../../database');
const DB_PATH = path.join(STORAGE_DIR, 'addlist.json');

if (!fs.existsSync(STORAGE_DIR)) {
  fs.mkdirSync(STORAGE_DIR, { recursive: true });
}

const MAX_FILE_SIZE = 200 * 1024 * 1024;
const MAX_KEY_LENGTH = 50;

// ==================== CATBOX FUNCTIONS ====================

async function uploadToCatbox(buffer) {
  if (!buffer || !Buffer.isBuffer(buffer)) {
    throw new Error('Buffer tidak valid');
  }

  if (buffer.length === 0) {
    throw new Error('Buffer kosong');
  }

  if (buffer.length > MAX_FILE_SIZE) {
    throw new Error(`File terlalu besar! Maksimal ${formatFileSize(MAX_FILE_SIZE)}`);
  }

  const type = await fileTypeFromBuffer(buffer);
  if (!type) {
    throw new Error('Format file tidak dikenali');
  }

  try {
    const filename = `${Date.now()}_${crypto.randomBytes(4).toString('hex')}.${type.ext}`;
    const boundary = `----FormBoundary${crypto.randomBytes(16).toString('hex')}`;

    const header = Buffer.from(
      `--${boundary}\r\n` +
      `Content-Disposition: form-data; name="reqtype"\r\n\r\n` +
      `fileupload\r\n` +
      `--${boundary}\r\n` +
      `Content-Disposition: form-data; name="fileToUpload"; filename="${filename}"\r\n` +
      `Content-Type: ${type.mime}\r\n\r\n`
    );

    const footer = Buffer.from(`\r\n--${boundary}--\r\n`);

    const body = Buffer.concat([header, buffer, footer]);

    const response = await fetch('https://catbox.moe/user/api.php', {
      method: 'POST',
      headers: {
        'Content-Type': `multipart/form-data; boundary=${boundary}`,
        'Content-Length': body.length.toString()
      },
      body,
      signal: AbortSignal.timeout(300000)
    });

    if (!response.ok) {
      throw new Error(`Catbox error: ${response.status} - ${response.statusText}`);
    }

    const data = await response.text();

    if (!data || !data.startsWith('https://')) {
      throw new Error('Response Catbox tidak valid');
    }

    return data.trim();
  } catch (err) {
    if (err.name === 'TimeoutError' || err.name === 'AbortError') {
      throw new Error('Upload ke Catbox timeout (5 menit)');
    }
    throw new Error(`Gagal upload ke Catbox: ${err.message}`);
  }
}

async function downloadFromUrl(url) {
  if (!url) {
    throw new Error('URL tidak valid');
  }

  try {
    const response = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      },
      signal: AbortSignal.timeout(120000)
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status} - ${response.statusText}`);
    }

    const arrayBuffer = await response.arrayBuffer();
    return Buffer.from(arrayBuffer);
  } catch (err) {
    if (err.name === 'TimeoutError' || err.name === 'AbortError') {
      throw new Error('Download timeout (2 menit)');
    }
    throw new Error(`Gagal download dari URL: ${err.message}`);
  }
}

// ==================== MEDIA DOWNLOAD FUNCTION ====================

async function downloadMedia(conn, quoted) {
  try {
    let buffer;

    if (typeof quoted.download === 'function') {
      buffer = await quoted.download();
    } else if (typeof conn.downloadMediaMessage === 'function') {
      buffer = await conn.downloadMediaMessage(quoted);
    } else if (typeof conn.downloadAndSaveMediaMessage === 'function') {
      const filePath = await conn.downloadAndSaveMediaMessage(quoted);
      buffer = fs.readFileSync(filePath);
      fs.unlinkSync(filePath);
    } else if (typeof conn.downloadM === 'function') {
      buffer = await conn.downloadM(quoted);
    } else if (quoted.msg) {
      const { downloadContentFromMessage } = await import('baileys');
      const stream = await downloadContentFromMessage(quoted.msg, quoted.mtype?.replace(/Message/, '') || 'image');
      const chunks = [];
      for await (const chunk of stream) {
        chunks.push(chunk);
      }
      buffer = Buffer.concat(chunks);
    } else {
      const { downloadContentFromMessage } = await import('baileys');
      const messageType = Object.keys(quoted.message || {})[0];
      const stream = await downloadContentFromMessage(
        quoted.message,
        messageType.replace(/Message/, '')
      );
      const chunks = [];
      for await (const chunk of stream) {
        chunks.push(chunk);
      }
      buffer = Buffer.concat(chunks);
    }

    if (!buffer || buffer.length === 0) {
      throw new Error('Buffer kosong setelah download');
    }

    return buffer;
  } catch (err) {
    throw new Error(`Gagal mendownload media: ${err.message}`);
  }
}

// ==================== DATABASE FUNCTIONS ====================

function getStoreDB() {
  if (!fs.existsSync(DB_PATH)) {
    const initial = {
      chats: {},
      version: '3.0',
      storageType: 'catbox',
      lastModified: Date.now()
    };
    fs.writeFileSync(DB_PATH, JSON.stringify(initial, null, 2), 'utf8');
    return initial;
  }

  try {
    const data = JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));

    if (!data.version || data.version === '1.0' || data.version === '2.0') {
      for (const chatId in data.chats) {
        const chat = data.chats[chatId];
        if (chat.items && Array.isArray(chat.items)) {
          chat.items = chat.items.map(item => {
            if (item.mediaFileName && !item.mediaUrl) {
              item.needsReupload = true;
              delete item.mediaFileName;
            }
            return item;
          });
        }
      }
      data.version = '3.0';
      data.storageType = 'catbox';
      data.lastModified = Date.now();
      saveStoreDB(data);
    }

    return data;
  } catch (err) {
    if (fs.existsSync(DB_PATH)) {
      const backupPath = `${DB_PATH}.backup.${Date.now()}`;
      fs.copyFileSync(DB_PATH, backupPath);
    }
    return { chats: {}, version: '3.0', storageType: 'catbox', lastModified: Date.now() };
  }
}

function saveStoreDB(data) {
  try {
    data.lastModified = Date.now();
    const tempPath = `${DB_PATH}.tmp`;

    fs.writeFileSync(tempPath, JSON.stringify(data, null, 2), 'utf8');
    fs.renameSync(tempPath, DB_PATH);

    return true;
  } catch (err) {
    return false;
  }
}

function getChatItems(chatId) {
  const db = getStoreDB();
  if (!db.chats[chatId]) {
    db.chats[chatId] = {
      items: [],
      createdAt: Date.now()
    };
    saveStoreDB(db);
  }
  return db.chats[chatId].items || [];
}

function setChatItems(chatId, items) {
  const db = getStoreDB();
  if (!db.chats[chatId]) {
    db.chats[chatId] = { createdAt: Date.now() };
  }
  db.chats[chatId].items = items;
  db.chats[chatId].lastModified = Date.now();
  return saveStoreDB(db);
}

// ==================== HELPER FUNCTIONS ====================

function getMediaType(mime) {
  if (!mime) return 'text';

  const mimeStr = mime.toLowerCase();

  if (mimeStr.includes('webp')) return 'sticker';
  if (mimeStr.startsWith('image/')) return 'image';
  if (mimeStr.startsWith('video/')) return 'video';
  if (mimeStr.startsWith('audio/')) {
    return mimeStr.includes('opus') ? 'voice' : 'audio';
  }

  return 'file';
}

function validateMediaType(mime) {
  if (!mime) return false;

  const allowed = [
    'image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp',
    'video/mp4', 'video/mpeg', 'video/webm', 'video/avi',
    'audio/mpeg', 'audio/mp3', 'audio/wav', 'audio/ogg', 'audio/mp4', 'audio/x-m4a',
    'application/pdf', 'application/zip', 'application/x-rar'
  ];

  return allowed.some(type => mime.toLowerCase().includes(type)) ||
    mime.startsWith('image/') ||
    mime.startsWith('video/') ||
    mime.startsWith('audio/');
}

function formatFileSize(bytes) {
  if (bytes === 0) return '0 Bytes';

  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));

  return (bytes / Math.pow(k, i)).toFixed(2) + ' ' + sizes[i];
}

function sanitizeKey(key) {
  return key.trim().toLowerCase();
}

// ==================== EDIT MESSAGE HELPER ====================

async function editMsg(conn, chatId, msgKey, newText) {
  try {
    await conn.sendMessage(chatId, { text: newText, edit: msgKey });
  } catch {
    await conn.sendMessage(chatId, { text: newText });
  }
}

// ==================== HANDLER FUNCTIONS ====================

async function handleAddList(m, conn, { text, usedPrefix, command }) {
  const chatId = m.chat;

  if (!text) {
    return m.reply(
      `CARA PENGGUNAAN ADDLIST\n\n` +
      `1. Teks:\n   ${usedPrefix}${command} key|response\n\n` +
      `2. Media:\n   Reply media dengan ${usedPrefix}${command} key\n\n` +
      `3. Media + Caption:\n   ${usedPrefix}${command} key|caption\n\n` +
      `CONTOH:\n` +
      `${usedPrefix}${command} halo|Halo juga!\n` +
      `${usedPrefix}${command} logo (reply gambar)\n\n` +
      `Storage: Catbox.moe (Cloud)`
    );
  }

  let key, response;
  let isReplied = false;
  const quoted = m.quoted;
  let mediaType = 'text';
  let mediaUrl = null;
  let fileSize = 0;
  let mimetype = null;

  if (text.includes('|')) {
    const parts = text.split('|');
    key = parts[0].trim();
    response = parts.slice(1).join('|').trim();

    if (!response && quoted) {
      isReplied = true;
      const mime = quoted.msg?.mimetype || quoted.mimetype || '';
      mimetype = mime;
      mediaType = getMediaType(mime);
      response = quoted.text || '';
    }
  } else {
    key = text.trim();
    if (quoted) {
      isReplied = true;
      const mime = quoted.msg?.mimetype || quoted.mimetype || '';
      mimetype = mime;
      mediaType = getMediaType(mime);
      response = quoted.text || '';
    } else {
      return m.reply(`Format salah!\nGunakan: ${usedPrefix}${command} key|response`);
    }
  }

  if (!key) {
    return m.reply('Key tidak boleh kosong!');
  }

  if (key.length > MAX_KEY_LENGTH) {
    return m.reply(`Key terlalu panjang! Maksimal ${MAX_KEY_LENGTH} karakter.`);
  }

  const items = getChatItems(chatId);
  const normalizedKey = sanitizeKey(key);

  if (items.find(i => sanitizeKey(i.key) === normalizedKey)) {
    return m.reply(`Key *${key}* sudah ada!\n\nGunakan ${usedPrefix}updatelist untuk mengubah.`);
  }

  try {
    let statusMsg = null;

    if (isReplied && mediaType !== 'text' && quoted) {
      const mime = quoted.msg?.mimetype || quoted.mimetype || '';

      if (!validateMediaType(mime)) {
        return m.reply(
          'Format file tidak didukung!\n\n' +
          'Format yang didukung:\n' +
          '- Image: jpg, png, gif, webp\n' +
          '- Video: mp4, webm\n' +
          '- Audio: mp3, wav, ogg\n' +
          '- Document: pdf, zip, rar'
        );
      }

      statusMsg = await conn.sendMessage(chatId, { text: 'Mengunduh media...' }, { quoted: m });

      const buffer = await downloadMedia(conn, quoted);

      if (!buffer || buffer.length === 0) {
        throw new Error('Gagal mengunduh media');
      }

      fileSize = buffer.length;

      if (fileSize > MAX_FILE_SIZE) {
        await editMsg(conn, chatId, statusMsg.key,
          `File terlalu besar!\n\n` +
          `Ukuran file: ${formatFileSize(fileSize)}\n` +
          `Maksimal: ${formatFileSize(MAX_FILE_SIZE)}`
        );
        return;
      }

      await editMsg(conn, chatId, statusMsg.key, 'Mengupload ke Catbox...');
      mediaUrl = await uploadToCatbox(buffer);
    }

    const newItem = {
      key,
      response: response || '',
      mediaType,
      mediaUrl,
      mimetype,
      fileSize,
      timestamp: Date.now(),
      addedBy: m.sender
    };

    items.push(newItem);

    if (setChatItems(chatId, items)) {
      const info = mediaType !== 'text'
        ? ` (${mediaType}, ${formatFileSize(fileSize)})`
        : '';

      const successText =
        `Berhasil menambahkan item\n\n` +
        `Key: *${key}*${info}\n` +
        `Response: ${response ? 'Ya' : 'Tidak'}\n` +
        `Media: ${mediaUrl ? 'Terupload ke Catbox' : 'Tidak'}`;

      if (statusMsg) {
        await editMsg(conn, chatId, statusMsg.key, successText);
      } else {
        await m.reply(successText);
      }
    } else {
      const errText = 'Gagal menyimpan ke database';
      if (statusMsg) {
        await editMsg(conn, chatId, statusMsg.key, errText);
      } else {
        await m.reply(errText);
      }
    }
  } catch (err) {
    await m.reply(`Gagal menambahkan item!\n\nDetail: ${err.message}`);
  }
}

async function handleDelList(m, { text, usedPrefix, command }) {
  const chatId = m.chat;

  if (!text) {
    return m.reply(
      `CARA PENGGUNAAN DELLIST\n\n` +
      `Format: ${usedPrefix}${command} key\n\n` +
      `Contoh: ${usedPrefix}${command} halo`
    );
  }

  const items = getChatItems(chatId);
  const normalizedKey = sanitizeKey(text);
  const index = items.findIndex(i => sanitizeKey(i.key) === normalizedKey);

  if (index !== -1) {
    const deleted = items.splice(index, 1)[0];

    if (setChatItems(chatId, items)) {
      await m.reply(`Berhasil menghapus item\n\nKey: *${deleted.key}*`);
    } else {
      await m.reply('Gagal menyimpan perubahan');
    }
  } else {
    await m.reply(`Key *${text}* tidak ditemukan!\n\nGunakan ${usedPrefix}list untuk melihat semua key.`);
  }
}

async function handleUpdateList(m, conn, { text, usedPrefix, command }) {
  const chatId = m.chat;

  if (!text) {
    return m.reply(
      `CARA PENGGUNAAN UPDATELIST\n\n` +
      `1. Teks:\n   ${usedPrefix}${command} key|response baru\n\n` +
      `2. Media:\n   Reply media dengan ${usedPrefix}${command} key\n\n` +
      `3. Media + Caption:\n   ${usedPrefix}${command} key|caption baru\n\n` +
      `CONTOH:\n` +
      `${usedPrefix}${command} halo|Halo juga kawan!\n` +
      `${usedPrefix}${command} logo (reply gambar baru)\n\n` +
      `Storage: Catbox.moe (Cloud)`
    );
  }

  let key, response;
  let isReplied = false;
  const quoted = m.quoted;
  let mediaType = 'text';
  let mediaUrl = null;
  let fileSize = 0;
  let mimetype = null;

  if (text.includes('|')) {
    const parts = text.split('|');
    key = parts[0].trim();
    response = parts.slice(1).join('|').trim();

    if (!response && quoted) {
      isReplied = true;
      const mime = quoted.msg?.mimetype || quoted.mimetype || '';
      mimetype = mime;
      mediaType = getMediaType(mime);
      response = quoted.text || '';
    }
  } else {
    key = text.trim();
    if (quoted) {
      isReplied = true;
      const mime = quoted.msg?.mimetype || quoted.mimetype || '';
      mimetype = mime;
      mediaType = getMediaType(mime);
      response = quoted.text || '';
    } else {
      return m.reply(`Format salah!\nGunakan: ${usedPrefix}${command} key|response baru\n\nAtau reply media dengan caption ${usedPrefix}${command} key`);
    }
  }

  if (!key) {
    return m.reply('Key tidak boleh kosong!');
  }

  if (key.length > MAX_KEY_LENGTH) {
    return m.reply(`Key terlalu panjang! Maksimal ${MAX_KEY_LENGTH} karakter.`);
  }

  const items = getChatItems(chatId);
  const normalizedKey = sanitizeKey(key);
  const index = items.findIndex(i => sanitizeKey(i.key) === normalizedKey);

  if (index === -1) {
    return m.reply(`Key *${key}* tidak ditemukan!\n\nGunakan ${usedPrefix}addlist untuk menambahkan key baru.\nGunakan ${usedPrefix}list untuk melihat semua key.`);
  }

  try {
    const oldItem = items[index];
    let statusMsg = null;

    if (isReplied && mediaType !== 'text' && quoted) {
      const mime = quoted.msg?.mimetype || quoted.mimetype || '';

      if (!validateMediaType(mime)) {
        return m.reply(
          'Format file tidak didukung!\n\n' +
          'Format yang didukung:\n' +
          '- Image: jpg, png, gif, webp\n' +
          '- Video: mp4, webm\n' +
          '- Audio: mp3, wav, ogg\n' +
          '- Document: pdf, zip, rar'
        );
      }

      statusMsg = await conn.sendMessage(chatId, { text: 'Mengunduh media baru...' }, { quoted: m });

      const buffer = await downloadMedia(conn, quoted);

      if (!buffer || buffer.length === 0) {
        throw new Error('Gagal mengunduh media');
      }

      fileSize = buffer.length;

      if (fileSize > MAX_FILE_SIZE) {
        await editMsg(conn, chatId, statusMsg.key,
          `File terlalu besar!\n\n` +
          `Ukuran file: ${formatFileSize(fileSize)}\n` +
          `Maksimal: ${formatFileSize(MAX_FILE_SIZE)}`
        );
        return;
      }

      await editMsg(conn, chatId, statusMsg.key, 'Mengupload ke Catbox...');
      mediaUrl = await uploadToCatbox(buffer);
    }

    const updatedItem = {
      key: oldItem.key,
      response: response || '',
      mediaType: mediaUrl ? mediaType : (isReplied && mediaType === 'text' ? 'text' : oldItem.mediaType),
      mediaUrl: mediaUrl || (isReplied && mediaType === 'text' ? null : oldItem.mediaUrl),
      mimetype: mediaUrl ? mimetype : (isReplied && mediaType === 'text' ? null : oldItem.mimetype),
      fileSize: mediaUrl ? fileSize : (isReplied && mediaType === 'text' ? 0 : oldItem.fileSize),
      timestamp: oldItem.timestamp,
      addedBy: oldItem.addedBy,
      updatedAt: Date.now(),
      updatedBy: m.sender
    };

    items[index] = updatedItem;

    if (setChatItems(chatId, items)) {
      const info = updatedItem.mediaType !== 'text' && updatedItem.mediaUrl
        ? ` (${updatedItem.mediaType}, ${formatFileSize(updatedItem.fileSize)})`
        : '';

      const successText =
        `Berhasil mengupdate item\n\n` +
        `Key: *${updatedItem.key}*${info}\n` +
        `Response: ${updatedItem.response ? 'Ya' : 'Tidak'}\n` +
        `Media: ${updatedItem.mediaUrl ? 'Terupdate di Catbox' : 'Tidak'}`;

      if (statusMsg) {
        await editMsg(conn, chatId, statusMsg.key, successText);
      } else {
        await m.reply(successText);
      }
    } else {
      const errText = 'Gagal menyimpan ke database';
      if (statusMsg) {
        await editMsg(conn, chatId, statusMsg.key, errText);
      } else {
        await m.reply(errText);
      }
    }
  } catch (err) {
    await m.reply(`Gagal mengupdate item!\n\nDetail: ${err.message}`);
  }
}

async function handleListStore(m, { usedPrefix }) {
  const chatId = m.chat;
  const items = getChatItems(chatId);

  if (!items.length) {
    return m.reply(
      `LIST STORE\n\n` +
      `Store masih kosong.\n\n` +
      `Gunakan ${usedPrefix}addlist key|response untuk menambahkan item.`
    );
  }

  const grouped = items.reduce((acc, item) => {
    const type = item.mediaType || 'text';
    if (!acc[type]) acc[type] = [];
    acc[type].push(item);
    return acc;
  }, {});

  let listText = `LIST STORE\n`;
  listText += `Total: ${items.length} item(s)\n`;
  listText += `${'─'.repeat(30)}\n\n`;

  const typeLabels = {
    text: 'TEXT',
    image: 'IMAGE',
    video: 'VIDEO',
    audio: 'AUDIO',
    voice: 'VOICE',
    sticker: 'STICKER',
    file: 'FILE'
  };

  for (const [type, arr] of Object.entries(grouped)) {
    const label = typeLabels[type] || type.toUpperCase();
    listText += `[ ${label} ] (${arr.length})\n`;

    arr.forEach((item, i) => {
      const size = item.fileSize ? ` [${formatFileSize(item.fileSize)}]` : '';
      const hasResponse = item.response ? ' +teks' : '';
      const needsReupload = item.needsReupload ? ' *reupload*' : '';
      listText += `  ${i + 1}. ${item.key}${size}${hasResponse}${needsReupload}\n`;
    });
    listText += '\n';
  }

  listText += `${'─'.repeat(30)}\n`;
  listText += `Ketik key untuk trigger response\n`;
  listText += `Storage: Catbox.moe (Cloud)\n`;

  const needsReupload = items.filter(i => i.needsReupload).length;
  if (needsReupload > 0) {
    listText += `\n${needsReupload} item perlu di-upload ulang`;
  }

  await m.reply(listText);
}

// ==================== MAIN HANDLER ====================

const handler = async (m, { conn, text, usedPrefix, command }) => {
  try {
    switch (command.toLowerCase()) {
      case 'addlist':
        return await handleAddList(m, conn, { text, usedPrefix, command });
      case 'dellist':
        return await handleDelList(m, { text, usedPrefix, command });
      case 'list':
        return await handleListStore(m, { usedPrefix });
      case 'updatelist':
        return await handleUpdateList(m, conn, { text, usedPrefix, command });
      default:
        await m.reply('Command tidak dikenal');
    }
  } catch (err) {
    await m.reply(`Terjadi kesalahan: ${err.message}`);
  }
};

handler.help = ['addlist', 'dellist', 'list', 'updatelist'];
handler.tags = ['admin'];
handler.command = ['addlist', 'dellist', 'list', 'updatelist'];
handler.group = true;
handler.admin = true;

// ==================== BEFORE HANDLER (AUTO RESPONSE) ====================

handler.before = async function (m) {
  const conn = this;

  if (!m.text || !m.isGroup || m.fromMe || m.isBaileys) return false;

  const chatId = m.chat;
  const items = getChatItems(chatId);

  if (!items.length) return false;

  const normalizedText = sanitizeKey(m.text);
  const item = items.find(i => sanitizeKey(i.key) === normalizedText);

  if (!item) return false;

  if (item.needsReupload) {
    await conn.sendMessage(m.chat, {
      text: `Media untuk key *${item.key}* perlu di-upload ulang.\n\nGunakan updatelist untuk mengupload ulang.`
    }, { quoted: m });
    return true;
  }

  try {
    if (item.mediaUrl) {
      const mediaBuffer = await downloadFromUrl(item.mediaUrl);

      switch (item.mediaType) {
        case 'sticker':
          await conn.sendSticker(m.chat, mediaBuffer, m, {
            packname: global.stickpack || 'Brat',
            author: global.stickauth || 'Sticker Bot'
          });

          if (item.response) {
            await conn.sendMessage(m.chat, {
              text: item.response
            }, { quoted: m });
          }
          break;

        case 'image':
          await conn.sendMessage(m.chat, {
            image: mediaBuffer,
            caption: item.response || ''
          }, { quoted: m });
          break;

        case 'video':
          await conn.sendMessage(m.chat, {
            video: mediaBuffer,
            caption: item.response || ''
          }, { quoted: m });
          break;

        case 'audio':
          await conn.sendMessage(m.chat, {
            audio: mediaBuffer,
            mimetype: item.mimetype || 'audio/mpeg'
          }, { quoted: m });

          if (item.response) {
            await conn.sendMessage(m.chat, {
              text: item.response
            }, { quoted: m });
          }
          break;

        case 'voice':
          await conn.sendMessage(m.chat, {
            audio: mediaBuffer,
            mimetype: 'audio/ogg; codecs=opus',
            ptt: true
          }, { quoted: m });

          if (item.response) {
            await conn.sendMessage(m.chat, {
              text: item.response
            }, { quoted: m });
          }
          break;

        case 'file':
        default:
          const ext = item.mimetype?.split('/')[1] || 'bin';
          await conn.sendMessage(m.chat, {
            document: mediaBuffer,
            mimetype: item.mimetype || 'application/octet-stream',
            fileName: `${item.key}.${ext}`
          }, { quoted: m });

          if (item.response) {
            await conn.sendMessage(m.chat, {
              text: item.response
            }, { quoted: m });
          }
      }
    } else if (item.response) {
      await conn.sendMessage(m.chat, {
        text: item.response
      }, { quoted: m });
    }

    return true;

  } catch (err) {
    console.error(`[ADDLIST ERROR] ${err.message}`);

    if (err.message.includes('404') || err.message.includes('Not Found')) {
      const items = getChatItems(chatId);
      const index = items.findIndex(i => sanitizeKey(i.key) === sanitizeKey(item.key));
      if (index !== -1) {
        items[index].needsReupload = true;
        setChatItems(chatId, items);
      }

      await conn.sendMessage(m.chat, {
        text: `Media untuk key *${item.key}* sudah tidak tersedia di server.\n\nGunakan updatelist untuk upload ulang.`
      }, { quoted: m });
    } else {
      await conn.sendMessage(m.chat, {
        text: `Gagal mengirim media: ${err.message}`
      }, { quoted: m });
    }

    return false;
  }
};

export default handler;