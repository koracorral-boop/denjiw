let handler = async (m, { conn, args, participants, usedPrefix, command }) => {
    let target = null;

    // 1. Dari reply
    if (m.quoted?.sender) {
        target = m.quoted.sender;
    }

    // 2. Dari mention
    if (!target && m.mentionedJid?.length) {
        target = m.mentionedJid[0];
    }

    // 3. Dari nomor (62xxxx / 08xxxx)
    if (!target && args[0]) {
        let num = args[0].replace(/[^0-9]/g, "");
        if (num.startsWith("0")) num = "62" + num.slice(1);
        target = num + "@s.whatsapp.net";
    }

    if (!target) {
        return m.reply(
            `Gunakan salah satu:\n` +
            `• Reply pesan member\n` +
            `• Tag member\n` +
            `• Ketik nomor (62xxxx)\n\n` +
            `Contoh: ${usedPrefix + command} @628xxxx`
        );
    }

    // Pastikan target ada di grup
    let member = participants.find(
        p => p.id === target || p.id === target.replace("@s.whatsapp.net", "@lid")
    );

    if (!member) {
        return m.reply("User tersebut bukan anggota grup ini.");
    }

    try {
        await conn.groupParticipantsUpdate(
            m.chat,
            [member.id],
            "remove"
        );

        await conn.sendMessage(
            m.chat,
            {
                text: `Successfully removed @${member.id.split("@")[0]}.`,
                mentions: [member.id],
            },
            { quoted: m }
        );
    } catch (e) {
        conn.logger.error(e);
        m.reply(`Error: ${e.message}`);
    }
};

handler.help = ["kick"];
handler.tags = ["admin"];
handler.command = ["kick", "k"];
handler.group = true;
handler.botAdmin = true;
handler.admin = true;

export default handler;