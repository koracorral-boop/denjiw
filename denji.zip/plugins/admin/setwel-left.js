const handler = async (m, { conn, text, usedPrefix, command }) => {
    try {
        let chat = global.db.data.chats[m.chat];
        if (!chat) chat = global.db.data.chats[m.chat] = {};
        
        const welcomeCommands = ['setwelcome', 'setwlc', 'setwel'];
        const byeCommands = ['setbye', 'setleft'];
        const isWelcome = welcomeCommands.includes(command.toLowerCase());
        const typeLabel = isWelcome ? "Welcome" : "Left/Bye";
        const activateCommand = isWelcome ? `${usedPrefix}welcome on` : `${usedPrefix}left on`;
        
        let finalText = null;
        
        if (m.quoted?.text && !text) {
            finalText = m.quoted.text;
        } 
        else if (m.text) {
            const commandPattern = new RegExp(`^[/!.]${command}\\s*`, 'i');
            finalText = m.text.replace(commandPattern, '').trim();
            
            if (!finalText && text) {
                finalText = text;
            }
        } 
        else if (text) {
            finalText = text;
        }
        
        if (finalText) {
            finalText = finalText.replace(/\\n/g, '\n');
        }

        // --- LOGIKA KHUSUS UNTUK KATA "ON" ---
        if (finalText && finalText.toLowerCase() === 'on') {
            const confirmText = `Konfirmasi Pengaturan Pesan ${typeLabel}\n\n` +
            `Anda mengetik kata "on".\n` +
            `Apakah Anda ingin mengubah pesan sambutan menjadi kata "on" atau Anda ingin mengaktifkan fitur ini?\n\n` +
            `Pilih tindakan di bawah ini:`;

            const interactiveMessage = {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            body: { text: confirmText },
                            footer: { text: `Pilih salah satu opsi` },
                            header: {
                                title: `⚙️ Konfirmasi ${typeLabel}`,
                                subtitle: '',
                                hasMediaAttachment: false
                            },
                            nativeFlowMessage: {
                                buttons: [
                                    {
                                        name: 'single_select',
                                        buttonParamsJson: JSON.stringify({
                                            title: 'Pilih Tindakan',
                                            sections: [
                                                {
                                                    title: `Opsi Pengaturan ${typeLabel}`,
                                                    highlight_label: 'Pilih',
                                                    rows: [
                                                        {
                                                            header: '📝 Ubah Teks',
                                                            title: `Ubah teks jadi "on"`,
                                                            description: `Set pesan ${typeLabel.toLowerCase()} menjadi kata "on"`,
                                                            id: `${usedPrefix + command} on --force`
                                                        },
                                                        {
                                                            header: '✅ Aktifkan Fitur',
                                                            title: `Aktifkan Fitur ${typeLabel}`,
                                                            description: `Mengaktifkan fitur ${typeLabel.toLowerCase()} di grup ini`,
                                                            id: activateCommand
                                                        }
                                                    ]
                                                }
                                            ]
                                        })
                                    }
                                ],
                                messageParamsJson: ''
                            }
                        }
                    }
                }
            };

            return conn.relayMessage(m.chat, interactiveMessage, { quoted: m });
        }

        // Cek flag --force untuk by-pass konfirmasi "on"
        if (finalText && finalText.toLowerCase() === 'on --force') {
            finalText = 'on';
        }

        // --- LOGIKA UTAMA SET TEXT ---
        if (isWelcome) {
            if (!finalText) {
                if (chat.sWelcome) {
                    return m.reply(
                        `Pesan Welcome Saat Ini:\n\n` +
                        `${chat.sWelcome}\n\n` +
                        `Untuk mengubah pesan, ketik:\n` +
                        `${usedPrefix + command} pesan baru anda`
                    );
                } 
                else {
                    return m.reply(
                        `Atur Pesan Welcome\n\n` +
                        `Cara Penggunaan:\n` +
                        `1. Langsung Multi-baris:\n` +
                        `   ${usedPrefix + command} Hai @user\n` +
                        `   Selamat datang di @subject\n` +
                        `   (Ketik seperti biasa dengan Enter untuk baris baru)\n\n` +
                        `2. Menggunakan \\n:\n` +
                        `   ${usedPrefix + command} Hai @user\\nSelamat datang\n\n` +
                        `3. Balas Pesan (Reply):\n` +
                        `   Balas pesan teks yang sudah ada dengan: ${usedPrefix + command}\n\n` +
                        `Contoh:\n` +
                        `${usedPrefix + command} Hai @user\n` +
                        `Selamat datang di @subject\n\n` +
                        `Silahkan perkenalkan diri:\n` +
                        `Nama:\n` +
                        `Asal:\n` +
                        `Umur:\n\n` +
                        `Placeholder tersedia:\n` +
                        `• @user = mention pengguna\n` +
                        `• @subject = nama grup\n` +
                        `• @desc = deskripsi grup`
                    );
                }
            } else {
                chat.sWelcome = finalText;
                return m.reply(
                    `Sukses Mengatur Pesan Welcome\n\n` +
                    `Pesan baru:\n` +
                    `${finalText}\n\n` +
                    `Pesan ini akan dikirim saat seseorang bergabung ke grup.\n` +
                    `Pastikan fitur aktif dengan mengetik: ${usedPrefix}welcome on`
                );
            }
        } 
        else if (byeCommands.includes(command.toLowerCase())) {
            if (!finalText) {
                if (chat.sBye) {
                    return m.reply(
                        `Pesan Left/Bye Saat Ini:\n\n` +
                        `${chat.sBye}\n\n` +
                        `Untuk mengubah pesan, ketik:\n` +
                        `${usedPrefix + command} pesan baru anda`
                    );
                }
                else {
                    return m.reply(
                        `Atur Pesan Left/Bye\n\n` +
                        `Cara Penggunaan:\n` +
                        `1. Langsung Multi-baris:\n` +
                        `   ${usedPrefix + command} Selamat tinggal @user\n` +
                        `   Semoga sukses selalu!\n` +
                        `   (Ketik seperti biasa dengan Enter untuk baris baru)\n\n` +
                        `2. Menggunakan \\n:\n` +
                        `   ${usedPrefix + command} Bye @user\\nSemoga sukses\n\n` +
                        `3. Balas Pesan (Reply):\n` +
                        `   Balas pesan teks yang sudah ada dengan: ${usedPrefix + command}\n\n` +
                        `Contoh:\n` +
                        `${usedPrefix + command} Selamat tinggal @user\n` +
                        `Semoga sukses selalu!\n\n` +
                        `Terima kasih telah bergabung di @subject\n\n` +
                        `Placeholder tersedia:\n` +
                        `• @user = mention pengguna\n` +
                        `• @subject = nama grup\n` +
                        `• @desc = deskripsi grup`
                    );
                }
            } else {
                chat.sBye = finalText;
                return m.reply(
                    `Sukses Mengatur Pesan Left\n\n` +
                    `Pesan baru:\n` +
                    `${finalText}\n\n` +
                    `Pesan ini akan dikirim saat seseorang keluar dari grup.\n` +
                    `Pastikan fitur aktif dengan mengetik: ${usedPrefix}left on`
                );
            }
        }
    } catch (e) {
        conn.logger?.error(e);
        return m.reply(`Error: ${e.message}`);
    }
};

handler.help = [
    "setwelcome",
    "setbye"
];
handler.tags = ["admin"];
handler.command = ['setwelcome', 'setwlc', 'setwel', 'setbye', 'setleft'];
handler.group = true;
handler.admin = true;

export default handler;