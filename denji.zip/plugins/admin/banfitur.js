/**
 * Ban/Unban fitur per grup (admin only)
 * Member ter-block, admin & owner tetap bisa pakai
 * 
 * Ban 1 command = seluruh alias plugin ikut ter-ban
 * Contoh: .banfitur s → sticker, stiker, s semua ter-ban
 *
 *   .banfitur sticker
 *   .unbanfitur sticker  
 *   .listbanfitur
 */

let handler = async (m, { command, text, usedPrefix }) => {
  if (!text && !['listbanfitur', 'listbannedfitur'].includes(command)) {
    return m.reply(
      `📌 *Penggunaan:*\n` +
      `• *${usedPrefix}banfitur <command>* — nonaktifkan fitur\n` +
      `• *${usedPrefix}unbanfitur <command>* — aktifkan kembali\n` +
      `• *${usedPrefix}listbanfitur* — lihat daftar\n\n` +
      `Contoh: *${usedPrefix}banfitur sticker*\n` +
      `→ Semua alias (sticker/stiker/s) ikut ter-ban`
    )
  }

  const cmd = (text || '').toLowerCase().trim()

  switch (command) {
    case 'banfitur':
    case 'bannedfitur':
    case 'disablefitur': {
      // Cari semua alias dari plugin yang punya command ini
      const aliases = global.findAllAliases(cmd)
      const success = global.addBanFitur(m.chat, cmd)

      if (success) {
        let msg = `✅ Fitur *${cmd}* berhasil di-*nonaktifkan* di grup ini.`
        if (aliases.length > 1) {
          msg += `\n📋 Alias yang ikut ter-ban: ${aliases.join(', ')}`
        }
        msg += `\n\n👤 Member tidak bisa pakai, admin tetap bisa.`
        m.reply(msg)
      } else {
        m.reply(`⚠️ Fitur *${cmd}* sudah ada di daftar ban grup ini.`)
      }
      break
    }

    case 'unbanfitur':
    case 'unbannedfitur':
    case 'enablefitur': {
      const success = global.delBanFitur(m.chat, cmd)
      if (success) {
        const aliases = global.findAllAliases(cmd)
        let msg = `✅ Fitur *${cmd}* berhasil di-*aktifkan* kembali.`
        if (aliases.length > 1) {
          msg += `\n📋 Alias yang ikut aktif: ${aliases.join(', ')}`
        }
        m.reply(msg)
      } else {
        m.reply(`⚠️ Fitur *${cmd}* tidak ditemukan di daftar ban grup ini.`)
      }
      break
    }

    case 'listbanfitur':
    case 'listbannedfitur': {
      const list = global.listBanFitur(m.chat)
      if (list.length === 0) {
        m.reply('📋 Tidak ada fitur yang di-ban di grup ini.')
      } else {
        let msg = `📋 *Daftar Fitur yang Di-ban:*\n\n`
        list.forEach((f, i) => {
          const aliases = global.findAllAliases(f)
          msg += `${i + 1}. *${f}*`
          if (aliases.length > 1) {
            msg += ` → alias: ${aliases.filter(a => a !== f).join(', ')}`
          }
          msg += '\n'
        })
        msg += `\n_Total: ${list.length} fitur_`
        m.reply(msg)
      }
      break
    }
  }
}

handler.command = ['banfitur', 'bannedfitur', 'disablefitur', 'unbanfitur', 'unbannedfitur', 'enablefitur', 'listbanfitur', 'listbannedfitur']
handler.help = ['banfitur <cmd>', 'unbanfitur <cmd>', 'listbanfitur']
handler.tags = ['admin']
handler.group = true
handler.admin = true
handler.botAdmin = false

export default handler