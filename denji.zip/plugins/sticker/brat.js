let handler = async (m, { conn, text }) => {
    try {
        let input = text?.trim() || m.quoted?.text?.trim()
        if (!input) return m.reply('📝 *Cara pakai:*\n!brat <teks>\natau reply pesan')

        await m.react('🕒')

        const controller = new AbortController()
        const timeout = setTimeout(() => controller.abort(), 15_000)

        let res
        try {
            res = await fetch(`https://api.deline.web.id/maker/brat?text=${encodeURIComponent(input)}`, {
                signal: controller.signal
            })
        } finally {
            clearTimeout(timeout)
        }

        if (!res.ok) throw new Error(`HTTP ${res.status}: ${res.statusText}`)

        const imageBuffer = Buffer.from(await res.arrayBuffer())
        if (imageBuffer.length === 0) throw new Error('Buffer gambar kosong')

        // Langsung lempar Buffer — sendSticker sudah support ini
        await conn.sendSticker(m.chat, imageBuffer, m, {
            packname: global.stickpack || 'Brat Sticker',
            author:   global.stickauth || 'Wea Bot'
        })

        await m.react('✅')
    } catch (e) {
        console.error('[BRAT ERROR]', e)
        await m.react('❌')
        await m.reply(
            e.name === 'AbortError'
                ? '⏱️ Request timeout, coba lagi nanti'
                : `❌ Gagal membuat stiker: ${e.message}`
        )
    }
}

handler.help    = ['brat <teks>']
handler.tags    = ['sticker']
handler.command = ['brat']
handler.limit   = true

export default handler
