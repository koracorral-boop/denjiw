let handler = async (m, { text }) => {
	let q = m.quoted ? m.quoted : m;
	let mime = (q.msg || q).mimetype || '';

	if (/image|video|webp/.test(mime)) {
		if ((q.msg?.seconds || q.seconds) > 10) {
			return m.reply('Video harus berdurasi di bawah 10 detik.');
		}

		let media = await q.download();

		// Parsing packname & author dari text, fallback ke global.stickpack/global.stickauth
		let options = {};
		if (text) {
			const [packname, author] = text.split(/[,|\-+&]/);
			options.packname = (packname || '').trim();
			options.author = (author || '').trim();
		} else {
			// Gunakan variabel global untuk pack dan auth default
			options.packname = (global.stickpack || 'Default Sticker Pack').trim();
			options.author = (global.stickauth || 'Default Author').trim();
		}

		await conn.sendSticker(m.chat, media, m, options);
	} else {
		m.reply('Kirim atau reply media untuk dijadikan stiker.');
	}
};

handler.help = ['sticker'];
handler.tags = ['sticker'];
handler.command = ['sticker', 's', 'stiker'];

export default handler;