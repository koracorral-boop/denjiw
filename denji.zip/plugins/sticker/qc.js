let handler = async (m, { conn, text }) => {
    try {
        let input = text?.trim() || m.quoted?.text?.trim()
        if (!input) return m.reply('📝 *Cara pakai:*\n!qc <teks>\natau reply pesan')
        await m.react('🕒')
        const sender = m.quoted?.sender || m.sender
        const name = await conn.getName(sender)
        let ppUrl
        try {
            ppUrl = await conn.profilePictureUrl(sender, 'image')
        } catch {
            ppUrl = 'https://i.ibb.co/3Fh9V6p/avatar-contact.png'
        }
        // Download foto profil
        const ppRes = await fetch(ppUrl)
        if (!ppRes.ok) throw new Error('Gagal mengambil foto profil')
        const ppBuffer = Buffer.from(await ppRes.arrayBuffer())
        if (!ppBuffer.length) throw new Error('Buffer foto profil kosong')
        // Upload ke tmpfiles
        const form = new FormData()
        form.append('file', new Blob([ppBuffer]), 'profile.jpg')
        const upRes = await fetch('https://tmpfiles.org/api/v1/upload', {
            method: 'POST',
            body: form
        })
        if (!upRes.ok) throw new Error(`Upload tmpfiles gagal: HTTP ${upRes.status}`)
        const upJson = await upRes.json()
        if (!upJson?.data?.url) throw new Error('URL tmpfiles tidak ditemukan')
        // Ubah URL tmpfiles agar jadi direct link
        const tmpUrl = upJson.data.url.replace('tmpfiles.org/', 'tmpfiles.org/dl/')
        const apiUrl = `https://api.stellarwa.xyz/tools/quotesticker?method=url&url=${encodeURIComponent(tmpUrl)}&name=${encodeURIComponent(name || 'User')}&text=${encodeURIComponent(input)}&solidColor=${encodeURIComponent('#FFFFFF')}&key=api-1en3J`
        const controller = new AbortController()
        const timeout = setTimeout(() => controller.abort(), 15_000)
        let res
        try {
            res = await fetch(apiUrl, {
                signal: controller.signal
            })
        } finally {
            clearTimeout(timeout)
        }
        if (!res.ok) throw new Error(`HTTP ${res.status}: ${res.statusText}`)
        const imageBuffer = Buffer.from(await res.arrayBuffer())
        if (!imageBuffer.length) throw new Error('Buffer gambar kosong')
        await conn.sendSticker(m.chat, imageBuffer, m, {
            packname: global.stickpack || 'Quote Sticker',
            author: global.stickauth || 'Wea Bot'
        })
        await m.react('✅')
    } catch (e) {
        console.error('[QC ERROR]', e)
        await m.react('❌')
        await m.reply(
            e.name === 'AbortError'
                ? '⏱️ Request timeout, coba lagi nanti'
                : `❌ Gagal membuat stiker quote: ${e.message}`
        )
    }
}
handler.help = ['qc <teks>']
handler.tags = ['sticker']
handler.command = ['qc', 'quotesticker']
handler.limit = true
export default handler