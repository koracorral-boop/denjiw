import { createCanvas, loadImage } from 'canvas'

function wrapText(ctx, text, maxWidth) {
  const words = text.split(/\s+/)
  const lines = []
  let line = ''

  for (const word of words) {
    const testLine = line ? `${line} ${word}` : word
    const width = ctx.measureText(testLine).width

    if (width > maxWidth && line) {
      lines.push(line)
      line = word
    } else {
      line = testLine
    }
  }

  if (line) lines.push(line)
  return lines
}

function fitText(ctx, text, maxWidth, startSize, minSize = 16) {
  let fontSize = startSize
  let lines = []

  while (fontSize >= minSize) {
    ctx.font = `bold ${fontSize}px Impact, Arial, sans-serif`
    lines = wrapText(ctx, text.toUpperCase(), maxWidth)

    if (lines.every(line => ctx.measureText(line).width <= maxWidth)) {
      break
    }

    fontSize -= 2
  }

  return { fontSize, lines }
}

function drawOutlinedText(ctx, text, x, y, options = {}) {
  const {
    maxWidth,
    startSize,
    minSize,
    fromBottom = false,
    lineGap = 0.15
  } = options

  if (!text || text === '_') return

  const { fontSize, lines } = fitText(ctx, text, maxWidth, startSize, minSize)
  ctx.font = `bold ${fontSize}px Impact, Arial, sans-serif`
  ctx.textAlign = 'center'
  ctx.textBaseline = 'top'
  ctx.fillStyle = 'white'
  ctx.strokeStyle = 'black'
  ctx.lineJoin = 'round'
  ctx.lineWidth = Math.max(3, fontSize * 0.12)

  const lineHeight = fontSize * (1 + lineGap)
  const totalHeight = lines.length * lineHeight

  let startY = fromBottom ? y - totalHeight : y

  for (const line of lines) {
    ctx.strokeText(line, x, startY)
    ctx.fillText(line, x, startY)
    startY += lineHeight
  }
}

async function createSmeme(buffer, topText, bottomText) {
  const img = await loadImage(buffer)

  const canvas = createCanvas(img.width, img.height)
  const ctx = canvas.getContext('2d')

  ctx.drawImage(img, 0, 0, img.width, img.height)

  const paddingX = canvas.width * 0.05
  const paddingY = canvas.height * 0.05
  const maxWidth = canvas.width - paddingX * 2

  const startFontSize = Math.floor(canvas.width / 8)
  const minFontSize = Math.max(16, Math.floor(canvas.width / 22))

  drawOutlinedText(ctx, topText, canvas.width / 2, paddingY, {
    maxWidth,
    startSize: startFontSize,
    minSize: minFontSize,
    fromBottom: false
  })

  drawOutlinedText(ctx, bottomText, canvas.width / 2, canvas.height - paddingY, {
    maxWidth,
    startSize: startFontSize,
    minSize: minFontSize,
    fromBottom: true
  })

  return canvas.toBuffer('image/png')
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
  const q = m.quoted ? m.quoted : m

  if (!text) {
    return m.reply(`Contoh:\n${usedPrefix + command} teks atas|teks bawah`)
  }

  let [atas, bawah] = text.split('|')
  atas = atas?.trim() || '_'
  bawah = bawah?.trim() || '_'

  let buffer
  try {
    buffer = await q.download()
  } catch {
    return m.reply(`Balas gambar dengan caption:\n${usedPrefix + command} teks atas|teks bawah`)
  }

  try {
    const imageBuffer = await createSmeme(buffer, atas, bawah)

    await conn.sendSticker(m.chat, imageBuffer, m, {
      packname: global.stickpack || 'Sticker',
      author: global.stickauth || 'Bot'
    })
  } catch (e) {
    console.error(e)
    await m.reply('❌ Gagal membuat meme sticker')
  }
}

handler.help = ['smeme <teks atas>|teks bawah>']
handler.tags = ['sticker']
handler.command = ['smeme', 'smim']
handler.limit = true

export default handler