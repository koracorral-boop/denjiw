import { smsg } from './lib/simple.js'
import { format } from 'util'
import { fileURLToPath } from 'url'
import path from 'path'
import { unwatchFile, watchFile, readdirSync, statSync, existsSync, readFileSync, writeFileSync, mkdirSync } from 'fs'
import chalk from 'chalk'

// ==================== CONSTANTS ====================
const __filename_current = fileURLToPath(import.meta.url)
const __dirname_current = path.dirname(__filename_current)
const CACHE_TTL = 5 * 60 * 1000
const DB_REIMPORT_INTERVAL = 5 * 60 * 1000
const SCHEDULER_CHECK_INTERVAL = 15000

// ==================== UTILITY FUNCTIONS ====================

const isNumber = (x) => typeof x === 'number' && !isNaN(x)

const str2Regex = (str) => str.replace(/[|\\{}()[\]^$+*?.]/g, '\\$&')

const getWibDate = () => {
  try {
    const now = new Date(new Date().toLocaleString('en-US', { timeZone: 'Asia/Jakarta' }))
    return {
      date: now,
      hours: now.getHours(),
      minutes: now.getMinutes(),
      todayDate: `${now.getFullYear()}-${now.getMonth() + 1}-${now.getDate()}`
    }
  } catch {
    const now = new Date()
    return {
      date: now,
      hours: now.getHours(),
      minutes: now.getMinutes(),
      todayDate: `${now.getFullYear()}-${now.getMonth() + 1}-${now.getDate()}`
    }
  }
}

const resolveJid = (user) => {
  try {
    let jid = ''
    if (typeof user === 'string') {
      jid = user
    } else if (typeof user === 'object' && user !== null) {
      jid = user?.id || user?.phoneNumber || ''
    }
    if (!jid) return null
    if (!jid.includes('@')) jid += '@s.whatsapp.net'
    return jid
  } catch {
    return null
  }
}

function getPluginFiles(dir, base = '') {
  let results = []
  try {
    if (!existsSync(dir)) return results
    const entries = readdirSync(dir)
    for (const entry of entries) {
      try {
        const fullPath = path.join(dir, entry)
        const relativePath = path.join(base, entry)
        const stat = statSync(fullPath)
        if (stat.isDirectory()) {
          results = results.concat(getPluginFiles(fullPath, relativePath))
        } else if (entry.endsWith('.js')) {
          results.push(relativePath)
        }
      } catch (e) {
        console.error(chalk.redBright(`[PLUGIN FILES] Error reading: ${entry}`), e.message)
      }
    }
  } catch (e) {
    console.error(chalk.redBright('[PLUGIN FILES ERROR]'), e.message)
  }
  return results
}

// ==================== SAFE REPLY WRAPPER ====================

async function safeReply(m, text) {
  try {
    if (m && typeof m.reply === 'function' && text) {
      await m.reply(text)
    }
  } catch (e) {
    console.error(chalk.redBright('[REPLY ERROR]'), e.message)
  }
}

// ==================== JSON I/O HELPERS ====================

function ensureDir(filePath) {
  try {
    const dir = path.dirname(filePath)
    if (!existsSync(dir)) mkdirSync(dir, { recursive: true })
  } catch (e) {
    console.error(chalk.redBright('[ENSURE DIR ERROR]'), e.message)
  }
}

function readJsonSafe(filePath) {
  try {
    if (!existsSync(filePath)) return null
    const raw = readFileSync(filePath, 'utf-8')
    if (!raw || !raw.trim()) return null
    return JSON.parse(raw)
  } catch (e) {
    console.error(chalk.redBright(`[READ JSON ERROR] ${path.basename(filePath)}`), e.message)
    return null
  }
}

function writeJsonSafe(filePath, data) {
  try {
    ensureDir(filePath)
    writeFileSync(filePath, JSON.stringify(data, null, 2))
    return true
  } catch (e) {
    console.error(chalk.redBright(`[WRITE JSON ERROR] ${path.basename(filePath)}`), e.message)
    return false
  }
}

// ==================== PREMIUM GROUP (CACHED) ====================

const premgcPath = path.join(__dirname_current, './database/premiumgc.json')
let _premGCCache = null
let _premGCCacheTime = 0

function loadPremGC() {
  const now = Date.now()
  if (_premGCCache !== null && (now - _premGCCacheTime) < CACHE_TTL) {
    return _premGCCache
  }
  try {
    ensureDir(premgcPath)
    const parsed = readJsonSafe(premgcPath)
    if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
      _premGCCache = parsed
    } else {
      _premGCCache = {}
      writeJsonSafe(premgcPath, _premGCCache)
    }
    _premGCCacheTime = now
    return _premGCCache
  } catch (e) {
    console.error(chalk.redBright('[LOAD PREMGC ERROR]'), e.message)
    return _premGCCache || {}
  }
}

function savePremGC(data) {
  try {
    _premGCCache = data
    _premGCCacheTime = Date.now()
    writeJsonSafe(premgcPath, data)
  } catch (e) {
    console.error(chalk.redBright('[SAVE PREMGC ERROR]'), e.message)
  }
}

function isPremiumGroup(chatId) {
  try {
    if (!chatId || typeof chatId !== 'string' || !chatId.endsWith('@g.us')) return false
    const data = loadPremGC()
    if (!data || !data[chatId]) return false
    const entry = data[chatId]
    if (!entry.expiredAt || entry.expiredAt == 0) return true
    const expiredAt = Number(entry.expiredAt)
    if (isNaN(expiredAt)) return false
    if (Date.now() > expiredAt) {
      console.log(chalk.yellowBright(`[PREMGC] Expired & removed: ${chatId}`))
      delete data[chatId]
      savePremGC(data)
      return false
    }
    return true
  } catch (e) {
    console.error(chalk.redBright('[PREMGC CHECK ERROR]'), e.message)
    return false
  }
}

global.loadPremGC = loadPremGC
global.savePremGC = savePremGC
global.isPremiumGroup = isPremiumGroup

// ==================== EXTRACT PLUGIN COMMANDS HELPER ====================

function extractPluginCommands(pluginCommand) {
  try {
    if (!pluginCommand) return []
    if (typeof pluginCommand === 'string') return [pluginCommand.toLowerCase()]
    if (Array.isArray(pluginCommand)) {
      return pluginCommand
        .filter((cmd) => typeof cmd === 'string')
        .map((cmd) => cmd.toLowerCase())
    }
    return []
  } catch {
    return []
  }
}

global.extractPluginCommands = extractPluginCommands

// ==================== BAN FITUR PER-GROUP (CACHED) ====================

const banFiturPath = path.join(__dirname_current, './database/banfitur.json')
let _banFiturCache = null
let _banFiturCacheTime = 0

function loadBanFitur() {
  const now = Date.now()
  if (_banFiturCache !== null && (now - _banFiturCacheTime) < CACHE_TTL) {
    return _banFiturCache
  }
  try {
    ensureDir(banFiturPath)
    const parsed = readJsonSafe(banFiturPath)
    if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
      _banFiturCache = parsed
    } else {
      _banFiturCache = {}
      writeJsonSafe(banFiturPath, _banFiturCache)
    }
    _banFiturCacheTime = now
    return _banFiturCache
  } catch (e) {
    console.error(chalk.redBright('[LOAD BANFITUR ERROR]'), e.message)
    return _banFiturCache || {}
  }
}

function saveBanFitur(data) {
  try {
    _banFiturCache = data
    _banFiturCacheTime = Date.now()
    writeJsonSafe(banFiturPath, data)
  } catch (e) {
    console.error(chalk.redBright('[SAVE BANFITUR ERROR]'), e.message)
  }
}

function isPluginBannedInGroup(chatId, pluginCommand) {
  try {
    if (!chatId) return false
    const data = loadBanFitur()
    if (!data?.[chatId] || !Array.isArray(data[chatId])) return false
    const bannedList = data[chatId]
    const cmds = extractPluginCommands(pluginCommand)
    return cmds.some((cmd) => bannedList.includes(cmd))
  } catch (e) {
    console.error(chalk.redBright('[BANFITUR CHECK ERROR]'), e.message)
    return false
  }
}

function findBannedCommandInGroup(chatId, pluginCommand) {
  try {
    const data = loadBanFitur()
    if (!data?.[chatId] || !Array.isArray(data[chatId])) return null
    const bannedList = data[chatId]
    const cmds = extractPluginCommands(pluginCommand)
    return cmds.find((cmd) => bannedList.includes(cmd)) || null
  } catch {
    return null
  }
}

function addBanFitur(chatId, command) {
  try {
    if (!chatId || !command) return false
    const data = loadBanFitur()
    if (!data[chatId]) data[chatId] = []
    const cmd = command.toLowerCase()
    if (data[chatId].includes(cmd)) return false
    data[chatId].push(cmd)
    saveBanFitur(data)
    return true
  } catch (e) {
    console.error(chalk.redBright('[ADD BANFITUR ERROR]'), e.message)
    return false
  }
}

function delBanFitur(chatId, command) {
  try {
    if (!chatId || !command) return false
    const data = loadBanFitur()
    if (!data?.[chatId] || !Array.isArray(data[chatId])) return false
    const cmd = command.toLowerCase()
    const idx = data[chatId].indexOf(cmd)
    if (idx === -1) return false
    data[chatId].splice(idx, 1)
    if (data[chatId].length === 0) delete data[chatId]
    saveBanFitur(data)
    return true
  } catch (e) {
    console.error(chalk.redBright('[DEL BANFITUR ERROR]'), e.message)
    return false
  }
}

function listBanFitur(chatId) {
  try {
    const data = loadBanFitur()
    return Array.isArray(data?.[chatId]) ? data[chatId] : []
  } catch {
    return []
  }
}

function findAllAliases(command) {
  try {
    const cmd = (command || '').toLowerCase()
    if (!cmd) return [cmd]
    for (const name in global.plugins) {
      const plugin = global.plugins[name]
      if (!plugin) continue
      const cmds = extractPluginCommands(plugin.command)
      if (cmds.includes(cmd)) return cmds
    }
    return [cmd]
  } catch {
    return [command?.toLowerCase?.() || '']
  }
}

global.loadBanFitur = loadBanFitur
global.saveBanFitur = saveBanFitur
global.isPluginBannedInGroup = isPluginBannedInGroup
global.findBannedCommandInGroup = findBannedCommandInGroup
global.addBanFitur = addBanFitur
global.delBanFitur = delBanFitur
global.listBanFitur = listBanFitur
global.findAllAliases = findAllAliases

// ==================== BAN FITUR GLOBAL (CACHED) ====================

const banFiturGlobalPath = path.join(__dirname_current, './database/banfiturglobal.json')
let _banFiturGlobalCache = null
let _banFiturGlobalCacheTime = 0

function loadBanFiturGlobal() {
  const now = Date.now()
  if (_banFiturGlobalCache !== null && (now - _banFiturGlobalCacheTime) < CACHE_TTL) {
    return _banFiturGlobalCache
  }
  try {
    ensureDir(banFiturGlobalPath)
    const parsed = readJsonSafe(banFiturGlobalPath)
    if (Array.isArray(parsed)) {
      _banFiturGlobalCache = parsed
    } else {
      _banFiturGlobalCache = []
      writeJsonSafe(banFiturGlobalPath, _banFiturGlobalCache)
    }
    _banFiturGlobalCacheTime = now
    return _banFiturGlobalCache
  } catch (e) {
    console.error(chalk.redBright('[LOAD BANFITUR GLOBAL ERROR]'), e.message)
    return _banFiturGlobalCache || []
  }
}

function saveBanFiturGlobal(data) {
  try {
    _banFiturGlobalCache = data
    _banFiturGlobalCacheTime = Date.now()
    writeJsonSafe(banFiturGlobalPath, data)
  } catch (e) {
    console.error(chalk.redBright('[SAVE BANFITUR GLOBAL ERROR]'), e.message)
  }
}

function isPluginBannedGlobal(pluginCommand) {
  try {
    const data = loadBanFiturGlobal()
    if (!data || !data.length) return false
    const cmds = extractPluginCommands(pluginCommand)
    return cmds.some((cmd) => data.includes(cmd))
  } catch (e) {
    console.error(chalk.redBright('[BANFITUR GLOBAL CHECK ERROR]'), e.message)
    return false
  }
}

function findBannedCommandGlobal(pluginCommand) {
  try {
    const data = loadBanFiturGlobal()
    if (!data || !data.length) return null
    const cmds = extractPluginCommands(pluginCommand)
    return cmds.find((cmd) => data.includes(cmd)) || null
  } catch {
    return null
  }
}

function addBanFiturGlobal(command) {
  try {
    if (!command) return false
    const data = loadBanFiturGlobal()
    const cmd = command.toLowerCase()
    if (data.includes(cmd)) return false
    data.push(cmd)
    saveBanFiturGlobal(data)
    return true
  } catch (e) {
    console.error(chalk.redBright('[ADD BANFITUR GLOBAL ERROR]'), e.message)
    return false
  }
}

function delBanFiturGlobal(command) {
  try {
    if (!command) return false
    const data = loadBanFiturGlobal()
    const cmd = command.toLowerCase()
    const idx = data.indexOf(cmd)
    if (idx === -1) return false
    data.splice(idx, 1)
    saveBanFiturGlobal(data)
    return true
  } catch (e) {
    console.error(chalk.redBright('[DEL BANFITUR GLOBAL ERROR]'), e.message)
    return false
  }
}

function listBanFiturGlobal() {
  try {
    return loadBanFiturGlobal()
  } catch {
    return []
  }
}

global.loadBanFiturGlobal = loadBanFiturGlobal
global.saveBanFiturGlobal = saveBanFiturGlobal
global.isPluginBannedGlobal = isPluginBannedGlobal
global.findBannedCommandGlobal = findBannedCommandGlobal
global.addBanFiturGlobal = addBanFiturGlobal
global.delBanFiturGlobal = delBanFiturGlobal
global.listBanFiturGlobal = listBanFiturGlobal

// ==================== DATABASE MODULE (THROTTLED) ====================

let _dbModule = null
let _dbModuleTime = 0

async function runDatabaseSetup(m, conn) {
  try {
    const now = Date.now()
    if (!_dbModule || (now - _dbModuleTime) > DB_REIMPORT_INTERVAL) {
      _dbModule = await import(`./lib/database.js?v=${now}`)
      _dbModuleTime = now
    }
    if (_dbModule && typeof _dbModule.default === 'function') {
      await _dbModule.default(m, conn)
    }
  } catch (e) {
    console.error(chalk.redBright('[DATABASE SETUP ERROR]'), e.message)
  }
}

// ==================== AUTO RESET LIMIT ====================

function checkAutoResetLimit(conn) {
  try {
    const { todayDate } = getWibDate()
    const botJid = conn.user?.jid
    if (!botJid) return
    const settings = global.db.data?.settings?.[botJid]
    if (!settings) return
    if (settings.lastLimitReset === todayDate) return

    const defaultLimit = global.defaultLimit || 100
    const users = global.db.data?.users
    if (users) {
      for (const userId in users) {
        if (users[userId]) users[userId].limit = defaultLimit
      }
    }
    settings.lastLimitReset = todayDate
    console.log(chalk.greenBright(`[AUTO RESET] Semua limit user di-reset ke ${defaultLimit} | ${todayDate}`))
  } catch (e) {
    console.error(chalk.redBright('[AUTO RESET ERROR]'), e.message)
  }
}

// ==================== PERMISSION HELPERS ====================

function getPermissions(m, conn) {
  try {
    const botId = conn.decodeJid?.(global.conn?.user?.id) || conn.user?.jid || ''
    const ownerNumbers = Array.isArray(global.owner)
      ? global.owner.map(([number]) => number).filter(Boolean)
      : []

    const isROwner = [botId, ...ownerNumbers]
      .filter(Boolean)
      .map((v) => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net')
      .includes(m.sender)

    const isOwner = isROwner || m.fromMe

    const modsArr = Array.isArray(global.mods) ? global.mods : []
    const isMods = isOwner || modsArr
      .map((v) => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net')
      .includes(m.sender)

    const isPrems = isROwner || (global.db.data?.users?.[m.sender]?.premiumTime > 0)

    return { isROwner, isOwner, isMods, isPrems }
  } catch (e) {
    console.error(chalk.redBright('[PERMISSIONS ERROR]'), e.message)
    return { isROwner: false, isOwner: m?.fromMe || false, isMods: false, isPrems: false }
  }
}

async function getGroupData(m, conn) {
  if (!m.isGroup) return { groupMetadata: {}, participants: [], user: {}, bot: {} }

  try {
    let groupMetadata = null

    try {
      groupMetadata = conn.chats?.[m.chat]?.metadata || null
    } catch {}

    if (!groupMetadata) {
      try {
        groupMetadata = await conn.groupMetadata(m.chat)
      } catch (e) {
        console.error(chalk.yellowBright(`[GROUP META] Failed for ${m.chat}:`), e.message)
        groupMetadata = {}
      }
    }

    groupMetadata = groupMetadata || {}
    const participants = groupMetadata.participants || []

    const user = participants.find((u) => {
      try { return conn.getJid(u.id) === m.sender } catch { return false }
    }) || {}

    const bot = participants.find((u) => {
      try { return conn.getJid(u.id) === conn.user?.jid } catch { return false }
    }) || {}

    return { groupMetadata, participants, user, bot }
  } catch (e) {
    console.error(chalk.redBright('[GROUP DATA ERROR]'), e.message)
    return { groupMetadata: {}, participants: [], user: {}, bot: {} }
  }
}

function getAdminStatus(user, bot, isOwner) {
  try {
    const isRAdmin = isOwner || user?.admin === 'superadmin' || false
    const isAdmin = isOwner || isRAdmin || user?.admin === 'admin' || false
    const isBotAdmin = !!bot?.admin
    return { isRAdmin, isAdmin, isBotAdmin }
  } catch {
    return { isRAdmin: false, isAdmin: isOwner || false, isBotAdmin: false }
  }
}

// ==================== PRIVATE CHAT BLOCKER ====================

async function blockPrivateChat(m, conn) {
  console.log(chalk.redBright(`[BLOCKED] ${m.sender} mencoba chat private. Auto block + hapus chat!`))

  try {
    await conn.chatModify({
      delete: true,
      lastMessages: [{
        key: m.key,
        messageTimestamp: m.messageTimestamp
      }]
    }, m.sender)
    console.log(chalk.yellowBright(`[DELETE CHAT] Chat ${m.sender} berhasil dihapus.`))
  } catch {
    try {
      await conn.chatModify({
        clear: {
          messages: [{
            id: m.key?.id,
            fromMe: m.key?.fromMe,
            timestamp: m.messageTimestamp
          }]
        }
      }, m.sender)
      console.log(chalk.yellowBright(`[CLEAR CHAT] Chat ${m.sender} berhasil di-clear.`))
    } catch (e) {
      console.error(chalk.redBright('[CLEAR CHAT ERROR]'), m.sender, e.message)
    }
  }

  try {
    await conn.updateBlockStatus(m.sender, 'block')
    console.log(chalk.redBright(`[BLOCK] ${m.sender} berhasil diblokir.`))
  } catch (e) {
    console.error(chalk.redBright('[BLOCK ERROR]'), m.sender, e.message)
  }
}

// ==================== PLUGIN PREFIX MATCHER ====================

function matchPrefix(m, plugin, conn) {
  try {
    const _prefix = plugin.customPrefix ?? conn.prefix ?? global.prefix

    const candidates = _prefix instanceof RegExp
      ? [[_prefix.exec(m.text), _prefix]]
      : Array.isArray(_prefix)
        ? _prefix.map((p) => {
            const re = p instanceof RegExp ? p : new RegExp(str2Regex(p))
            return [re.exec(m.text), re]
          })
        : typeof _prefix === 'string'
          ? [[new RegExp(str2Regex(_prefix)).exec(m.text), new RegExp(str2Regex(_prefix))]]
          : [[[], new RegExp()]]

    return candidates.find((p) => p[1]) || null
  } catch (e) {
    console.error(chalk.redBright('[MATCH PREFIX ERROR]'), e.message)
    return null
  }
}

// ==================== PLUGIN PERMISSION CHECK ====================

function checkPluginPermission(plugin, m, conn, {
  isROwner, isOwner, isMods, isPrems, isAdmin, isBotAdmin,
  _user, usedPrefix, isPremGroup, command
}) {
  try {
    const fail = plugin.fail || global.dfail
    const baseName = path.basename(m.plugin || '')

    // ── Ban chat / ban user check ──
    if (m.chat in (global.db.data?.chats || {}) || m.sender in (global.db.data?.users || {})) {
      const chat = global.db.data.chats?.[m.chat]
      const user = global.db.data.users?.[m.sender]
      const exceptPlugins = ['owner-unbanchat.js', 'owner-exec.js', 'owner-exec2.js', 'tools-delete.js']

      if (!exceptPlugins.includes(baseName) && chat?.isBanned) return 'banned'
      if (baseName !== 'owner-unbanuser.js' && user?.banned) return 'banned'
    }

    // ── BAN FITUR GLOBAL ──
    if (isPluginBannedGlobal(plugin.command) && !isOwner) {
      const found = findBannedCommandGlobal(plugin.command) || command
      const aliases = extractPluginCommands(plugin.command)
      safeReply(m,
        `Fitur *${found}* sedang di-disable secara global oleh owner.` +
        (aliases.length > 1 ? `\nAlias ter-ban: ${aliases.join(', ')}` : '')
      )
      return 'denied'
    }

    // ── BAN FITUR PER-GROUP ──
    if (m.isGroup && isPluginBannedInGroup(m.chat, plugin.command) && !isAdmin && !isOwner) {
      const found = findBannedCommandInGroup(m.chat, plugin.command) || command
      const aliases = extractPluginCommands(plugin.command)
      safeReply(m,
        `Fitur *${found}* di-nonaktifkan di grup ini oleh admin.` +
        (aliases.length > 1 ? `\nAlias ter-ban: ${aliases.join(', ')}` : '') +
        `\nHanya admin yang bisa menggunakannya.`
      )
      return 'denied'
    }

    // ── Role-based checks (tetap berlaku untuk semua, termasuk premium group) ──
    if (plugin.rowner && plugin.owner && !(isROwner || isOwner)) { fail('owner', m, conn); return 'denied' }
    if (plugin.rowner && !isROwner) { fail('rowner', m, conn); return 'denied' }
    if (plugin.owner && !isOwner) { fail('owner', m, conn); return 'denied' }
    if (plugin.mods && !isMods) { fail('mods', m, conn); return 'denied' }

    // ── Structural checks (tetap berlaku untuk semua) ──
    if (plugin.group && !m.isGroup) { fail('group', m, conn); return 'denied' }
    if (plugin.group && plugin.botAdmin && !isBotAdmin) { fail('botAdmin', m, conn); return 'denied' }
    if (plugin.group && plugin.admin && !isAdmin) { fail('admin', m, conn); return 'denied' }
    if (plugin.private && m.isGroup) { fail('private', m, conn); return 'denied' }
    if (plugin.register === true && _user?.registered === false) { fail('unreg', m, conn); return 'denied' }

    // ── PREMIUM GROUP BYPASS ──
    // Member & admin di premium group → bypass premium, limit, dan level
    if (isPremGroup === true) return 'ok'

    // ── Premium user check (hanya untuk NON premium group) ──
    if (plugin.premium && !isPrems) { fail('premium', m, conn); return 'denied' }

    // ── Limit check (hanya untuk NON premium group) ──
    if (!isPrems && plugin.limit && (global.db.data?.users?.[m.sender]?.limit || 0) < plugin.limit * 1) {
      safeReply(m, `Limit Anda telah habis. Silakan beli melalui *${usedPrefix}buy limit*.`)
      return 'denied'
    }

    // ── Level check (hanya untuk NON premium group) ──
    if (plugin.level > (_user?.level || 0)) {
      safeReply(m, `Diperlukan level ${plugin.level} untuk menggunakan perintah ini.\nLevel Anda saat ini: ${_user?.level || 0}`)
      return 'denied'
    }

    return 'ok'
  } catch (e) {
    console.error(chalk.redBright('[PERMISSION CHECK ERROR]'), e.message)
    return 'ok'
  }
}

// ==================== MAIN HANDLER ====================

export async function handler(chatUpdate) {
  if (!chatUpdate) return
  this.pushMessage?.(chatUpdate.messages)?.catch?.(() => {})

  let m = chatUpdate.messages?.[chatUpdate.messages?.length - 1]
  if (!m) return

  if (global.db.data == null) {
    try {
      await Promise.race([
        global.loadDatabase(),
        new Promise((_, reject) => setTimeout(() => reject(new Error('DB load timeout')), 15000))
      ])
    } catch (e) {
      console.error(chalk.redBright('[DB LOAD ERROR]'), e.message)
      return
    }
  }

  if (!global.db.data) return

  let isPremGroup = false // ← deklarasi di scope handler agar bisa diakses di finally

  try {
    m = smsg(this, m) || m
    if (!m) return

    m.exp = 0
    m.limit = false

    if (!m.sender) return
    if (m.sender.endsWith('@broadcast') || m.sender.endsWith('@newsletter')) return

    await runDatabaseSetup(m, this)

    checkAutoResetLimit(this)

    if (global.opts?.pconly && m.isGroup) return
    if (global.opts?.gconly && !m.isGroup) return
    if (typeof m.text !== 'string') m.text = ''

    const { isROwner, isOwner, isMods, isPrems } = getPermissions(m, this)

    if (m.isGroup) {
      isPremGroup = isPremiumGroup(m.chat)
    }
    m.isPremGroup = isPremGroup

    if (!m.isGroup && !isOwner && !isROwner) {
      await blockPrivateChat(m, this)
      return
    }

    const botJid = this.user?.jid
    if (!botJid) return
    const settings = global.db.data?.settings?.[botJid]
    if (!settings?.public && !isMods && !isOwner && !m.fromMe) return
    if (m.isBaileys) return

    m.exp += Math.ceil(Math.random() * 10)

    const _user = global.db.data?.users?.[m.sender]

    const { groupMetadata, participants, user, bot } = await getGroupData(m, this)
    const { isRAdmin, isAdmin, isBotAdmin } = getAdminStatus(user, bot, isOwner)

    const pluginsDir = path.join(__dirname_current, './plugins')

    // ==================== PLUGIN LOOP ====================

    for (const name in global.plugins) {
      const plugin = global.plugins[name]
      if (!plugin || plugin.disabled) continue

      const __filename = path.join(pluginsDir, name)

      // --- plugin.all ---
      if (typeof plugin.all === 'function') {
        try {
          await plugin.all.call(this, m, {
            chatUpdate,
            __dirname: pluginsDir,
            __filename
          })
        } catch (e) {
          console.error(chalk.redBright('[PLUGIN ALL ERROR]'), name, e.message)
        }
      }

      // --- matchPrefix ---
      const match = matchPrefix(m, plugin, this)

      // --- plugin.before ---
      if (typeof plugin.before === 'function') {
        try {
          if (await plugin.before.call(this, m, {
            match, conn: this, participants, groupMetadata,
            user, bot, isROwner, isOwner, isRAdmin, isAdmin,
            isBotAdmin, isPrems, isPremGroup, chatUpdate,
            __dirname: pluginsDir, __filename
          })) continue
        } catch (e) {
          console.error(chalk.redBright('[PLUGIN BEFORE ERROR]'), name, e.message)
        }
      }

      if (typeof plugin !== 'function') continue

      if (!match || !match[0]) continue

      const usedPrefix = (match[0] || '')[0]
      if (!usedPrefix) continue

      const noPrefix = m.text.replace(usedPrefix, '')
      let [command, ...args] = noPrefix.trim().split(/\s+/).filter(Boolean)
      args = args || []
      const _args = noPrefix.trim().split(/\s+/).slice(1)
      const text = _args.join(' ')
      command = (command || '').toLowerCase()

      if (!command) continue

      const isAccept = plugin.command instanceof RegExp
        ? plugin.command.test(command)
        : Array.isArray(plugin.command)
          ? plugin.command.some((cmd) => cmd instanceof RegExp ? cmd.test(command) : cmd === command)
          : typeof plugin.command === 'string'
            ? plugin.command === command
            : false

      if (!isAccept) continue

      m.plugin = name

      const permResult = checkPluginPermission(plugin, m, this, {
        isROwner, isOwner, isMods, isPrems, isAdmin, isBotAdmin,
        _user, usedPrefix, isPremGroup, command
      })
      if (permResult === 'banned') return
      if (permResult === 'denied') continue

      m.isCommand = true

      const xp = 'exp' in plugin ? parseInt(plugin.exp) : 17
      if (xp > 200) {
        safeReply(m, 'Terdeteksi kecurangan.')
      } else {
        m.exp += xp
      }

      const extra = {
        match, usedPrefix, noPrefix, _args, args, command, text,
        conn: this, participants, groupMetadata, user, bot,
        isROwner, isOwner, isRAdmin, isAdmin, isBotAdmin, isPrems, isPremGroup,
        chatUpdate, __dirname: pluginsDir, __filename
      }

      try {
        await plugin.call(this, m, extra)

        // ── LIMIT ASSIGNMENT ──
        // Premium group → SELALU false, tidak pernah potong limit
        if (isPremGroup) {
          m.limit = false                                     // ← OK (sudah ada)
        } else if (!isPrems) {
          m.limit = m.limit || plugin.limit || false
        }
      } catch (e) {
        m.error = e
        if (isPremGroup) m.limit = false                      // ← FIX 1: reset saat error
        console.error(chalk.redBright('[PLUGIN ERROR]'), name, e)
        if (e) {
          try {
            safeReply(m, format(e))
          } catch {}
        }
      } finally {
        // ── FIX 2: paksa reset sebelum plugin.after ──
        if (isPremGroup) m.limit = false

        if (typeof plugin.after === 'function') {
          try {
            await plugin.after.call(this, m, extra)
          } catch (e) {
            console.error(chalk.redBright('[PLUGIN AFTER ERROR]'), name, e.message)
          }
        }

        // ── FIX 3: paksa reset SETELAH plugin.after ──
        // (plugin.after bisa saja men-set m.limit lagi)
        if (isPremGroup) m.limit = false

        // ── LIMIT MESSAGE ──
        // Premium group → TIDAK tampilkan pesan limit
        if (m.limit && !isPremGroup) {
          const userLimit = global.db.data?.users?.[m.sender]?.limit || 0
          const sisaLimit = userLimit - m.limit * 1
          safeReply(m, `${+m.limit} limit digunakan [Sisa limit ${sisaLimit}]`)
        }
      }

      break
    }
  } catch (e) {
    console.error(chalk.redBright('[HANDLER ERROR]'), e)
  } finally {
    try {
      if (m) {
        // ── FIX 4: re-verifikasi status premium group sebagai safety net ──
        // Jika variabel isPremGroup gagal di-set (misal error sebelumnya),
        // cek ulang langsung dari isPremiumGroup()
        const _finalPremGroup = isPremGroup || (m.isGroup && isPremiumGroup(m.chat))

        // ── FIX 5: paksa m.limit = false untuk premium group ──
        if (_finalPremGroup) m.limit = false

        const user = global.db.data?.users?.[m.sender]
        if (user) {
          if (isNumber(m.exp)) user.exp = (user.exp || 0) + m.exp

          // ── LIMIT DEDUCTION ──
          // Premium group → JANGAN pernah kurangi limit user
          if (_finalPremGroup) {
            // skip — member & admin bebas tanpa potong limit
          } else {
            if (m.limit) {
              user.limit = (user.limit || 0) - m.limit * 1
            }
          }
        }

        if (m.plugin) {
          const stats = global.db.data?.stats
          if (stats) {
            const now = Date.now()
            let stat = stats[m.plugin]

            if (!stat) {
              stat = stats[m.plugin] = {
                total: 0,
                success: 0,
                last: 0,
                lastSuccess: 0
              }
            }

            if (!isNumber(stat.total)) stat.total = 0
            if (!isNumber(stat.success)) stat.success = 0
            if (!isNumber(stat.last)) stat.last = 0
            if (!isNumber(stat.lastSuccess)) stat.lastSuccess = 0

            stat.total += 1
            stat.last = now

            if (m.error == null) {
              stat.success += 1
              stat.lastSuccess = now
            }
          }
        }
      }
    } catch (e) {
      console.error(chalk.redBright('[HANDLER FINALLY STATS ERROR]'), e.message)
    }

    try {
      await (await import('./lib/print.js')).default(m, this)
    } catch (e) {
      console.log(m, m?.quoted, e)
    }

    try {
      const botJid = this.user?.jid
      if (botJid && global.db.data?.settings?.[botJid]?.autoread) {
        await this.readMessages([m.key]).catch(() => {})
      }
    } catch {}
  }
}

// ==================== PARTICIPANTS UPDATE ====================

export async function participantsUpdate({ id, participants, action, simulate = false }) {
  if (this.isInit && !simulate) return

  if (!global.db.data) {
    try {
      await global.loadDatabase()
    } catch {
      return
    }
  }
  if (!global.db.data) return

  const chat = global.db.data.chats?.[id] || {}

  let groupMetadata
  try {
    groupMetadata = this.chats?.[id]?.metadata || (await this.groupMetadata(id))
  } catch (e) {
    console.error(chalk.redBright('[GROUP META ERROR]'), e.message)
    groupMetadata = { subject: id, desc: '', ephemeralDuration: 0 }
  }

  groupMetadata = groupMetadata || {}
  const groupName = groupMetadata.subject || this.getName?.(id) || id
  const groupDesc = groupMetadata.desc || ''
  const ephemeral = groupMetadata.ephemeralDuration || 0

  const formatText = (template, jid) => {
    try {
      return template
        .replace(/@user/g, `@${jid.split('@')[0]}`)
        .replace(/@subject/g, groupName)
        .replace(/@desc/g, groupDesc)
    } catch {
      return template
    }
  }

  switch (action) {

    case 'add': {
      if (!chat.welcome) break
      for (const participant of participants) {
        try {
          const jid = resolveJid(participant)
          if (!jid) continue

          const template = chat.sWelcome ||
            this.welcome ||
            'Selamat datang, @user!\nDi grup @subject\n\n@desc'

          const welcomeText = formatText(template, jid)

          await this.sendMessage(id, {
            text: welcomeText,
            mentions: [jid]
          }, {
            ephemeralExpiration: ephemeral
          }).catch((e) => console.error(chalk.redBright('[WELCOME SEND ERROR]'), e.message))

          console.log(chalk.greenBright(`[WELCOME] ${jid.split('@')[0]} → ${groupName}`))
        } catch (e) {
          console.error(chalk.redBright('[WELCOME ERROR]'), e.message)
        }
      }
      break
    }

    case 'remove': {
      if (!chat.left) break
      for (const participant of participants) {
        try {
          const jid = resolveJid(participant)
          if (!jid) continue

          const template = chat.sLeft ||
            chat.sBye ||
            this.left ||
            'Sampai jumpa, @user!'

          const leftText = formatText(template, jid)

          await this.sendMessage(id, {
            text: leftText,
            mentions: [jid]
          }, {
            ephemeralExpiration: ephemeral
          }).catch((e) => console.error(chalk.redBright('[LEFT SEND ERROR]'), e.message))

          console.log(chalk.yellowBright(`[LEFT] ${jid.split('@')[0]} ← ${groupName}`))
        } catch (e) {
          console.error(chalk.redBright('[LEFT ERROR]'), e.message)
        }
      }
      break
    }

    case 'promote': {
      if (!chat.detect) break
      for (const participant of participants) {
        try {
          const jid = resolveJid(participant)
          if (!jid) continue

          await this.sendMessage(id, {
            text: `@${jid.split('@')[0]} telah dipromosikan menjadi admin!`,
            mentions: [jid]
          }, {
            ephemeralExpiration: ephemeral
          }).catch((e) => console.error(chalk.redBright('[PROMOTE SEND ERROR]'), e.message))

          console.log(chalk.cyanBright(`[PROMOTE] ${jid.split('@')[0]} → admin | ${groupName}`))
        } catch (e) {
          console.error(chalk.redBright('[PROMOTE ERROR]'), e.message)
        }
      }
      break
    }

    case 'demote': {
      if (!chat.detect) break
      for (const participant of participants) {
        try {
          const jid = resolveJid(participant)
          if (!jid) continue

          await this.sendMessage(id, {
            text: `@${jid.split('@')[0]} telah diturunkan dari jabatan admin.`,
            mentions: [jid]
          }, {
            ephemeralExpiration: ephemeral
          }).catch((e) => console.error(chalk.redBright('[DEMOTE SEND ERROR]'), e.message))

          console.log(chalk.cyanBright(`[DEMOTE] ${jid.split('@')[0]} → member | ${groupName}`))
        } catch (e) {
          console.error(chalk.redBright('[DEMOTE ERROR]'), e.message)
        }
      }
      break
    }
  }
}

// ==================== DEFAULT FAIL MESSAGES ====================

global.dfail = (type, m, conn) => {
  const messages = {
    rowner: 'Perintah ini hanya dapat digunakan oleh developer bot.',
    owner: 'Perintah ini hanya dapat digunakan oleh pemilik bot.',
    mods: 'Perintah ini hanya dapat digunakan oleh moderator.',
    premium: 'Perintah ini hanya tersedia untuk pengguna premium.',
    group: 'Perintah ini hanya dapat digunakan di dalam grup.',
    private: 'Perintah ini hanya dapat digunakan di chat pribadi.',
    admin: 'Perintah ini hanya dapat digunakan oleh admin grup.',
    botAdmin: 'Bot perlu dijadikan admin terlebih dahulu untuk menjalankan perintah ini.',
    unreg: 'Anda belum terdaftar. Silakan lakukan pendaftaran terlebih dahulu dengan mengetik:\n.daftar Nama.Umur'
  }

  const msg = messages[type]
  if (msg) safeReply(m, msg)
}

// ==================== FILE WATCHER ====================

const file = __filename_current
watchFile(file, async () => {
  unwatchFile(file)
  console.log(chalk.redBright("Update 'handler.js'"))
  try {
    if (global.reloadHandler) console.log(await global.reloadHandler())
  } catch (e) {
    console.error(chalk.redBright('[RELOAD HANDLER ERROR]'), e.message)
  }
})

// ==================== SCHEDULER AUTO RESET LIMIT 00:00 WIB ====================

let lastResetDate = ''
let _schedulerInterval = null

function startLimitResetScheduler() {
  if (_schedulerInterval) {
    clearInterval(_schedulerInterval)
    _schedulerInterval = null
  }

  _schedulerInterval = setInterval(async () => {
    try {
      if (!global.db.data) return

      const { hours, minutes, todayDate } = getWibDate()

      if (hours === 0 && minutes <= 3 && lastResetDate !== todayDate) {
        lastResetDate = todayDate
        const defaultLimit = global.defaultLimit || 500

        const users = global.db.data?.users
        if (users) {
          for (const userId in users) {
            if (users[userId]) users[userId].limit = defaultLimit
          }
        }

        const settings = global.db.data?.settings
        if (settings) {
          for (const botId in settings) {
            if (settings[botId]) settings[botId].lastLimitReset = todayDate
          }
        }

        console.log(chalk.greenBright(`[SCHEDULER] Semua limit user di-reset ke ${defaultLimit} | 00:00 WIB - ${todayDate}`))
      }
    } catch (e) {
      console.error(chalk.redBright('[SCHEDULER ERROR]'), e.message)
    }
  }, SCHEDULER_CHECK_INTERVAL)

  if (_schedulerInterval.unref) _schedulerInterval.unref()
}

startLimitResetScheduler()

// ==================== EXPORTS ====================

export { getPluginFiles }