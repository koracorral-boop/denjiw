import './config.js'
global.opts = global.opts || {}

import { createRequire } from 'module'
import path, { join } from 'path'
import { fileURLToPath, pathToFileURL } from 'url'
import { platform } from 'process'

// ==================== GLOBAL HELPERS ====================

global.__filename = function filename(pathURL = import.meta.url, rmPrefix = platform !== 'win32') {
  return rmPrefix
    ? /file:\/\/\//.test(pathURL) ? fileURLToPath(pathURL) : pathURL
    : pathToFileURL(pathURL).toString()
}
global.__dirname = function dirname(pathURL) {
  return path.dirname(global.__filename(pathURL, true))
}
global.__require = function require(dir = import.meta.url) {
  return createRequire(dir)
}

import fs from 'fs'
import { spawn } from 'child_process'
import { tmpdir } from 'os'
import { format } from 'util'
import { parentPort } from 'worker_threads'
import { makeWASocket, protoType, serialize } from './lib/simple.js'
import chalk from 'chalk'
import pino from 'pino'
import syntaxerror from 'syntax-error'
import { Low, JSONFile } from 'lowdb'
import {
  useMultiFileAuthState,
  Browsers,
  fetchLatestBaileysVersion,
  makeCacheableSignalKeyStore,
  DisconnectReason,
} from 'baileys'
import NodeCache from 'node-cache'

protoType()
serialize()

// ==================== CONSTANTS ====================

const __dirname = global.__dirname(import.meta.url)
const logger = pino({ level: 'silent' })
const fatalLogger = logger.child({ level: 'fatal', stream: 'store' })
const groupCache = new NodeCache({ stdTTL: 300, useClones: false })

global.prefix = new RegExp(
  '^[' + '‎/!#$%+£¢€¥^°=¶∆×÷π√✓©®:;?&.\\-'.replace(/[|\\{}[\]()^$+*?.-]/g, '\\$&') + ']'
)

// ==================== DATABASE ====================

global.db = new Low(new JSONFile('database.json'))

global.loadDatabase = async function loadDatabase() {
  if (global.db.READ) {
    return new Promise((resolve) => {
      const iv = setInterval(async () => {
        if (!global.db.READ) {
          clearInterval(iv)
          resolve(global.db.data == null ? global.loadDatabase() : global.db.data)
        }
      }, 1000)
    })
  }
  if (global.db.data !== null) return
  global.db.READ = true
  await global.db.read().catch(console.error)
  global.db.READ = null
  global.db.data = {
    users: {},
    chats: {},
    stats: {},
    msgs: {},
    sticker: {},
    settings: {},
    ...(global.db.data || {}),
  }
}

// ==================== PHASE 1: PARALLEL INITIALIZATION ====================

const startTime = Date.now()
global.botStartTimestamp = Math.floor(startTime / 1000)

let savedSaveCreds

const [authResult, { version }, , handler_] = await Promise.all([
  useMultiFileAuthState('sessions'),
  fetchLatestBaileysVersion(),
  global.loadDatabase(),
  import('./handler.js'),
])

let { state, saveCreds } = authResult
savedSaveCreds = saveCreds
let handler = handler_

console.log(chalk.gray(`→ Init: ${Date.now() - startTime}ms`))

// ==================== PHASE 2: CONNECTION OPTIONS ====================

function buildConnectionOptions(authState) {
  return {
    auth: {
      creds: authState.creds,
      keys: makeCacheableSignalKeyStore(authState.keys, fatalLogger),
    },
    version,
    logger,
    browser: Browsers.ubuntu('Edge'),
    cachedGroupMetadata: async (jid) => groupCache.get(jid),
    generateHighQualityLinkPreview: true,
    syncFullHistory: false,
    shouldSyncHistoryMessage: () => false,
    markOnlineOnConnect: true,
    connectTimeoutMs: 60_000,
    keepAliveIntervalMs: 30_000,
    retryRequestDelayMs: 250,
    maxMsgRetryCount: 5,
  }
}

let connectionOptions = buildConnectionOptions(state)

// ==================== PHASE 2b: CREATE INITIAL CONNECTION ====================

global.conn = makeWASocket(connectionOptions)

if (fs.existsSync('./sessions/creds.json') && !conn.authState.creds.registered) {
  console.log(chalk.yellow('-- WARNING: creds.json is broken, please delete it first --'))
  process.exit(0)
}

if (!conn.authState.creds.registered) {
  console.log(chalk.bgWhite(chalk.blue('Generating code...')))
  setTimeout(async () => {
    try {
      let code = await conn.requestPairingCode(global.pairingNumber)
      code = code?.match(/.{1,4}/g)?.join('-') || code
      console.log(chalk.black(chalk.bgGreen('Your Pairing Code : ')), chalk.black(chalk.white(code)))
    } catch (e) {
      console.error(e)
      if (parentPort) parentPort.postMessage('restart')
      else process.exit(1)
    }
  }, 3000)
}

// ==================== DATABASE AUTO-SAVE ====================

let dbWriting = false
if (global.db) {
  setInterval(async () => {
    if (!global.db.data || dbWriting) return
    dbWriting = true
    try {
      await global.db.write()
    } catch (e) {
      console.error(chalk.red('[DB Write Error]'), e.message)
    } finally {
      dbWriting = false
    }
    if (global.support?.find) {
      [tmpdir(), 'tmp'].forEach((f) => {
        try { spawn('find', [f, '-amin', '3', '-type', 'f', '-delete']) } catch {}
      })
    }
  }, 30_000)
}

// ==================== RECONNECTION STATE ====================

let reconnectAttempts = 0
const MAX_RECONNECT_ATTEMPTS = 15
const BASE_RECONNECT_DELAY = 3_000
const MAX_RECONNECT_DELAY = 120_000
let isReconnecting = false

function getReconnectDelay() {
  return Math.min(BASE_RECONNECT_DELAY * Math.pow(1.5, reconnectAttempts), MAX_RECONNECT_DELAY)
}

// ==================== TIMESTAMP HELPER ====================

function getMessageTimestamp(msg) {
  const ts = msg?.messageTimestamp
  if (!ts) return 0
  if (typeof ts === 'number') return ts
  if (typeof ts === 'object') {
    if (typeof ts.toNumber === 'function') return ts.toNumber()
    if (ts.low !== undefined) return ts.low
  }
  return Number(ts) || 0
}

// ==================== CONNECTION UPDATE HANDLER ====================

async function connectionUpdate(update) {
  const { receivedPendingNotifications, connection, lastDisconnect, isOnline } = update
  global.stopped = connection

  if (connection === 'connecting') {
    console.log(chalk.yellow('⏳ Menghubungkan...'))
  }

  if (connection === 'open') {
    console.log(chalk.green('✅ Tersambung.'))
    reconnectAttempts = 0
    isReconnecting = false
  }

  if (isOnline === true) console.log(chalk.green('Status: Aktif'))
  else if (isOnline === false) console.log(chalk.red('Status: Tidak Aktif'))

  if (receivedPendingNotifications) {
    console.log(chalk.yellow('Menunggu pesan baru...'))
    // Tandai init selesai setelah pending notifications diterima
    if (global.conn) global.conn.isInit = false
  }

  // ── DISCONNECT HANDLING ──
  if (connection === 'close') {
    const statusCode = lastDisconnect?.error?.output?.statusCode
      ?? lastDisconnect?.error?.output?.payload?.statusCode
      ?? 500
    const reason = lastDisconnect?.error?.output?.payload?.message
      ?? lastDisconnect?.error?.message
      ?? 'Unknown'

    console.log(chalk.red(`❌ Terputus: ${reason} (code: ${statusCode})`))

    // Logged out
    if (statusCode === DisconnectReason.loggedOut || statusCode === 401) {
      console.log(chalk.red.bold('⛔ Sesi logout. Hapus folder "sessions" lalu restart.'))
      if (global.db.data) await global.db.write().catch(() => {})
      process.exit(1)
    }

    // Connection replaced
    if (statusCode === DisconnectReason.connectionReplaced || statusCode === 440) {
      console.log(chalk.red.bold('⛔ Koneksi digantikan oleh sesi lain.'))
      if (global.db.data) await global.db.write().catch(() => {})
      process.exit(1)
    }

    // Multidevice mismatch
    if (statusCode === DisconnectReason.multideviceMismatch || statusCode === 411) {
      console.log(chalk.red.bold('⛔ Multidevice mismatch. Hapus folder "sessions" lalu pairing ulang.'))
      if (global.db.data) await global.db.write().catch(() => {})
      process.exit(1)
    }

    // Bad session
    if (statusCode === DisconnectReason.badSession || statusCode === 500) {
      console.log(chalk.yellow('⚠️ Bad session terdeteksi, mencoba reconnect...'))
    }

    // Reconnectable
    if (isReconnecting) {
      console.log(chalk.gray('→ Reconnect sedang berjalan, skip...'))
      return
    }

    if (reconnectAttempts >= MAX_RECONNECT_ATTEMPTS) {
      console.log(chalk.red.bold(`⛔ Gagal reconnect setelah ${MAX_RECONNECT_ATTEMPTS} percobaan. Restarting...`))
      if (global.db.data) await global.db.write().catch(() => {})
      if (parentPort) parentPort.postMessage('restart')
      else process.exit(1)
      return
    }

    isReconnecting = true
    reconnectAttempts++
    const delay = getReconnectDelay()

    console.log(chalk.yellow(
      `🔄 Reconnect dalam ${Math.round(delay / 1000)}s (percobaan ${reconnectAttempts}/${MAX_RECONNECT_ATTEMPTS})...`
    ))

    await new Promise((r) => setTimeout(r, delay))

    try {
      await global.reloadHandler(true)
    } catch (e) {
      console.error(chalk.red('[Reconnect Error]'), e.message)
      isReconnecting = false
    }
  }

  if (global.db.data == null) await global.loadDatabase()
}

// ==================== PROCESS ERROR HANDLERS ====================

process.on('uncaughtException', (err) => {
  console.error(chalk.red('[Uncaught Exception]'), err)
})

process.on('unhandledRejection', (reason) => {
  console.error(chalk.red('[Unhandled Rejection]'), reason)
})

// ==================== GRACEFUL SHUTDOWN ====================

async function gracefulShutdown(signal) {
  console.log(chalk.yellow(`\n${signal} diterima, menyimpan data...`))
  try {
    if (global.db.data) await global.db.write()
  } catch (e) {
    console.error(chalk.red('Gagal simpan DB:'), e.message)
  }
  try { global.conn?.ws?.close() } catch {}
  console.log(chalk.green('Bye! 👋'))
  process.exit(0)
}

process.on('SIGINT', () => gracefulShutdown('SIGINT'))
process.on('SIGTERM', () => gracefulShutdown('SIGTERM'))

// ==================== RELOAD HANDLER ====================

let isInit = true

global.reloadHandler = async function (restartConn) {
  // ── 1. Reload handler.js ──
  try {
    const Handler = await import(`./handler.js?update=${Date.now()}`).catch(console.error)
    if (Handler && Object.keys(Handler).length) handler = Handler
  } catch (e) {
    console.error(chalk.red('[Handler Import Error]'), e)
  }

  // ── 2. Hapus listener lama ──
  if (!isInit) {
    try {
      conn.ev.off('messages.upsert', conn.handler)
      conn.ev.off('group-participants.update', conn.participantsUpdate)
      conn.ev.off('groups.update', conn.groupsUpdate)
      conn.ev.off('connection.update', conn.connectionUpdate)
      conn.ev.off('creds.update', conn.credsUpdate)
    } catch (e) {
      console.error(chalk.red('[Listener Cleanup Error]'), e.message)
    }
  }

  // ── 3. Restart koneksi jika diminta ──
  if (restartConn) {
    try { global.conn?.ws?.close() } catch {}
    try { conn.ev.removeAllListeners() } catch {}

    try {
      const freshAuth = await useMultiFileAuthState('sessions')
      state = freshAuth.state
      savedSaveCreds = freshAuth.saveCreds
      connectionOptions = buildConnectionOptions(state)
    } catch (e) {
      console.error(chalk.red('[Auth Refresh Error]'), e.message)
    }

    global.conn = makeWASocket(connectionOptions)
    isInit = true
  }

  // ── 4. Tandai conn.isInit (agar handler tahu sedang init) ──
  conn.isInit = isInit

  // ── 5. Setup welcome/bye/left messages ──
  conn.welcome = 'Selamat datang, @user!\nDi grup @subject\n\n@desc'
  conn.bye = 'Sampai jumpa, @user!'
  conn.left = 'Sampai jumpa, @user!'
  conn.spromote = '@user telah dipromosikan menjadi admin! 🎉'
  conn.sdemote = '@user telah diturunkan dari jabatan admin.'

  // ── 6. Message handler (filter pesan lama) ──
  const _originalHandler = handler.handler.bind(global.conn)
  conn.handler = async function (chatUpdate) {
    try {
      if (chatUpdate.type !== 'notify') return

      if (chatUpdate.messages?.length) {
        const GRACE_PERIOD = 10
        chatUpdate.messages = chatUpdate.messages.filter((msg) => {
          if (msg.key?.remoteJid === 'status@broadcast') return false
          const ts = getMessageTimestamp(msg)
          if (!ts) return false
          return ts >= global.botStartTimestamp - GRACE_PERIOD
        })
        if (chatUpdate.messages.length === 0) return
      }

      return await _originalHandler.call(this, chatUpdate)
    } catch (e) {
      console.error(chalk.red('[Handler Error]'), e)
    }
  }

  // ── 7. Participants update handler (welcome/left/promote/demote) ──
  const _boundParticipantsUpdate = handler.participantsUpdate.bind(global.conn)
  conn.participantsUpdate = async function (event) {
    // Update group cache terlebih dahulu
    try {
      const metadata = await conn.groupMetadata(event.id)
      groupCache.set(event.id, metadata)
    } catch (e) {
      console.error(chalk.red('[Group Participants Cache Error]'), e.message)
    }

    // Panggil handler welcome/left
    try {
      return await _boundParticipantsUpdate(event)
    } catch (e) {
      console.error(chalk.red('[Participants Update Error]'), e.message)
    }
  }

  // ── 8. Connection & creds handlers ──
  conn.connectionUpdate = connectionUpdate.bind(global.conn)
  conn.credsUpdate = savedSaveCreds.bind(global.conn)

  // ── 9. Groups update handler (cache) ──
  conn.groupsUpdate = async ([event]) => {
    try {
      const metadata = await conn.groupMetadata(event.id)
      groupCache.set(event.id, metadata)
    } catch (e) {
      console.error(chalk.red('[Group Cache Error]'), e.message)
    }
  }

  // ── 10. Anti-call ──
  conn.ev.on('call', async (calls) => {
    for (const call of calls) {
      try {
        const { id, from, status } = call
        const settings = global.db.data?.settings?.[conn.user?.jid]
        if (status === 'offer' && settings?.anticall) {
          await conn.rejectCall(id, from)
          console.log(chalk.gray(`Menolak panggilan dari ${from}`))
        }
      } catch (e) {
        console.error(chalk.red('[Call Handler Error]'), e.message)
      }
    }
  })

  // ── 11. Register event listeners ──
  conn.ev.on('messages.upsert', conn.handler)
  conn.ev.on('group-participants.update', conn.participantsUpdate)
  conn.ev.on('groups.update', conn.groupsUpdate)
  conn.ev.on('connection.update', conn.connectionUpdate)
  conn.ev.on('creds.update', conn.credsUpdate)

  // ── 12. Selesai init ──
  isInit = false
  conn.isInit = false
  isReconnecting = false

  return true
}

// ==================== PHASE 3: PLUGIN LOADER ====================

const pluginFolder = join(__dirname, './plugins')
const pluginFilter = /\.js$/
global.plugins = {}

const pluginCache = new Map()
const reloadQueue = new Map()
const DEBOUNCE_DELAY = 300

function getPluginFiles(dir, base = '') {
  const results = []
  if (!fs.existsSync(dir)) return results
  try {
    const entries = fs.readdirSync(dir, { withFileTypes: true })
    for (const entry of entries) {
      const rel = base ? `${base}/${entry.name}` : entry.name
      if (entry.isDirectory()) results.push(...getPluginFiles(join(dir, entry.name), rel))
      else if (pluginFilter.test(entry.name)) results.push(rel)
    }
  } catch (e) {
    console.error(chalk.red('[Plugin Scan Error]'), e.message)
  }
  return results
}

async function loadPlugin(relativePath, { force = false, skipSyntax = false } = {}) {
  const fullPath = join(pluginFolder, relativePath)

  if (!fs.existsSync(fullPath)) {
    if (global.plugins[relativePath]) {
      delete global.plugins[relativePath]
      pluginCache.delete(relativePath)
      console.log(chalk.yellow(`Plugin dihapus: ${relativePath}`))
    }
    return false
  }

  let mtime
  try {
    mtime = fs.statSync(fullPath).mtimeMs
  } catch {
    return false
  }

  if (!force && pluginCache.get(relativePath) === mtime) return true

  if (!skipSyntax) {
    try {
      const content = fs.readFileSync(fullPath, 'utf-8')
      const err = syntaxerror(content, relativePath, {
        sourceType: 'module',
        allowAwaitOutsideFunction: true,
      })
      if (err) {
        console.error(chalk.red(`Syntax error: ${relativePath}\n${format(err)}`))
        return false
      }
    } catch (e) {
      console.error(chalk.red(`[Plugin Read Error] ${relativePath}:`), e.message)
      return false
    }
  }

  try {
    const module = await import(`${global.__filename(fullPath)}?t=${mtime}`)
    global.plugins[relativePath] = module.default || module
    pluginCache.set(relativePath, mtime)
    return true
  } catch (e) {
    console.error(chalk.red(`Gagal load: ${relativePath}\n${e.message}`))
    return false
  }
}

async function initPlugins() {
  const t = Date.now()
  const files = getPluginFiles(pluginFolder)

  const results = await Promise.allSettled(
    files.map((f) => loadPlugin(f, { force: true, skipSyntax: true }))
  )

  const loaded = results.filter((r) => r.status === 'fulfilled' && r.value).length
  console.log(chalk.green(`✓ Loaded ${loaded}/${files.length} plugins (${Date.now() - t}ms)`))

  global.plugins = Object.fromEntries(
    Object.entries(global.plugins).sort(([a], [b]) => a.localeCompare(b))
  )
}

function queueReload(relativePath) {
  if (reloadQueue.has(relativePath)) clearTimeout(reloadQueue.get(relativePath))
  reloadQueue.set(
    relativePath,
    setTimeout(async () => {
      reloadQueue.delete(relativePath)
      const existed = !!global.plugins[relativePath]
      const success = await loadPlugin(relativePath, { skipSyntax: false })
      if (success) {
        console.log(chalk.cyan(`${existed ? 'Reloaded' : 'Loaded'}: ${relativePath}`))
        global.plugins = Object.fromEntries(
          Object.entries(global.plugins).sort(([a], [b]) => a.localeCompare(b))
        )
      }
    }, DEBOUNCE_DELAY)
  )
}

function watchPlugins() {
  if (!fs.existsSync(pluginFolder)) fs.mkdirSync(pluginFolder, { recursive: true })
  try {
    const watcher = fs.watch(pluginFolder, { recursive: true }, (_, filename) => {
      if (!filename || !pluginFilter.test(filename)) return
      queueReload(filename.replace(/\\/g, '/'))
    })
    watcher.on('error', (err) => console.error(chalk.red('[Watcher Error]'), err.message))
    process.on('SIGINT', () => { try { watcher.close() } catch {} })
    process.on('SIGTERM', () => { try { watcher.close() } catch {} })
    console.log(chalk.gray('→ Plugin watcher aktif'))
  } catch {
    console.log(chalk.yellow('→ Fallback watcher'))
    watchPluginsFallback()
  }
}

function watchPluginsFallback() {
  const watchers = new Map()
  function watchDir(dir, base = '') {
    if (watchers.has(dir)) return
    try {
      const watcher = fs.watch(dir, (_, filename) => {
        if (!filename) return
        const fullPath = join(dir, filename)
        const rel = base ? `${base}/${filename}` : filename
        try {
          if (fs.existsSync(fullPath) && fs.statSync(fullPath).isDirectory()) {
            watchDir(fullPath, rel)
            return
          }
        } catch {}
        if (pluginFilter.test(filename)) queueReload(rel)
      })
      watchers.set(dir, watcher)
      if (fs.existsSync(dir)) {
        for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
          if (entry.isDirectory()) {
            watchDir(join(dir, entry.name), base ? `${base}/${entry.name}` : entry.name)
          }
        }
      }
    } catch (e) {
      console.error(chalk.red('[Fallback Watcher Error]'), e.message)
    }
  }
  watchDir(pluginFolder)
}

global.reloadAllPlugins = async function () {
  pluginCache.clear()
  global.plugins = {}
  await initPlugins()
  return Object.keys(global.plugins).length
}

// ==================== PHASE 4: START EVERYTHING ====================

await initPlugins()
watchPlugins()
await global.reloadHandler()

console.log(chalk.green(`⚡ Bot ready in ${Date.now() - startTime}ms`))

// ==================== PHASE 5: HEALTH CHECK ====================

setInterval(() => {
  try {
    if (global.conn && global.stopped === 'open') {
      const ws = global.conn?.ws
      if (ws && ws.readyState !== ws.OPEN && ws.readyState !== ws.CONNECTING) {
        console.log(chalk.yellow('⚠️ WebSocket zombie terdeteksi, reconnecting...'))
        if (!isReconnecting) {
          global.reloadHandler(true).catch(console.error)
        }
      }
    }
  } catch {}
}, 60_000)

// ==================== PHASE 6: QUICK TEST ====================

;(async function _quickTest() {
  try {
    const test = await Promise.all(
      [
        spawn('ffmpeg'),
        spawn('ffprobe'),
        spawn('ffmpeg', [
          '-hide_banner', '-loglevel', 'error',
          '-filter_complex', 'color',
          '-frames:v', '1', '-f', 'webp', '-',
        ]),
        spawn('convert'),
        spawn('magick'),
        spawn('gm'),
        spawn('find', ['--version']),
      ].map((p) =>
        Promise.race([
          new Promise((resolve) => p.on('close', (code) => resolve(code !== 127))),
          new Promise((resolve) => p.on('error', () => resolve(false))),
        ])
      )
    )
    const [ffmpeg, ffprobe, ffmpegWebp, convert, magick, gm, find] = test
    global.support = Object.freeze({ ffmpeg, ffprobe, ffmpegWebp, convert, magick, gm, find })
    console.log(chalk.gray('→ Quick test selesai'))
  } catch (e) {
    console.error(chalk.red('[Quick Test Error]'), e.message)
    global.support = Object.freeze({
      ffmpeg: false, ffprobe: false, ffmpegWebp: false,
      convert: false, magick: false, gm: false, find: false,
    })
  }
})()